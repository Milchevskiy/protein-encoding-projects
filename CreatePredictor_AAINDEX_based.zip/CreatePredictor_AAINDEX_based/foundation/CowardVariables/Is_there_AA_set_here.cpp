#pragma warning( disable : 4786 )

#include "Is_there_AA_set_here.h"
#include "CowardVariables.h"

using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>

Is_there_AA_set_here::Is_there_AA_set_here(
	CowardVariables& cowa_store,
	const string& task_string
) : Property(cowa_store)
{
//Is_there_AA_set_here       0            DUMB  -2 PARA
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "Is_there_AA_set_here" ) ;

	//int tmp_int;
	//ist >> tmp_int;
	//is_subsidiary_ = ( tmp_int == 1 ) ? true : false;

	ist >> variable_name_in_list_;

	/*
	string current_property_name;
	ist >> current_property_name;
	property_ID_ = get_property_ID_by_property_name ( current_property_name ) ;
	*/
	ist >> 	left_border_ ;
	//ist >> 	right_border_ ;


	ist >> aa_set_;

	ist >> answer_mode_;

}

Property* Is_there_AA_set_here::
clone ( const string & task_string ) const
{
	return new Is_there_AA_set_here(cowa_store_,task_string);
}

double    Is_there_AA_set_here::calc_value (
		const int   position_in_chain/*,
			  int	var_set_cursor,
		const		vector < vector < double > >   & Chain_Prime_Constants,
					vector < vector < double > >   & sophisticated_variables */   )

{

	int pre_start = position_in_chain + left_border_;
	int pre_end = pre_start + aa_set_.size();

	int seq_len = cowa_store_.sequence_.size();

	if (pre_start >= seq_len)
		return 0.0;

	int start = max(0, pre_start);
	int end_ = min(pre_end, seq_len);


	int sum = 0;
	int kk = 0;
	for (int ii = start; ii < end_; ii++)
	{
		char current_aa = cowa_store_.sequence_[ii];
		if (current_aa != aa_set_[kk])
			return  0.0;
		kk++;
	}

	return 1.0;


}
