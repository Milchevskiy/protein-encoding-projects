#ifndef BASE_COWARD_H
#define BASE_COWARD_H

#include	<string>
#include	<vector>
#include	<map>

using namespace std;

using namespace std; 

class  Base_coward
{
public:
	  
	Base_coward(): 
	  value_( 0 ),
	  is_subsidiary_ (false)
	  {}

	virtual			~Base_coward() ;
	virtual			Base_coward* clone (const string & task_string, map   < string, int >&	co_task_variable_name_to_index   ) const					= 0;

	virtual			void    calc_value ( 
				const int   position_in_chain,  
					  int	var_set_cursor, 
				const		vector < vector < double > >   & Chain_Prime_Constants,
							vector < vector < double > >   & sophisticated_variables    )   = 0;

/*
	virtual			void    calc_contact_value ( 
						const int   ii_position_in_chain,  
						const int   jj_position_in_chain,  
						int			var_set_cursor, 
						vector < vector < double > >   & sophisticated_variables    )   = 0;
*/


	double			get_value		() const { return value_; } 

	bool			is_subsidiary () const { return is_subsidiary_; }

protected:	
	double	value_;
	string	name_;
	bool    is_subsidiary_;
};

#endif