#include "Base_coward.h"

Base_coward::~Base_coward()  
{
}

