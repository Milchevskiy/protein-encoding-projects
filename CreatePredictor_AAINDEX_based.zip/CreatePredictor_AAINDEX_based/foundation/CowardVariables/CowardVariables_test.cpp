
#pragma warning( disable : 4786 )

#include "CowardVariables_test.h"
#include "CowardVariables.h"

//#include "../Fragment_base/Chain_binary.h"
//#include "../Main_model/Abu_Maimonides_Rambam.h"

#include "../CommonFunc.h"
//#include "../Censorship.h"




#include <fstream>
#include <iostream>

//#include "../Main_model/handle_det_distance_set.h"

using namespace std;

extern ofstream log_stream;

//extern Censorship configuration;

CowardVariables_test::~CowardVariables_test()
{
	cout << "CowardVariables_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;

}



void CowardVariables_test::first_test			()
{
	CowardVariables  cvs ("TEST/CowardVariables.task");

	string sequence = "RAPRARAKALRLLLKLLKLLSRYWVRVKRLLL";

///	vector < vector < double > > sophisticated_variables  ;

	cvs.process_chain(
		sequence );

	vector < vector < double > >	sophisticated_variables = cvs.get_sophisticated_variables();



	ofstream  out( "TEST/CowardVariables_test.txt");

	if ( ! out)	{
		log_stream << "CowardVariables_test: ERROR -  can't create file" << endl;
		cout       << "CowardVariables_test: ERROR -  can't create file" << endl;
		exit (1);
	}


	int number_of_variables = cvs.get_number_of_variables() ;
	for (int ii=0; ii<sophisticated_variables.size() ;ii++)
	{
		for (int kk=0;kk<number_of_variables ;kk++)
			PutVaDouble (sophisticated_variables [ii][kk], out,10, 3 , 'l');
		out << endl;
	}
}
