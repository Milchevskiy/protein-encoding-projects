#ifndef COWARDVARIABLES_TEST_H
#define COWARDVARIABLES_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  CowardVariables_test: public Simple_test
{
public:
	~CowardVariables_test();

    void run()
    {
		first_test				();
	}
	void first_test				();
	
};

#endif


