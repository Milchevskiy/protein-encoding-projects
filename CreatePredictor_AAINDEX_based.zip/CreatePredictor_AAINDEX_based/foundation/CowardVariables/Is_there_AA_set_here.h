#ifndef IS_THERE_AA_SET_HERE_H_INCLUDED
#define IS_THERE_AA_SET_HERE_H_INCLUDED


#ifndef PROPERTY_H
#include "Property.h"
#endif

#include <string>
#include <vector>

using namespace std;

class  Is_there_AA_set_here: public Property
{
public:

	Is_there_AA_set_here(CowardVariables & cowa_store ) :
		Property( cowa_store)
	{}

	explicit Is_there_AA_set_here(
		CowardVariables & cowa_store,
		const string	& task_string);




	Property* clone	(
		const string & task_string) const;

	double    calc_value(const int   position_in_chain);

protected:

	string	variable_name_in_list_; // ��� ���������� ��� ������� ������ ������

	int		left_border_ ;
	int		right_border_ ;

	string  aa_set_;
	char    answer_mode_;

	double  power_ ;

	//int		property_ID_;

	int     pb_index_;

	char	fabs_mode_;

	Is_there_AA_set_here(const Is_there_AA_set_here&);
	Is_there_AA_set_here& operator = (const Is_there_AA_set_here&);
};


#endif // DULL_DISTANCE_SUM_H_INCLUDED

