#ifndef COWARDVARIABLES_H
#define COWARDVARIABLES_H

#include "Property.h"

#include	<map>
#include	<vector>

using namespace std;

//#include "..//Frequency_extrapolation//Frequency_chain_constants.h"

//class Frequency_extrapolation;

class CowardVariables
{
public:
CowardVariables() {}
	explicit CowardVariables( const string & Sequence_to_values_file_name);
	~CowardVariables() {};

	void process_chain ( 
		const string & sequense );

	void set_path_to_current_prediction(const string & path_to_current_prediction) { path_to_current_prediction_ = path_to_current_prediction; }
	string path_to_current_prediction_;  // file containing predicted structure information
	string get_path_to_current_prediction() const  { return path_to_current_prediction_; }

//	vector < vector < double > > &	get_predicted_distance_set() { return predicted_distance_set_; }
//	void refresh_predicted_distance_set(); // read distance_set from binary file from path_to_current_prediction_

	int get_number_of_variables () const {return number_of_variables_ ;}  

	map    < string, int >					get_coward_variable_name_to_index () const
												{ return coward_variable_name_to_index_;}  

	vector < vector < double > >	const & get_sophisticated_variables() const { return sophisticated_variables_; }

	vector < vector <double > >     Chain_Prime_Constants_;
	vector < vector < double > >	sophisticated_variables_;
	string							sequence_;

/*	vector < Frequency_chain_constants >		pull_fcc_;
	vector < Frequency_extrapolation * >		frequency_pull_;
	map    < string, int >						frequency_name_to_pull_index_;


	void 		frequency_constant_for_chain(
			const string & sequence,
			const string & chain_ID); 

	int get_predicted_distance_set_size() const {return predicted_distance_set_.size();	}

	vector < vector < double > >			predicted_distance_set_;  // only for motif prediction. NOT FOR STRUCTURE PREDICTION
*/	
	map    < string, int >					coward_variable_name_to_index_;

private:

	vector < Property *  >				    array_derived_SequenceMap_toValues_;
	map    < string, Property* >			known_templates_map_SequenceMap_toValue_;

	int		number_of_variables_ {};

	void init_frequency_prichindales(const vector < string >   & all_mapped_definite_task);

	void  init_known_templates_map ();

	void calc_values(		int position); 

	CowardVariables ( const CowardVariables& );
	void operator = ( const CowardVariables& );
};

#endif
