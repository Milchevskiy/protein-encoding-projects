#pragma warning( disable : 4786 )

///#include "Composite_Filter_only.h"

#include "CowardVariables.h"

#include "Simultaneous_two_variables.h"

///#include "../WiseVariables/get_property_ID_by_property_name.h"

using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>
#include <iostream>
#include <fstream>

extern ofstream log_stream;


Simultaneous_two_variables::Simultaneous_two_variables (
	CowardVariables & cowa_store,
	const string	& task_string
) : Property(cowa_store),
    fabs_mode_ ('a')
{
// Simultaneous_two_variables 	0 DULL Filtered_name Second_name
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "Simultaneous_two_variables" ) ;

	//int tmp_int;
	//ist >> tmp_int;

	ist >> variable_name_in_list_;

	ist >> first_var_name_ ;
	ist >> second_var_name_ ;


	if  ( cowa_store_.coward_variable_name_to_index_.end() == cowa_store_.coward_variable_name_to_index_.find ( first_var_name_ )  )
    {
        log_stream << first_var_name_ <<    ": There is no variable with this name."  << endl;
        cout       << first_var_name_ <<    ": There is no variable with this name."  << endl;
        exit(1);
    }

 

	/*ist >> border_value_ ;

	if ( ! (ist >>  power_)  )
		power_ = 1;
		*/
}

Property* Simultaneous_two_variables::
clone ( const string & task_string ) const
{
	return new Simultaneous_two_variables(cowa_store_,task_string);
}

double    Simultaneous_two_variables::calc_value (
		const int   position_in_chain)
{
    int first_index     = cowa_store_.coward_variable_name_to_index_[first_var_name_];
    int second_index    = cowa_store_.coward_variable_name_to_index_[second_var_name_];

    double first_var    = cowa_store_.get_sophisticated_variables()[position_in_chain][first_index];
    double second_var   = cowa_store_.get_sophisticated_variables()[position_in_chain][second_index];

   return first_var*second_var;
}
