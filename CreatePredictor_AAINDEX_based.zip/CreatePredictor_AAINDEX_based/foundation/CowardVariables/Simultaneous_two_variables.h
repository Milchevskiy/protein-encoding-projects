#ifndef SIMULTANEOUS_TWO_VARIABLES_H_INCLUDED
#define SIMULTANEOUS_TWO_VARIABLES_H_INCLUDED


#ifndef PROPERTY_H
#include "Property.h"
#endif

#include <string>
#include <vector>

using namespace std;


class  Simultaneous_two_variables: public Property
{
public:

	Simultaneous_two_variables(CowardVariables & cowa_store ) :
		Property( cowa_store)
	{}

	explicit Simultaneous_two_variables(
		CowardVariables & cowa_store,
		const string	& task_string);

	Property* clone	(
		const string & task_string) const;

	double    calc_value(const int   position_in_chain);

protected:

	string	variable_name_in_list_; // ��� ���������� ��� ������� ������ ������

	string first_var_name_ ;
	string second_var_name_ ;

	char	fabs_mode_;

	double border_value_;
	double power_;

	Simultaneous_two_variables(const Simultaneous_two_variables&);
	Simultaneous_two_variables& operator = (const Simultaneous_two_variables&);
};



#endif // SIMULTANEOUS_TWO_VARIABLES_H_INCLUDED
