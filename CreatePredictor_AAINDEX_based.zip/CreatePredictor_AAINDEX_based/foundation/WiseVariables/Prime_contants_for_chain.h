#ifndef	PRIME_CONTANTS_FOR_CHAIN_H
#define	PRIME_CONTANTS_FOR_CHAIN_H

#include <vector>
#include <string>

using namespace std;

 void prime_contants_for_chain ( const string & chain_sequence, vector < vector <double > > & Chain_Prime_Constants);

#endif
