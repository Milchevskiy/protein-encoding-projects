#ifndef GET_PROPERTY_ID_BY_PROPERTY_NAME_H
#define GET_PROPERTY_ID_BY_PROPERTY_NAME_H

#include <string> 

int get_property_ID_by_property_name  ( const std::string  & property_name );
#endif