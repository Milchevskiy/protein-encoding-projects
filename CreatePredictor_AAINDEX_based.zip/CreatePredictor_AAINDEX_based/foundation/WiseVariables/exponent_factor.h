#ifndef EXPONENT_FACTOR_H 
#define EXPONENT_FACTOR_H 

double exponent_factor ( const int point_number, const int shift ) ;


#endif