﻿// PredEnco.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <fstream>

#include "foundation/CowardVariables/CowardVariables_test.h"

using namespace std;
ofstream log_stream;

int main()
{
    std::cout << "Creating predictors based on AAINDEX database\n";
    string  output_file("log");
    log_stream.open(output_file.c_str());

    CowardVariables_test CowardVariables_test_;
    CowardVariables_test_.run();
 }
