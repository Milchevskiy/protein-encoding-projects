
#pragma warning( disable : 4786 )

#include "Discriminant_utility_test.h"
#include "Discriminant_stepwise.h" 

#include "Generality_test.h"
#include "Regression_stepwise.h" 

#include "../Common/CommonFunc.h"
#include "Statistic_general_purpose.h"

#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

Discriminant_utility_test::~Discriminant_utility_test()
{
	cout << "Discriminant_utility_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Discriminant_utility_test::compare_cross_sum_new_and_traditional() 
{

	Discriminant_stepwise  discriminant_stepwise_ 
		(string ("discriminant_data"),       string ("discriminant_options") );

	Regression_stepwise    regression_stepwise_ 
		(string ("discriminant_data_check"), string ("regression_options") );

	vector <  double >	 average_value = discriminant_stepwise_.get_average_value();
	vector <  double >	 cross_matrix  = discriminant_stepwise_.get_cross_marix();

	vector <  double >	 avsumx        = regression_stepwise_.get_original_variable_sum_matrix(); 
	vector <  double >	 su            = regression_stepwise_.get_original_cross_sum_matrix();

	int wcount     = regression_stepwise_. get_number_of_variables ();
	int recordnum  = regression_stepwise_.get_number_of_cases();

	vector <  double >	 d ; d.resize(wcount); 
	prepare_covariation_matrix( 
		recordnum,	wcount,	
		avsumx, su, d ); 


	double difference = 0;
	for (int ii=0;ii<wcount ;ii++)
	{
		double val_old  = avsumx [ii];
		double val_new  = average_value [ii];
		difference += fabs (val_old  - val_new  );

	}
	test( "avsumx for old and new version must be equal ",	difference <  epsilon_float() );

	difference = 0;
	for (int ii=0;ii< su.size();ii++)
	{
		double val_old  = su[ii];
		double val_new  = cross_matrix[ii];
		difference += fabs (( recordnum-1) * val_old  - val_new  );
	}
	test( "avsumx for old and new version must be equal ",	difference <  epsilon_float() );



}

void Discriminant_utility_test::compare_number_of_included_variables() 
{

	Discriminant_stepwise  discriminant_stepwise_ 
		(string ("discriminant_data"),       string ("discriminant_options") );

	Discriminant_stepwise  discriminant_stepwise_1 
		(string ("discriminant_data_1"),       string ("discriminant_options") );


	int number_0 = discriminant_stepwise_ .get_number_of_included();
	int number_1 = discriminant_stepwise_1.get_number_of_included();


}


void Discriminant_utility_test::test_pull_out_discrimination_constants( string & data_source_name) 
{

	Discriminant_stepwise  discriminant_stepwise_1 
		(data_source_name,       string ("discriminant_options") );


	vector < vector < double> >  group_classifying_coefficient    = 
		discriminant_stepwise_1.get_group_classifying_coefficient     () ;

	vector  < double >     constant_of_classifying_function = 
		discriminant_stepwise_1.get_constant_of_classifying_function  () ;

	vector < double>  intra_group_cross_marix = 
		discriminant_stepwise_1.get_intra_group_cross_marix () ;


	string result_file_name = new_extension_file_name (data_source_name,"dc");
	ofstream  out ( result_file_name.c_str() );
	if ( ! out)	{	cout << "can't find file " << "discriminant_data_1.discriminant_constants" << endl;
		assert (  out );		exit (1);	}


	int number_of_variables = discriminant_stepwise_1.get_number_of_variables ();
	int number_of_groops   =  discriminant_stepwise_1.get_number_of_groops    ();
	int number_of_cases = discriminant_stepwise_1.get_number_of_cases    ();
    
	vector < string >  variable_names = discriminant_stepwise_1.get_variable_names ();


    out << "N - Q = " << number_of_cases -  number_of_groops << endl;
	out << "intra_group_cross_marix " << endl;
	for ( int kk=0;kk<intra_group_cross_marix.size(); kk++)
			PutVaDouble (intra_group_cross_marix[kk],out,8, 3,'r');


	out << endl << "Group classifying coefficients" << endl;
	for (int ii=0;ii<number_of_variables;ii++)
	{
		PutVa(variable_names [ii],out,10, 8,'r');
		PutVa(ii,out,5, 3,'r');

		for ( int gg=0;gg<number_of_groops;gg++)
		{
			PutVaDouble (group_classifying_coefficient[ii][gg],out,8, 3,'r');
		}
		out << endl;
	}


	out << "Constant_of_classifying_function " << endl;
	for ( int gg=0;gg<number_of_groops;gg++)
		PutVaDouble (constant_of_classifying_function[gg],out,8, 3,'r');


   vector < vector < double> >  group_average_value = discriminant_stepwise_1.get_group_average_value();

   out << endl << "group_average_values " << endl;
   for (int ii=0;ii<number_of_variables;ii++)
   {
	   for ( int gg=0;gg<number_of_groops;gg++)
	   {
		   PutVaDouble (group_average_value[gg][ii],out,8, 3,'r');
	   }
	   out << "   ";
   }
   
   vector < double>   average_value = discriminant_stepwise_1.get_average_value ();
   out << endl << "average_values " << endl;
   for (int ii=0;ii<number_of_variables;ii++)
   {
	   PutVaDouble (average_value[ii],out,8, 3,'r');
   }




	out << endl << endl << "probabilitie to be in groops" << endl;

	for ( int ii=0; ii< number_of_cases;ii++)
	{
		vector < double > current_case = 
			discriminant_stepwise_1.get_case_variables (ii);

		vector < double > probabilities =  
			discriminant_stepwise_1.posterior_probability_to_be_in_each_group ( current_case );

		for ( int gg=0;gg<number_of_groops;gg++)
			PutVaDouble (probabilities[gg],out,8, 3,'r');

		out << endl;
	}


}
