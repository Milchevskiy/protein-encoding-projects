#ifndef GENERALITY_TEST_H
#define GENERALITY_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Common/Simple_test.h"

#endif


class  Generality_test: public Simple_test
{
public:
	~Generality_test();

    void run()
    {
		one_dimensional_matrix_index_test  ();
		lead_up_cross_sum_matrix_test      ();
		sweep_matrix_operator_test         ();
		select_sweep_variables_test        ();
		fill_up_one_iteration_result       ();
		check_index_of_included_filling    ();
		binary_input_output_test           ();
	}
	void lead_up_cross_sum_matrix_test     ();
    void sweep_matrix_operator_test        ();
	void one_dimensional_matrix_index_test ();
	void select_sweep_variables_test       ();
	void fill_up_one_iteration_result      ();
	void check_index_of_included_filling   ();
	void binary_input_output_test          ();
    
};

#endif
