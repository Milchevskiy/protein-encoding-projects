#ifndef DISCRIMINANT_UTILITY_TEST_H
#define DISCRIMINANT_UTILITY_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Common/Simple_test.h"

#endif

#include <string>

class  Discriminant_utility_test: public Simple_test
{
public:
	~Discriminant_utility_test();

    void run()
    {
		compare_cross_sum_new_and_traditional();
		compare_number_of_included_variables(); 
		test_pull_out_discrimination_constants(std::string ("discriminant_data_1") ); 
		test_pull_out_discrimination_constants(std::string ("bigdata.STR") ); 
		test_pull_out_discrimination_constants(std::string ("1AON.resdat") ); 
		test_pull_out_discrimination_constants(std::string ("bigdata_polinom") ); 



	}
    
	void compare_cross_sum_new_and_traditional();
	void compare_number_of_included_variables() ;
	void test_pull_out_discrimination_constants();
	void test_pull_out_discrimination_constants( std::string & data_source_name); 


};

#endif
