#pragma warning( disable : 4786 )

#ifndef DISCRIMINANT_STEPWISE_H
#define DISCRIMINANT_STEPWISE_H

#include <string>
#include <vector>
#include <map>

Discriminant_stepwise
class Discriminant_stepwise
{
public:
	Discriminant_stepwise() {};
	Discriminant_stepwise( 
		const std::string &data_file_name, 
		const std::string &option_file_name);

private:
	std::string data_file_name_;
	std::string option_file_name_;

	int		number_of_variables_;
	int		number_of_cases_    ;
	int		number_of_included_ ;


	std::vector < std::vector < double> >	task_set_matrix_;
	std::vector < std::string >			    variable_names_;
};

#endif

