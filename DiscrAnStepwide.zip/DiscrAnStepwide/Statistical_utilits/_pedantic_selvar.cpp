#include "Regression_stepwise.h" 
#include "../Common/CommonFunc.h"
#include "Statistic_general_purpose.h"

bool Regression_stepwise::pedantic_selvar (int & FLAG,int & K)
{
	
	vector <double> A = su_;
	vector <double> D = d_;
	int M  = number_of_variables_;
	int N  = number_of_cases_;
	int NP = number_of_included_;
	double TOL = tolerance_;
	double FIN = Fisher_in_;
	double FOUT = Fisher_out_;
	int ID = number_of_variables_ - 1;

	int KP,KN;
	double V;

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	double VN =  - FOUT* A [ one_dimensional_matrix_index(  ID,  ID,  number_of_variables_) ];
	double VP = 0;
	for (int I=0;I<M;I++)
	{
		if ( I == ID ) 
			continue;
		if ( fabs ( A [ one_dimensional_matrix_index(  I,  I, number_of_variables_) ] )  < VERY_SMALL_POSITIVE_VALUE  ) 
			continue;

		int itmp=min(I,ID);
		int jtmp=max(I,ID);

		 V =  A [ one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_) ] *
		      A [ one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_) ] /
		      A [ one_dimensional_matrix_index(  I,     I,     number_of_variables_) ] ;

		if ( V <= VN )
			continue;
		if ( V <   0 )
			goto label2;
		if ( V <= VP ) 
			continue;
		if (  A [ one_dimensional_matrix_index(  I,  I, number_of_variables_) ] / D[I] < TOL )
			continue;
		VP = V;
		KP = I;
		continue;
label2: 
		VN = V;
		KN = I;

	}

	FLAG = 0;
	if ( (N -NP -2)*VP >= FIN* ( A [ one_dimensional_matrix_index(  ID,    ID,    number_of_variables_)] -VP)  )
		FLAG = -1;
	if( -(N -NP -1)*VN <  FOUT*A [ one_dimensional_matrix_index(  ID,    ID,    number_of_variables_) ] )
		FLAG = 1;
	K = KP;
	if (FLAG ==1) 
		K = KN;

	if (FLAG)		return true;
	else            return false;
}

					  