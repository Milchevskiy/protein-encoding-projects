#include "Regression_stepwise.h" 
#include "Statistic_general_purpose.h"

#include "../Common/CommonFunc.h"

#include <fstream>
#include <iostream>
#include <cassert>
#include <sstream>

using namespace std;

Regression_stepwise::Regression_stepwise ( 
	const string &data_file_name, 
	const string &option_file_name ):

data_file_name_   (data_file_name), 
option_file_name_ (option_file_name),
number_of_included_ (0)
{
	assign_options();

	string names_file_name = new_extension_file_name (data_file_name_,"names");

	ifstream  data_stream ( data_file_name_.c_str() );
	if ( ! data_stream )	{	cout << "can't find file " << data_file_name_ << endl;
		assert (  data_stream  );		exit (1);	}

	ifstream  names_stream ( names_file_name .c_str() );
	if ( ! names_stream )	{	cout << "can't find file " << names_file_name  << endl;
		/*assert (  names_stream );		exit (1);*/	}

	
	data_stream >> number_of_cases_ >> number_of_variables_;


	int number_of_varable_name = variable_names_.size() ;

	if (  names_stream )
	{
		string word;
		while ( names_stream >> word ) 
			variable_names_.push_back (word );
	}

	number_of_varable_name = variable_names_.size() ;

	if (number_of_varable_name != number_of_variables_ )
	{
		cout << "improper number of names for variables in file " << names_file_name << endl;
		for ( int kk=0;kk<number_of_variables_;kk++)
		{
			ostringstream v_stream;
			v_stream << "V_" << kk +1;
			variable_names_.push_back ( v_stream.str() );
		}
	
//		assert (0); 
//		exit(1);
	}

	index_of_included_.resize(number_of_variables_);

	int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;
	avsumx_.          resize( number_of_variables_ );
	su_.              resize( upper_triange_matrix_size );
    //cross_sum_matrix_.resize ( upper_triange_matrix_size );

	
	vector < double > x; 	x.resize ( number_of_variables_ ); 
	for (int ii=0;ii<number_of_cases_;ii++)
	{
		for (int jj=0;jj<number_of_variables_;jj++) 
			data_stream >> x[jj];
//		task_set_matrix_.push_back (x); // fix late; Note, that to hold huge data matrix may be with difficulty
		supplement_cross_sum_matrix( number_of_variables_ ,x,                     
			                         avsumx_ , su_, 1);  
	}

// memorize this values, it will needed for iteration process
	virgin_avsumx_ = avsumx_;
	virgin_su_ = su_;


    d_.resize( number_of_variables_ );
	prepare_covariation_matrix( 
		number_of_cases_,			//const int recordnum, 
		number_of_variables_,		//const int wc, 
		avsumx_,					//vector <double> & avsumx, 
		su_,						//vector <double> & su, 
		d_)	;						//vector <double> & d ) 

	prepare_particular_solution ();
	fill_up_one_iteration_result();
}
// addition for seoarate usage when ready_task_set_matrix is available
Regression_stepwise::
Regression_stepwise( 		
	vector < vector < double> >	ready_task_set_matrix, 
	const string &option_file_name):
  option_file_name_ (option_file_name),
  task_set_matrix_ (ready_task_set_matrix)
{

	assign_options();

	number_of_cases_ = ready_task_set_matrix.size();
	number_of_variables_ = ready_task_set_matrix[0].size();

	index_of_included_.resize(number_of_variables_);

	int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;
	avsumx_.          resize( number_of_variables_ );
	su_.              resize( upper_triange_matrix_size );
    //cross_sum_matrix_.resize ( upper_triange_matrix_size );

	
	vector < double > x; 	x.resize ( number_of_variables_ ); 
	for (int ii=0;ii<number_of_cases_;ii++)
	{
//		for (int jj=0;jj<number_of_variables_;jj++) 
//			data_stream >> x[jj];
		task_set_matrix_.push_back (x); // fix late; Note, that to hold huge data matrix may be with difficulty
		supplement_cross_sum_matrix( number_of_variables_ ,task_set_matrix_[ii],                     
			                         avsumx_ , su_, 1);  
	}

// memorize this values, it will needed for iteration process
	virgin_avsumx_ = avsumx_;
	virgin_su_ = su_;


    d_.resize( number_of_variables_ );
	prepare_covariation_matrix( 
		number_of_cases_,			//const int recordnum, 
		number_of_variables_,		//const int wc, 
		avsumx_,					//vector <double> & avsumx, 
		su_,						//vector <double> & su, 
		d_)	;						//vector <double> & d ) 

	prepare_particular_solution ();
	fill_up_one_iteration_result();

	for ( int kk=0;kk<number_of_variables_;kk++)
	{
		ostringstream v_stream;
		v_stream << "V_" << kk +1;
		variable_names_.push_back ( v_stream.str() );

	}

}
  Regression_stepwise ::
Regression_stepwise (
		const int number_of_cases ,
		const int number_of_variables ,
		vector < double> & avsumx , 
		vector < double> & su, 
		const string &option_file_name):
 number_of_cases_		(number_of_cases ),
 number_of_variables_	(number_of_variables ) ,
 option_file_name_ (option_file_name),
 avsumx_( avsumx ),
 su_(su)

{

	assign_options();
	index_of_included_.resize(number_of_variables_);

	int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;

// memorize this values, it will needed for iteration process
	virgin_avsumx_ = avsumx_;
	virgin_su_ = su_;


    d_.resize( number_of_variables_ );
	prepare_covariation_matrix( 
		number_of_cases_,			//const int recordnum, 
		number_of_variables_,		//const int wc, 
		avsumx_,					//vector <double> & avsumx, 
		su_,						//vector <double> & su, 
		d_)	;						//vector <double> & d ) 

	prepare_particular_solution ();
	fill_up_one_iteration_result();

	ifstream  names_stream ( "default.names") ;
	if ( ! names_stream  ) 
		for ( int kk=0;kk<number_of_variables_;kk++)
		{
			ostringstream v_stream;
			v_stream << "V_" << kk +1;
			variable_names_.push_back ( v_stream.str() );

		}

	else 
	{
		int ii=0;
		string current_line;
		while( getline( names_stream , current_line, '\n' ) )
		{
			if ( current_line [0] == '/' ||  current_line [0] == '#' || current_line [0] == ' '  )
				continue;

			variable_names_.push_back ( current_line ) ;

		}
		int variable_names_size  = variable_names_.size() ;

		if ( variable_names_.size() != number_of_variables_ )
		{
			cout << "Check number of variables in file " << "default.names" << endl;
			cout << "variable_names_size = " <<  variable_names_size  << endl;
			cout << "number_of_variables = " <<  number_of_variables_ << endl;
			assert (ii == number_of_variables_ );
			exit (1);
		}
	}
}




void     Regression_stepwise::assign_options()
{

	map < string, string  >  options_ ;
	options_ =   Suck_up_options (  option_file_name_);

	Fisher_in_  =  atof ( options_["FISHER_INCLUDE"].c_str() );
	Fisher_out_ =  atof ( options_["FISHER_EXCLUDE"].c_str() );
    tolerance_  =  atof ( options_["TOLERANCE"].     c_str() );

}  

void     Regression_stepwise::print_one_iteration_result ( const string & result_file_name )
{
	ofstream  result_stream ( result_file_name.c_str() );
	if ( ! result_stream )	{	cout << "can't find file " << result_file_name << endl;
		assert (  result_stream );		exit (1);	}

	for (int ii = 0; ii <  number_of_variables_; ii++)
	{
		if ( fabs ( regression_coefficient_[ii] )  < epsilon_float() )
			continue;

		PutVa(ii+1,result_stream ,4, 4,'l');

		PutVa(variable_names_[ii],result_stream ,30, 29,'l');


		PutVaDouble (regression_coefficient_                   [ii],
			result_stream ,10, 5,'r');
		PutVaDouble (standard_errror_of_regression_coefficient_[ii],
			result_stream ,10, 5,'r');

		double Single_var_Fisher_statistics = (regression_coefficient_[ii]/standard_errror_of_regression_coefficient_[ii])*(regression_coefficient_[ii]/standard_errror_of_regression_coefficient_[ii]);
		PutVaDouble (Single_var_Fisher_statistics  ,
			result_stream ,10, 5,'r');

		result_stream << endl;

	}
	
	result_stream << endl;
	result_stream <<  "absolute_term " ;
	PutVaDouble (absolute_term_,result_stream ,10, 5,'l');
	result_stream << endl;

	vector < double > predicted;
	vector < double > experimental;

	if ( task_set_matrix_.size() == 0 )
		return;

	for (int ii=0;ii<number_of_cases_;ii++)
	{
		double sum = absolute_term_;
		for (int jj=0;jj<number_of_variables_ - 1 ;jj++) 
			sum  += task_set_matrix_[ii][jj]*regression_coefficient_[jj];

		

		PutVaDouble (task_set_matrix_[ii][number_of_variables_ - 1],result_stream ,10, 5,'r');
		PutVaDouble (sum,result_stream ,10, 5,'r');
		result_stream << endl;

		predicted.push_back (sum ) ;
		experimental.push_back (task_set_matrix_[ii][number_of_variables_ - 1] ) ;

	}

	double correlation = calculate_correlation (predicted,experimental) ;
	
	result_stream << endl;
	result_stream << "CORRELATION for predicted & experimental: " ;
	PutVaDouble (correlation ,
		result_stream ,10, 5,'r');
	result_stream << endl;

}
void     Regression_stepwise:: fill_up_one_iteration_result ()
{

   static double Minimal_Accuracy = epsilon_float();

   int dependent=number_of_variables_ - 1;

   int  ij=one_dimensional_matrix_index(dependent,dependent,number_of_variables_);
   double ms=su_[ij]/( number_of_cases_- number_of_included_ - 1 );

   double LostSquareSum=su_[ij];

   double rss=d_[dependent]-su_[ij];
   double rms=rss/number_of_included_;

   regression_coefficient_                    .resize (number_of_variables_);
   standard_errror_of_regression_coefficient_ .resize (number_of_variables_);

   absolute_term_ = avsumx_[dependent];

   for( int i=0;i<number_of_variables_;i++) 
   {
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);
     if(su_[ij]<  -Minimal_Accuracy ) 
	 {
       int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
       absolute_term_  -= avsumx_[i]*su_[ij1];
     }
   }

   for(int i=0;i<number_of_variables_;i++)     
   {
     int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);
   
	 if( su_[ij]  < -Minimal_Accuracy ) 
	 {
       regression_coefficient_[i]=su_[ij1];
       standard_errror_of_regression_coefficient_[i]= ms*(-su_[ij]);
       standard_errror_of_regression_coefficient_[i]=
		   ( standard_errror_of_regression_coefficient_[i] > Minimal_Accuracy ) ?  
		        sqrt( standard_errror_of_regression_coefficient_[i]) : -1;  // ** it shows accuracy fault

     }
     else                    regression_coefficient_[i]=0;
   }

}
bool Regression_stepwise::pedantic_selvar (int & FLAG,int & K)
{
	
	vector <double> A = su_;
	vector <double> D = d_;
	int M  = number_of_variables_;
	int N  = number_of_cases_;
	int NP = number_of_included_;
	double TOL = tolerance_;
	double FIN = Fisher_in_;
	double FOUT = Fisher_out_;
	int ID = number_of_variables_ - 1;

	int KP,KN;
	double V;

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	double VN =  - FOUT* A [ one_dimensional_matrix_index(  ID,  ID,  number_of_variables_) ];
	double VP = 0;
	for (int I=0;I<M;I++)
	{
		if ( I == ID ) 
			continue;
		if ( fabs ( A [ one_dimensional_matrix_index(  I,  I, number_of_variables_) ] )  < VERY_SMALL_POSITIVE_VALUE  ) 
			continue;

		int itmp=min(I,ID);
		int jtmp=max(I,ID);

		 V =  A [ one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_) ] *
		      A [ one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_) ] /
		      A [ one_dimensional_matrix_index(  I,     I,     number_of_variables_) ] ;

		if ( V <= VN )
			continue;
		if ( V <   0 )
			goto label2;
		if ( V <= VP ) 
			continue;
		if (  A [ one_dimensional_matrix_index(  I,  I, number_of_variables_) ] / D[I] < TOL )
			continue;
		VP = V;
		KP = I;
		continue;
label2: 
		VN = V;
		KN = I;

	}

	FLAG = 0;
	if ( (N -NP -2)*VP >= FIN* ( A [ one_dimensional_matrix_index(  ID,    ID,    number_of_variables_)] -VP)  )
		FLAG = -1;
	if( -(N -NP -1)*VN <  FOUT*A [ one_dimensional_matrix_index(  ID,    ID,    number_of_variables_) ] )
		FLAG = 1;
	K = KP;
	if (FLAG ==1) 
		K = KN;

	if (FLAG)		return true;
	else            return false;
}

void Regression_stepwise::prepare_particular_solution ()
{
	vector <double> x; x.resize(number_of_variables_);

	//index_of_included_.resize(number_of_variables_);
	index_of_included_.assign(number_of_variables_,0);
		
    int flag,kk,iter=0;
	
    number_of_included_ = 0;
   	while ( pedantic_selvar  (flag,kk) )
	{

		sweep_operator(number_of_variables_,kk,flag,su_,x); 

		number_of_included_		+= -flag;
		index_of_included_[kk]	+= -flag;

		if(++iter > 2*number_of_variables_ )
			break;
    }
 
}
bool Regression_stepwise::select_swept_out_variable (int & flag,int & k)
{
	int  id   = number_of_variables_ - 1;

    double vn,vp,v; 
    int i;
    int ij,ij1;
    int kp,kn;

    ij=one_dimensional_matrix_index(id,id,number_of_variables_);
    vn =(-Fisher_out_*su_[ij]);
    vp= 0;
	for(i=0;i<number_of_variables_;i++)
	{
		ij=one_dimensional_matrix_index(i,i,number_of_variables_);
		if( i !=  id && su_[ij] > epsilon_float() )
		{
			int itmp=min(i,id);
			int jtmp=max(i,id);
			ij1=one_dimensional_matrix_index(itmp,jtmp,number_of_variables_);
			v=su_[ij1]*su_[ij1]/su_[ij];
			if(v>vn)
			{
				if(v <  0)
				{
					vn=v;
					kn=i;
				}
				else
				{
					if(v>vp)
					{
						if( (su_[ij]/d_[i]) > tolerance_)
						{
							vp=v;
							kp=i;
						}
					}
				}
			}
		}
	}

	flag=0;
	ij1=one_dimensional_matrix_index(id,id,number_of_variables_);
	if( (number_of_cases_- number_of_included_-2)*vp    >=  Fisher_in_  * (su_[ij1]-vp) )
		flag=-1;
	if( (-(number_of_cases_-number_of_included_-1)*vn) <=   Fisher_out_ * su_[ij1] )
		flag=1;

	k=kp;

	if(flag==1)		k=kn;

	if ( flag  ) 	return true;
	else 			return false;

}


vector <double> Regression_stepwise::
get_regression_coefficient_and_absolute_term () 
{
	vector < double > full_regression_solution = get_regression_coefficient ();
	full_regression_solution.push_back (absolute_term_); 		

	return  full_regression_solution ;
}
