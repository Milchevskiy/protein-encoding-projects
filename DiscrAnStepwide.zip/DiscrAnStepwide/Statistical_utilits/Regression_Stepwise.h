#pragma warning( disable : 4786 )

#ifndef REGRESSION_STEPWISE_H
#define REGRESSION_STEPWISE_H

#include <string>
#include <vector>	
#include <map>


class Regression_stepwise
{
public:
	Regression_stepwise() {};
	Regression_stepwise( 
		const std::string &data_file_name, 
		const std::string &option_file_name);

	Regression_stepwise( 
		std::vector < std::vector < double> >	task_set_matrix_, 
		const std::string &option_file_name);


	Regression_stepwise (
		const int number_of_cases ,
		const int number_of_variables ,
		std::vector < double> & avsumx , 
		std::vector < double> & su, 
		const std::string &option_file_name);


	int get_number_of_variables () const {return number_of_variables_;};
	int get_number_of_cases     () const {return number_of_cases_;};

	std::vector < int > get_index_of_included   () const {return index_of_included_;};

	std::vector <double>get_original_cross_sum_matrix    () const { return virgin_su_ ;   }
	std::vector <double>get_original_variable_sum_matrix () const { return virgin_avsumx_;}
	
	std::vector <double>get_current_cross_sum_matrix             () const { return su_ ;   }
	std::vector <double>get_current_variable_sum_matrix          () const { return avsumx_;}
	std::vector <double>get_current_diagonal_of_cross_sum_matrix () const { return d_;}

	void print_one_iteration_result ( const std::string & output_file_name );

	std::vector <double> get_regression_coefficient () const {return regression_coefficient_;} 

	std::vector <double> get_regression_coefficient_and_absolute_term () ;

	//std::vector <double> get_regression_coefficient_and_absolute_term () 

private:

	std::string data_file_name_;
	std::string option_file_name_;

	int		number_of_variables_;
	int		number_of_cases_    ;
	int		number_of_included_    ;
	std::vector < int > index_of_included_;


	std::vector < std::vector < double> >	task_set_matrix_;
	std::vector < std::string >			    variable_names_;
	
	std::vector <double> avsumx_;
	std::vector <double> su_;

	std::vector <double> virgin_avsumx_;
	std::vector <double> virgin_su_;
	std::vector <double> d_;




	double absolute_term_;
	std::vector <double> regression_coefficient_;
	std::vector <double> standard_errror_of_regression_coefficient_;


	std::map < std::string, std::string  >      options_ ;
	void   assign_options();         
	double Fisher_in_;
	double Fisher_out_;
    double tolerance_;

    bool select_swept_out_variable (int & flag,int & k); // both of this functions makes the same task
	bool pedantic_selvar           (int & FLAG,int & K); // second one 
	
	void prepare_particular_solution ();

	void fill_up_one_iteration_result ();

// functions are usefull for catching optimal Fisher's value
};


#endif
