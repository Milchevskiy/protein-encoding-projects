#include "Regression_stepwise.h" 
#include "Statistic_general_purpose.h"

#include "../Common/CommonFunc.h"

void     Regression_stepwise:: fill_up_one_iteration_result ()
{

   static double Minimal_Accuracy = epsilon_float();

   int dependent=number_of_variables_ - 1;

   int  ij=one_dimensional_matrix_index(dependent,dependent,number_of_variables_);
   double ms=su_[ij]/( number_of_cases_- number_of_included_ - 1 );

   double LostSquareSum=su_[ij];

   double rss=d_[dependent]-su_[ij];
   double rms=rss/number_of_included_;

   regression_coefficient_                    .resize (number_of_variables_);
   standard_errror_of_regression_coefficient_ .resize (number_of_variables_);

   absolute_term_ = avsumx_[dependent];

   for( int i=0;i<number_of_variables_;i++) 
   {
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);
     if(su_[ij]<  -Minimal_Accuracy ) 
	 {
       int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
       absolute_term_  -= avsumx_[i]*su_[ij1];
     }
   }

   for(i=0;i<number_of_variables_;i++)     
   {
     int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);
   
	 if( su_[ij]  < -Minimal_Accuracy ) 
	 {
       regression_coefficient_[i]=su_[ij1];
       standard_errror_of_regression_coefficient_[i]= ms*(-su_[ij]);
       standard_errror_of_regression_coefficient_[i]=
		   ( standard_errror_of_regression_coefficient_[i] > Minimal_Accuracy ) ?  
		        sqrt( standard_errror_of_regression_coefficient_[i]) : -1;  // ** it shows accuracy fault

     }
     else                    regression_coefficient_[i]=0;
   }

}
