#include "Regression_stepwise.h" 
#include "Statistic_general_purpose.h"
#include "../Common/CommonFunc.h"

#define max(a,b) ((a>=b) ? a : b)
#define min(a,b) ((a <b) ? a : b)

bool Regression_stepwise::select_swept_out_variable (int & flag,int & k)
{
	int  id   = number_of_variables_ - 1;

    double vn,vp,v; 
    int i;
    int ij,ij1;
    int kp,kn;

    ij=one_dimensional_matrix_index(id,id,number_of_variables_);
    vn =(-Fisher_out_*su_[ij]);
    vp= 0;
	for(i=0;i<number_of_variables_;i++)
	{
		ij=one_dimensional_matrix_index(i,i,number_of_variables_);
		if( i !=  id && su_[ij] > epsilon_float() )
		{
			int itmp=min(i,id);
			int jtmp=max(i,id);
			ij1=one_dimensional_matrix_index(itmp,jtmp,number_of_variables_);
			v=su_[ij1]*su_[ij1]/su_[ij];
			if(v>vn)
			{
				if(v <  0)
				{
					vn=v;
					kn=i;
				}
				else
				{
					if(v>vp)
					{
						if( (su_[ij]/d_[i]) > tolerance_)
						{
							vp=v;
							kp=i;
						}
					}
				}
			}
		}
	}

	flag=0;
	ij1=one_dimensional_matrix_index(id,id,number_of_variables_);
	if( (number_of_cases_- number_of_included_-2)*vp    >=  Fisher_in_  * (su_[ij1]-vp) )
		flag=-1;
	if( (-(number_of_cases_-number_of_included_-1)*vn) <=   Fisher_out_ * su_[ij1] )
		flag=1;

	k=kp;

	if(flag==1)		k=kn;

	if ( flag  ) 	return true;
	else 			return false;

}

