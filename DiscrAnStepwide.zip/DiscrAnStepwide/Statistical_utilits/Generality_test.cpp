#pragma warning( disable : 4786 )
//#pragma warning( disable : 4503 )

#include "Generality_test.h"

#include "Regression_stepwise.h" 
#include "../Common/CommonFunc.h"

//#include "../Statistical_utilits.old/wesmacro.h"
//#include "../Statistical_utilits.old/regress.h"

#include "Statistic_general_purpose.h"

#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

	void   util_for_lead_up_cross_sum_matrix_test ( 
		const char * source_file_name,  
		vector < double > & _avsumx, 
		vector < double > & _sumxy ); 

Generality_test::~Generality_test()
{
	cout << "Generality_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}
/*
void Generality_test::one_dimensional_matrix_index_test () 
{
	int wc  = 10;
	int difference  = 0;
	for ( int ii=0; ii< wc; ii++)
	{
		for ( int jj=0; jj< wc; jj++)
		{
			int new_index = one_dimensional_matrix_index (ii,jj,wc);
			int old_index = m_ind                        (ii,jj,wc);
			difference  += abs (new_index  - old_index );
		}
	}

	test( "old and new one_dimensional_matrix_index must be equal",	difference == 0 );
}
*/

void Generality_test::lead_up_cross_sum_matrix_test () 
{
	Regression_stepwise regression_stepwise_ (string ("test.data"), string ("regression_options") );

	vector < double > v_su     = regression_stepwise_.get_original_cross_sum_matrix    ();
	vector < double > v_avsumx = regression_stepwise_.get_original_variable_sum_matrix (); 

	vector < double > old_v_su, old_v_avsumx;	
	util_for_lead_up_cross_sum_matrix_test ("test.data",old_v_avsumx,old_v_su);

	test( "Number of var. for old and new version must be equal ",	
		old_v_avsumx.size() == regression_stepwise_.get_number_of_variables() );

	double difference_su =0,  difference_avsumx= 0;
	for ( int ii=0; ii< old_v_su.size(); ii++ )
		difference_su += fabs (v_su[ii] - old_v_su[ii]);
	for ( int jj=0; jj< old_v_avsumx.size(); jj++ )
		difference_avsumx += fabs (old_v_avsumx[jj] - v_avsumx[jj]) ;

	test( "cross sum matrix for old and new version must be equal ",	difference_su <  epsilon_float() );
	test( "avsumx for old and new version must be equal ",	difference_su <  epsilon_float() );
}


void Generality_test::sweep_matrix_operator_test    ()
{
	Regression_stepwise regression_stepwise_ (string ("test.data"), string ("regression_options") );

	vector < double > current_cross_sum          
		=  regression_stepwise_.get_current_cross_sum_matrix ();
	vector < double > current_variable_sum       
		=  regression_stepwise_.get_current_variable_sum_matrix();
	vector < double > current_diagonal
		=  regression_stepwise_.get_current_diagonal_of_cross_sum_matrix();


	int size_of_cross_sum_matrix = current_cross_sum    .size();
	int size_of_variable_set     = current_variable_sum .size();

	double *sumxy   = new double[size_of_cross_sum_matrix];
	double *avsumx = new double[size_of_variable_set];
	double *d       = new double[size_of_variable_set];
	double *x       = new double[size_of_variable_set];

	for (int ii=0;ii<size_of_cross_sum_matrix;ii++)
		sumxy[ii]  = current_cross_sum[ii];
	
	for ( int ii=0;ii<size_of_variable_set;ii++)
	{
		avsumx[ii]= current_variable_sum[ii];
		d[ii]      = current_diagonal    [ii];
	}


	vector < int > chosen_var_iindex;

	chosen_var_iindex.push_back(2);
	chosen_var_iindex.push_back(3);
	chosen_var_iindex.push_back(5);

	double difference_su =0;
	for ( int kk=0; kk< size_of_cross_sum_matrix; kk++ )
			difference_su += fabs (current_cross_sum[kk] - sumxy[kk]);

	vector < double > auxilary;	auxilary.resize (size_of_variable_set);
	for ( ii =0;ii<chosen_var_iindex.size();ii++) 
	{
		int wc = size_of_variable_set;
		int k  =  chosen_var_iindex [ii];
		int flag = -1;
		lswp            (wc, &k, &flag, sumxy,             x);
		sweep_operator ( wc,  k, flag, current_cross_sum, auxilary);

		for ( int kk=0; kk< size_of_cross_sum_matrix; kk++ )
			difference_su += fabs (current_cross_sum[kk] - sumxy[kk]);

	}

	test( "cross sum matrix for old and new version must be equal ",	difference_su <  epsilon_float() );
	delete [] sumxy; delete [] avsumx; delete [] d; delete [] x;
}
void Generality_test::select_sweep_variables_test        ()
{
	Regression_stepwise regression_stepwise_ (string ("test.data"), string ("regression_options") );

	vector < double > original_cross_sum          
		=  regression_stepwise_.get_original_cross_sum_matrix();
	vector < double > original_variable_sum       
		=  regression_stepwise_.get_original_variable_sum_matrix();
	int number_of_cases     
		= regression_stepwise_.get_number_of_cases();

	int size_of_cross_sum_matrix = original_cross_sum    .size();
	int size_of_variable_set     = original_variable_sum .size();

	double *sumxy   = new double[size_of_cross_sum_matrix];
	double *avsumx =  new double[size_of_variable_set];
	double *d       = new double[size_of_variable_set];
	double *x       = new double[size_of_variable_set];

	for (int ii=0;ii<size_of_cross_sum_matrix;ii++)
		sumxy[ii]  = original_cross_sum[ii];
	
	for (ii=0;ii<size_of_variable_set;ii++)
		avsumx[ii]= original_variable_sum [ii];

	int wcount		= size_of_variable_set;
	int recordnum	= number_of_cases     ;
	int dependent	= size_of_variable_set - 1;

    f_cvmt( recordnum, wcount, avsumx, sumxy, d );
	int npr=lstpwise(wcount,recordnum,dependent,sumxy,avsumx,d,x,1,1) ;

	
	vector < double > current_cross_sum          
		=  regression_stepwise_.get_current_cross_sum_matrix();

	double difference_su =0;
	for ( int kk=0; kk< size_of_cross_sum_matrix; kk++ )
		difference_su += fabs (current_cross_sum[kk] - sumxy[kk]);

	test( "For whole task cross sum matrix for old and new version must be equal ",	difference_su <  epsilon_float() );

	delete [] sumxy;	delete [] avsumx;	delete [] d;	delete [] x;
}


void Generality_test:: fill_up_one_iteration_result      ()
{
	Regression_stepwise regression_stepwise_ (string ("test.data"), string ("regression_options") );
	regression_stepwise_.print_one_iteration_result ("test.res");
}

void Generality_test:: check_index_of_included_filling      ()
{
	Regression_stepwise regression_stepwise_ (string ("test.data"), string ("regression_options") );
	regression_stepwise_.print_one_iteration_result ("test.res");

	vector < int > inedexes = regression_stepwise_.get_index_of_included ();

	int count =0;
	for (int ii=0; ii<inedexes.size();ii++)
	{
//	cout << inedexes[ii] << " " ;
		if ( inedexes[ii] )
			count ++;
	}


	test( "Number of included variables must be equal 8 under current conditions",	count == 8  );

}

void Generality_test:: binary_input_output_test          ()
{

	ifstream  in_text_data_stream ( "test.data",ios::in );
	if ( ! in_text_data_stream )	{	cout << "can't find file " << "test.dat" << endl;
		assert (  in_text_data_stream );		exit (1);	}

	ofstream  out_binary_data_stream ( "test.dat.binary",ios::out | ios::binary );
	if ( ! out_binary_data_stream )	{	cout << "can't find file " << "test.dat.binary" << endl;
		assert (  out_binary_data_stream );		exit (1);	}

	double value; 
	int pre_pointer =0;
	while ( in_text_data_stream >> value) 
	{
		out_binary_data_stream.write((char *) &value, sizeof(double));
		pre_pointer ++;
	}

	in_text_data_stream.close();

	ifstream  in_binary_data_stream ( "test.dat.binary",ios::in | ios::binary );
	if ( ! in_binary_data_stream )	{	cout << "can't find file " << "test.dat.binary" << endl;
		assert (  in_binary_data_stream );		exit (1);	}

	in_text_data_stream.clear(0);
	in_text_data_stream.seekg(0);

	int test = in_text_data_stream.tellg();

	double value_b, difference = 0;
	int pointer = 0;
	while ( in_text_data_stream >> value) 
	{
		char word[10];
		in_binary_data_stream.read(( char *) word,sizeof(double) ); 
		memcpy (&value_b, word ,sizeof(double) ); 
		difference  += fabs( value_b - value) ;
		pointer ++;
	}
}
