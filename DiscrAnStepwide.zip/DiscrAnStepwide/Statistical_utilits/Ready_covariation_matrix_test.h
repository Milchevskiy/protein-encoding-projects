#ifndef READY_COVARIATION_MATRIX_TEST_H
#define READY_COVARIATION_MATRIX_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Common/Simple_test.h"

#endif

#include <string>

class  Ready_covariation_matrix_test: public Simple_test
{
public:
	~Ready_covariation_matrix_test();

    void run()
    {
		single_enough_test ();
		by_external_file_test(); // fix it later
	}
    
	void single_enough_test ();
	void by_external_file_test();
};

#endif