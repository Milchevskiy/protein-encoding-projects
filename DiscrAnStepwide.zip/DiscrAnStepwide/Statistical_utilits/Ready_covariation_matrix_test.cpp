#pragma warning( disable : 4786 )

#include "Ready_covariation_matrix_test.h"

#include "../Common/CommonFunc.h"
#include "../Statistical_utilits/Regression_stepwise.h" 

#include "Statistic_general_purpose.h"

#include <cassert>
#include <iostream>
#include <fstream>

using namespace std;


Ready_covariation_matrix_test::~Ready_covariation_matrix_test()
{
	cout << "Ready_covariation_matrix_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Ready_covariation_matrix_test::
single_enough_test () 
{
	ifstream  data_stream ( "data");
	if ( ! data_stream )	{	cout << "can't find file " << "data" << endl;
		assert (  data_stream  );		exit (1);	}
	
	int number_of_cases ,number_of_variables;

	data_stream >> number_of_cases >> number_of_variables;

	//vector < vector < double> >	task_set_matrix;

	vector <double> avsumx;
	vector <double> su;

	int upper_triange_matrix_size = number_of_variables*(number_of_variables+1)/2;
	avsumx.          resize( number_of_variables );
	su.              resize( upper_triange_matrix_size );

	vector < double > x; 	x.resize ( number_of_variables ); 
	for (int ii=0;ii<number_of_cases;ii++)
	{
		for (int jj=0;jj<number_of_variables;jj++) 
			data_stream >> x[jj];
		supplement_cross_sum_matrix( number_of_variables ,x,  avsumx , su, 1);  

	}

	ofstream  out ( "avsumx_su");
	if ( ! out )	{	cout << "can't create file " << "avsumx_su" << endl;
		assert (  out );		exit (1);	}
	
	out << number_of_variables << " " << upper_triange_matrix_size << " " << number_of_cases << endl;

	for ( ii = 0 ;ii< number_of_variables ;ii++)
		PutVaDouble (avsumx [ii],out,15,6,'l');
	out << endl;

	for ( ii = 0 ;ii< upper_triange_matrix_size ;ii++)
		PutVaDouble (su [ii],out,15,6,'l');
	out << endl;

 
	Regression_stepwise regression_stepwise_ (number_of_cases ,number_of_variables ,avsumx , su, string ("regression_options") );
	vector <double> regression_coefficient = regression_stepwise_.get_regression_coefficient () ;

	for (  ii=0;ii< regression_coefficient .size(); ii++)
		PutVaDouble ( regression_coefficient[ii] ,cout, 10,3,'l');

	cout << endl;


	regression_stepwise_.print_one_iteration_result ("BeBeBe.res");


}


void Ready_covariation_matrix_test::
by_external_file_test() 
{

	ifstream  data_stream ( "avsumx_su");
	if ( ! data_stream )	{	cout << "can't find file " << "avsumx_su" << endl;
		assert (  data_stream  );		exit (1);	}


	int number_of_variables ,upper_triange_matrix_size ,number_of_cases;

	data_stream >> number_of_variables >> upper_triange_matrix_size >> number_of_cases;


	int check_upper_triange_matrix_size = number_of_variables*(number_of_variables+1)/2;
	assert (check_upper_triange_matrix_size == upper_triange_matrix_size ) ;

	vector <double> avsumx;
	vector <double> su;

	avsumx.          resize( number_of_variables );
	su.              resize( upper_triange_matrix_size );

	for ( int  kk=0;kk<number_of_variables;kk++)
		data_stream >> avsumx[kk];


	for (   kk=0;kk<upper_triange_matrix_size;kk++)
		data_stream >> su[kk];


	// 50  1275  8302875
	Regression_stepwise regression_stepwise_ (number_of_cases ,number_of_variables ,avsumx , su, string ("regression_options") );
	vector <double> regression_coefficient = regression_stepwise_.get_regression_coefficient () ;

	for ( int  ii=0;ii< regression_coefficient .size(); ii++)
		PutVaDouble ( regression_coefficient[ii] ,cout, 10,3,'l');

	cout << endl;


	regression_stepwise_.print_one_iteration_result ("by_external_file_test.res");


}