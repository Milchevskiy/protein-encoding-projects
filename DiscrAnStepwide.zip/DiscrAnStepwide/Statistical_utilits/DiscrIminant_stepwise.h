#pragma warning( disable : 4786 )

#ifndef DISCRIMINANT_STEPWISE_H
#define DISCRIMINANT_STEPWISE_H

#include <string>
#include <vector>
#include <map>


class Discriminant_stepwise
{
public:
	Discriminant_stepwise() {};
	Discriminant_stepwise( 
		const std::string &data_file_name, 
		const std::string &option_file_name);

	Discriminant_stepwise::Discriminant_stepwise( 
		const std::string &data_file_name, 
		const std::string &option_file_name,
		const std::string &mandatory_index_file_name);

	int		
		get_number_of_groops        () const { return number_of_groops_   ;  } 
	int		
		get_number_of_variables     () const { return number_of_variables_;  } 
	int		
		get_number_of_cases         () const { return number_of_cases_    ;  } 
	int     
		get_number_of_included      () const { return number_of_included_ ;  } 

	std::vector < std::string > 
		get_variable_names          () const { return variable_names_ ;}

	std::vector <  double >	  
		get_case_variables ( const int ii) const { return task_set_matrix_ [ii]   ;  } 

	int 	  
		get_groop_index_in_data( const int ii) const { return ( int ) task_set_matrix_ [ii][number_of_variables_]   ;  } 


	std::vector < std::vector < double> >  
		get_group_average_value     () const { return group_average_value_; }
    std::vector <  double >	  
		get_average_value           () const { return average_value_;} 
	std::vector <  double >	  
		get_cross_marix             () const { return cross_marix_;  } 
	std::vector <  double >	  
		get_intra_group_cross_marix () const { return intra_group_cross_marix_;  }  

	std::vector < std::vector < double> >   
		get_group_classifying_coefficient     () const { return group_classifying_coefficient_   ;  };
	std::vector  < double >                 
		get_constant_of_classifying_function  () const { return constant_of_classifying_function_;  };

	std::vector <  double >	                
		posterior_probability_to_be_in_each_group ( std::vector < double > & current_case );

	void 	print_orthodox_result ();
	void 	print_prediction_parameters ();

	void push_in_mandatory_variables ();


private:

	void assign_options                        ();
	void assign_names                          ();

	void handle_source_data                    (); // getting source data file and filling up task_set_matrix_
    void making_intra_group_covariation_matrix ();
	bool pedantic_selvar                       (int & FLAG,int & K);
	void prepare_particular_solution           ();
	void pull_out_discrimination_constants     ();

	void get_apriori_class_content_tare		   ();

	std::map < std::string, std::string  >      options_ ;

	std::string data_file_name_;
	std::string option_file_name_;

	std::string mandatory_index_file_name_;

	std::vector < int > mandatory_index_ ;
	std::vector < int > read_mandatory_index ();


	std::vector  < double >					read_apriori_class_content ();

	int		number_of_groops_;
	int		number_of_variables_;
	int		number_of_cases_    ;
	int		number_of_included_ ;

	double	tolerance_;
	double	Fisher_in_;
	double	Fisher_out_;

	std::vector < std::vector < double> >	task_set_matrix_; // last value in each case is groop number
	std::vector < std::string >			    variable_names_;

	std::vector < std::vector < double> >   group_average_value_  ;
	std::vector < int >			            case_group_index_    ;

	std::vector <  double >	                intra_group_cross_marix_;
	std::vector <  double >	                intra_group_cross_marix_diagonal_ ;
	std::vector <  double >	                cross_marix_;

	std::vector <  double >	                average_value_ ;

	std::vector < std::vector < double> >   group_classifying_coefficient_  ;
	std::vector  < double >                 constant_of_classifying_function_  ;

	std::vector  < double >					apriori_class_content_tare_;

	
};

#endif

