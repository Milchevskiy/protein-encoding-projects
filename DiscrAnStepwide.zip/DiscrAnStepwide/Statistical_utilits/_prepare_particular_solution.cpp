#include "Regression_stepwise.h" 
#include "Statistic_general_purpose.h"

using namespace std;

void Regression_stepwise::prepare_particular_solution ()
{
	vector <double> x; x.resize(number_of_variables_);
	
    int flag,kk,iter=0;
	
    number_of_included_ = 0;
   // while ( select_swept_out_variable (flag,kk) )
	while ( pedantic_selvar  (flag,kk) )
	{
		sweep_operator(number_of_variables_,kk,flag,su_,x); 

		number_of_included_ += -flag;

		if(++iter > 2*number_of_variables_ )
			break;
    }
 
}

