#include "Discriminant_stepwise.h" 
#include "Statistic_general_purpose.h"

#include "../Common/CommonFunc.h"

#include <fstream>
#include <iostream>
#include <cassert>
#include <sstream>
 
using namespace std;


Discriminant_stepwise::Discriminant_stepwise( 
	const string &data_file_name, 
	const string &option_file_name,
	const string &mandatory_index_file_name):
data_file_name_   (data_file_name), 
option_file_name_ (option_file_name),
mandatory_index_file_name_ (mandatory_index_file_name),
number_of_included_ (0)
{
	assign_options     ();



	handle_source_data ();

	//get_apriori_class_content_tare  (); 
	
	assign_names       ();

	mandatory_index_ = read_mandatory_index ();
/*
	group_average_value_                 .resize(number_of_groops_);
	case_group_index_                    .resize(number_of_groops_);
	for (int ii=0;ii<number_of_groops_;ii++)
		group_average_value_[ii].resize(number_of_variables_) ;


	int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;
	intra_group_cross_marix_             .resize ( upper_triange_matrix_size );
	cross_marix_                         .resize ( upper_triange_matrix_size );

	average_value_                       .resize (number_of_variables_);
	intra_group_cross_marix_diagonal_    .resize (number_of_variables_);
*/
	making_intra_group_covariation_matrix ();

	push_in_mandatory_variables (  );

	prepare_particular_solution ();

	pull_out_discrimination_constants ();

}

vector < int > Discriminant_stepwise::
read_mandatory_index () 
{

	ifstream  m_stream ( mandatory_index_file_name_.c_str() );
	if ( ! m_stream )	{	cout << "can't find file " << mandatory_index_file_name_<< endl;
		assert (  m_stream );		exit (1);	}

	vector < int > mandatory_index;

	int current_value;
	while ( m_stream >> current_value ) 
		mandatory_index.push_back ( current_value );

	return mandatory_index;
}

void Discriminant_stepwise::
push_in_mandatory_variables ()
{

	vector <double> x; x.resize(number_of_variables_);
	int flag = -1; 

	int size = mandatory_index_.size();

	for (int kk=0; kk< size;kk++)
	{
		sweep_operator(number_of_variables_,mandatory_index_[kk],flag,intra_group_cross_marix_,x); 
		sweep_operator(number_of_variables_,mandatory_index_[kk],flag,cross_marix_            ,x); 

		number_of_included_ += -flag;
	}

}

Discriminant_stepwise::Discriminant_stepwise( 
	const string &data_file_name, 
	const string &option_file_name ):

data_file_name_   (data_file_name), 
option_file_name_ (option_file_name),
number_of_included_ (0)
{
	assign_options     ();

	handle_source_data ();

	get_apriori_class_content_tare  (); 
	
	assign_names       ();
/*
	group_average_value_                 .resize(number_of_groops_);
	case_group_index_                    .resize(number_of_groops_);
	for (int ii=0;ii<number_of_groops_;ii++)
		group_average_value_[ii].resize(number_of_variables_) ;


	int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;
	intra_group_cross_marix_             .resize ( upper_triange_matrix_size );
	cross_marix_                         .resize ( upper_triange_matrix_size );

	average_value_                       .resize (number_of_variables_);
	intra_group_cross_marix_diagonal_    .resize (number_of_variables_);
*/
	making_intra_group_covariation_matrix ();
	prepare_particular_solution ();

	pull_out_discrimination_constants ();

}

//*****************************
// ������� ������� ������ ����������� ���� ������������ ������������ 
// � ����� ������. ���� prepare_particular_solution() 
//*****************************

void Discriminant_stepwise::handle_source_data ()
{
	ifstream  data_stream ( data_file_name_.c_str() );
	if ( ! data_stream )	{	cout << "can't find file " << data_file_name_ << endl;
		assert (  data_stream  );		exit (1);	}

	string current_line;
	getline( data_stream , current_line, '\n' );
	{
		istringstream ist (current_line);
		ist >> number_of_groops_ >> number_of_cases_ >> number_of_variables_;

		group_average_value_                 .resize(number_of_groops_);
		case_group_index_                    .resize(number_of_groops_);
		for (int ii=0;ii<number_of_groops_;ii++)
			group_average_value_[ii].resize(number_of_variables_) ;


		int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;
		intra_group_cross_marix_             .resize ( upper_triange_matrix_size );
		cross_marix_                         .resize ( upper_triange_matrix_size );

		average_value_                       .resize (number_of_variables_);
		intra_group_cross_marix_diagonal_    .resize (number_of_variables_);

	}


	apriori_class_content_tare_.resize( number_of_groops_ ) ;

	int count =0;
	while( getline( data_stream , current_line, '\n' ) )
	{

		int  current_group_number;
		istringstream ist (current_line);
		ist >> current_group_number;

		apriori_class_content_tare_ [ current_group_number ]  += 1;

		double value ;
		vector < double > current_values;

		int check_index = 0;
		while ( ist >> value ) 
		{
			current_values.push_back( value );
			check_index ++;
		}
		count ++;
//		cout << count <<  " " << value << endl;
		if ( (count % 1000  ) == 0 )
			cout << count <<  " " << value << endl;

		if ( check_index !=  number_of_variables_  ) 
		{
			cout << "check_index: "  << check_index << " number_of_variables_: " << number_of_variables_  << endl; 
			int dd;
			cin >> dd;
		}

		assert ( check_index ==  number_of_variables_  );

		current_values.push_back (current_group_number);

		//task_set_matrix_.push_back (current_values);
		
		int group_index = current_values[number_of_variables_];
		making_intra_group_covariation_matrix_one_step (
			number_of_variables_, current_values, group_average_value_[group_index]  ,
	        case_group_index_[group_index], intra_group_cross_marix_);

			
	}

	for ( int ii=0;ii< number_of_groops_; ii++ ) 
		apriori_class_content_tare_ [ii] /= count;

	data_stream.close();
}


void Discriminant_stepwise::making_intra_group_covariation_matrix ()
{

	/*
	for ( int ii =0; ii< number_of_cases_; ii++ )
	{
		int group_index = task_set_matrix_[ii][number_of_variables_];
		making_intra_group_covariation_matrix_one_step (
			number_of_variables_, task_set_matrix_[ii], group_average_value_[group_index]  ,
	        case_group_index_[group_index], intra_group_cross_marix_);

	}
	*/
	
	for ( int kk =0; kk< number_of_variables_; kk++ )
	{
		for ( int ii =0; ii< number_of_groops_; ii++ )
		{
			average_value_ [kk] +=  case_group_index_[ii]*group_average_value_[ii][kk];
		}
		average_value_ [kk] /= number_of_cases_;
	}
	

	for ( int    ii=0;ii<number_of_variables_;ii++ )
	{
		for (int jj=ii; jj<number_of_variables_;jj++)
		{
			int index = one_dimensional_matrix_index (ii,jj,number_of_variables_); 
			cross_marix_[index]  =	intra_group_cross_marix_[ index ] ;

			for (int kk=0;kk<number_of_groops_;kk++) 
			{
			
				cross_marix_[index]  +=  
					case_group_index_[kk]*( group_average_value_[kk][ii] - average_value_[ii] ) * ( group_average_value_[kk][jj] - average_value_[jj] );
			}
		}
	}
	for (int ii=0;ii<number_of_variables_;ii++ )
	{
		int index = one_dimensional_matrix_index (ii,ii,number_of_variables_); 
		intra_group_cross_marix_diagonal_[ii] = intra_group_cross_marix_[ index ];
	}

}



bool Discriminant_stepwise::pedantic_selvar (int & FLAG,int & K)
{

	vector <double> T = cross_marix_;
	vector <double> W = intra_group_cross_marix_;
	vector <double> D = intra_group_cross_marix_diagonal_;
	int M  = number_of_variables_;
	int N  = number_of_cases_;
	int NP = number_of_included_;
	int NQ = number_of_groops_;
	double TOL  = tolerance_;
	double FIN  = Fisher_in_;
	double FOUT = Fisher_out_;


	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	double VI = NQ*FOUT + 1;
	double VO = 1.0;

	double V;
	int KO,KI;

	for (int I=0;I<M;I++)
	{
		int index = one_dimensional_matrix_index(  I,  I, number_of_variables_) ;
		if ( fabs ( T [ index ] )  < VERY_SMALL_POSITIVE_VALUE  ) 
			continue;
		
		V= W[index]/T[index];
		
		if ( V >= VI )
			continue;

		if ( W[index] < 0 ) // fix < VERY_SMALL_POSITIVE_VALUE
			goto label2;

		if ( W[index]/D[I] < TOL )
			continue;

		if ( V >= VO ) 
			continue;

		VO = V;
		KO = I;
		continue;
label2: 
		VI = V;
		KI = I;
	}
	FLAG = 0;

	if ( ((1-VO)/VO) * (N-NP-NQ)/(NQ-1) >= FIN  ) 
		FLAG = -1;
	if ( (VI-1)*(N-NP-NQ+1)/(NQ-1) < FOUT)
		FLAG = 1;
	
	K = KO;

	if (FLAG == 1) 
		K = KI;

	if (FLAG)		return true;
	else            return false;
}


void Discriminant_stepwise::prepare_particular_solution ()
{
	vector <double> x; x.resize(number_of_variables_);
	
    int flag,kk,iter=0;
	
   // number_of_included_ = 0;
   	while ( pedantic_selvar  (flag,kk) )
	{
		sweep_operator(number_of_variables_,kk,flag,intra_group_cross_marix_,x); 
		sweep_operator(number_of_variables_,kk,flag,cross_marix_            ,x); 

		number_of_included_ += -flag;

		if(++iter > 2*number_of_variables_ )
			break;
    }
 
}

void     Discriminant_stepwise::assign_options()
{

	map < string, string  >  options_ ;
	options_ =   Suck_up_options (  option_file_name_);

	Fisher_in_  =  atof ( options_["FISHER_INCLUDE"].c_str() );
	Fisher_out_ =  atof ( options_["FISHER_EXCLUDE"].c_str() );
    tolerance_  =  atof ( options_["TOLERANCE"].     c_str() );

}  
void	 Discriminant_stepwise::assign_names                          ()
{

	string names_file_name = new_extension_file_name (data_file_name_, "names" );
	ifstream  names_stream ( names_file_name.c_str() );


	

	if ( ! names_stream )	
	{	
		cout << "REMEMBER! can't find file " << names_file_name << endl;
		variable_names_.resize (number_of_variables_);

		for (int ii=0;ii<number_of_variables_;ii++)
		{
			{
				ostringstream ost ;
				ost << "Variable_" << ii+1;

				variable_names_[ii] = ost.str();
			}
		}
	}

	else 
	{
		int ii=0;
		string current_line;
		while( getline( names_stream , current_line, '\n' ) )
		{
			if ( current_line [0] == '/' ||  current_line [0] == '#' || current_line [0] == ' '  )
				continue;

			variable_names_.push_back ( current_line ) ;

		}
		int variable_names_size  = variable_names_.size() ;

		if ( variable_names_.size() != number_of_variables_ )
		{
			cout << "Check number of variables in file " << names_file_name << endl;
			cout << "variable_names_size = " <<  variable_names_size  << endl;
			cout << "number_of_variables = " <<  number_of_variables_ << endl;
			assert (ii == number_of_variables_ );
			exit (1);
		}
	}
}

void     Discriminant_stepwise::pull_out_discrimination_constants()
{

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	group_classifying_coefficient_.resize(number_of_variables_);
	for (int ii=0;ii<number_of_variables_;ii++)
		group_classifying_coefficient_[ii].resize(number_of_groops_) ;


	for (int ii=0;ii<number_of_variables_;ii++)
	{
		int index = one_dimensional_matrix_index(  ii,  ii, number_of_variables_) ;
		if ( intra_group_cross_marix_ [index]  >  -VERY_SMALL_POSITIVE_VALUE )
			continue;

		for ( int gg=0;gg<number_of_groops_;gg++)
		{
			for ( int jj=0;jj<number_of_variables_;jj++)
			{
									double  test = group_classifying_coefficient_[ii][gg];

				int index = one_dimensional_matrix_index(  jj,  jj, number_of_variables_) ;
				if ( intra_group_cross_marix_ [index]  >  -VERY_SMALL_POSITIVE_VALUE )
					continue;

				index = one_dimensional_matrix_index(  ii,  jj, number_of_variables_) ;
				group_classifying_coefficient_[ii][gg] +=  intra_group_cross_marix_ [index] * group_average_value_ [gg][jj];
			}
		}
	}

	double Const = number_of_groops_ - number_of_cases_ ;
	for (int ii=0;ii<number_of_variables_;ii++)
	{
//		int index = one_dimensional_matrix_index(  ii,  ii, number_of_variables_) ;
//		if ( intra_group_cross_marix_ [index]  >  -VERY_SMALL_POSITIVE_VALUE )
//			continue;

		for ( int gg=0;gg<number_of_groops_;gg++)
			group_classifying_coefficient_[ii][gg] *= Const;
	}


	//fix- move it to constructor
	constant_of_classifying_function_.resize(number_of_groops_);  

	for ( int gg=0;gg<number_of_groops_;gg++)
	{
		for ( int jj=0;jj<number_of_variables_;jj++)
		{
			int index = one_dimensional_matrix_index(  jj,  jj, number_of_variables_) ;
			if ( intra_group_cross_marix_ [index]  >  -VERY_SMALL_POSITIVE_VALUE )
				continue;
			constant_of_classifying_function_[gg] -= group_average_value_ [gg][jj]*group_classifying_coefficient_[jj][gg]/2;
		}
	}
}

vector <  double >	Discriminant_stepwise::
posterior_probability_to_be_in_each_group ( vector < double > & current_case )
{

	vector < double > current_classifying_function;
	current_classifying_function.resize(number_of_groops_);

	vector < double > current_probability;
	current_probability.resize(number_of_groops_);


	for ( int hh=0; hh< number_of_groops_;hh++)
	{
		current_classifying_function [hh]  = constant_of_classifying_function_[hh];
		for (int ii=0; ii < number_of_variables_;ii++)
		{
			current_classifying_function [hh] += current_case [ii] * group_classifying_coefficient_[ii][hh];
		}
	}


	for ( int hh=0; hh< number_of_groops_;hh++)
	{
		double subsidiary_sum =0.0;
		for ( int kk=0; kk< number_of_groops_;kk++)
		{
			/*general mode */
			//subsidiary_sum += exp (current_classifying_function [kk] - current_classifying_function [hh]);

		// taking into consideration class content
			double power_value =  apriori_class_content_tare_[kk] + current_classifying_function [kk] 
			                    - apriori_class_content_tare_[hh] - current_classifying_function [hh] ;

			subsidiary_sum += exp ( power_value );
		}
			                       

			current_probability[hh] = 1/subsidiary_sum ;

	}


	return current_probability;

}

void 	Discriminant_stepwise::
print_orthodox_result ()
{
	string result_file_name = new_extension_file_name (data_file_name_,"orthodox_result");

	ofstream  out ( result_file_name.c_str() );
	if ( ! out)	{	cout << "can't create file " << result_file_name << endl;
		assert (  out );		exit (1);	}


	string significant_variables_file_name = new_extension_file_name (data_file_name_,"var_significant");
	ofstream  vs_out ( significant_variables_file_name .c_str() );
	if ( ! vs_out )	{	cout << "can't create file " << significant_variables_file_name << endl;
		assert (  vs_out );		exit (1);	}

	vector <double> T = cross_marix_;
	vector <double> W = intra_group_cross_marix_;
	int N  = number_of_cases_;
	int NP = number_of_included_;
	int NQ = number_of_groops_;

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	for (int ii=0;ii<number_of_variables_;ii++)
	{
		int index = one_dimensional_matrix_index(  ii,  ii, number_of_variables_) ;
		if ( W [index] < (-1)*VERY_SMALL_POSITIVE_VALUE   )
		{
			double Fisher_exclusion = (( W [index] - T [index]) / T [index] ) * (N-NP-NQ)/((double)(NQ-1)) ;

			PutVaDouble (Fisher_exclusion,vs_out,8, 3,'r');
			PutVa( variable_names_ [ii],vs_out,10, 8,'r');
			vs_out << endl;

		}
	}



/*
	out << endl << "Group classifying coefficients" << endl;
	for (int ii=0;ii<number_of_variables_;ii++)
	{
		PutVa( variable_names_ [ii],out,10, 8,'r');
		PutVa(ii,out,5, 3,'r');

		for ( int gg=0;gg<number_of_groops_;gg++)
		{
			PutVaDouble (group_classifying_coefficient_[ii][gg],out,8, 3,'r');
		}
		out << endl;
	}


	out << "Constants of classifying functions " << endl;
	for ( int gg=0;gg<number_of_groops_;gg++)
		PutVaDouble (constant_of_classifying_function_[gg],out,8, 3,'r');




   out << endl << "average values in groops" << endl;
   for ( ii=0;ii<number_of_variables_;ii++)
   {
	   for ( int gg=0;gg<number_of_groops_;gg++)
	   {
		   PutVaDouble (group_average_value_[gg][ii],out,8, 3,'r');
	   }
	   out << "   ";
   }
   

   out << endl << "average_values " << endl;
   for ( ii=0;ii<number_of_variables_;ii++)
   {
	   PutVaDouble (average_value_[ii],out,8, 3,'r');
   }

*/

	//out << endl << endl << "probabilitie to be in groops" << endl;

	out << number_of_groops_ << "  " << number_of_cases_ << endl;

	ifstream  data_stream ( data_file_name_.c_str() );
	if ( ! data_stream )	{	cout << "can't find file " << data_file_name_ << endl;
		assert (  data_stream  );		exit (1);	}
	string current_line;
	getline( data_stream , current_line, '\n' );




	int count =0;
	while( getline( data_stream , current_line, '\n' ) )
	{

		double current_group_number;
		istringstream ist (current_line);
		ist >> current_group_number;

		double value ;
		vector < double > current_values;

		int check_index = 0;
		while ( ist >> value ) 
		{
			current_values.push_back( value );
			check_index ++;
		}

		if ( (count % 1000  ) == 0 )
			cout << count <<  "++ " << value <<  endl;

		assert ( check_index ==  number_of_variables_  );
		current_values.push_back (current_group_number);

			//cout << count << " " ;

		vector < double > probabilities = posterior_probability_to_be_in_each_group ( current_values );
			//cout <<  endl;

	//	int group_index = get_groop_index_in_data(count);
		int group_index = current_values[number_of_variables_];

		PutVa 	(group_index ,out,5, 3,'l');

		for ( int gg=0;gg<number_of_groops_;gg++)
		{
			PutVaDouble (probabilities[gg],out,9, 5,'r'); out << " ";
		}

		out << endl;

		count ++;
	}
}


void 	Discriminant_stepwise::
print_prediction_parameters ()
{
 
	string result_file_name = new_extension_file_name (data_file_name_,"prediction_template");
	ofstream  out ( result_file_name.c_str() );
	if ( ! out)	{	cout << "can't create file " << result_file_name << endl;
		assert (  out );		exit (1);	}

//	out << "NUMBER OF GROUPS" << endl;
	PutVa 	(number_of_groops_,out,10, 0,'l');			out << endl ;
//	out << endl << "NUMBER OF VARIABLES" << endl;
	PutVa 	(number_of_variables_,out,10, 0,'l');		out << endl ;
//	out << endl ;

//	out << "CONTENT for classes" << endl;	
	for ( int hh=0; hh< number_of_groops_;hh++)
		PutVaDouble  	(apriori_class_content_tare_[hh],out,25, 10,'l');
	out << endl ;

	
//	out << "CONSTANTS OF CLASSIFYING FUNCTIONS" << endl;
	for (int hh=0; hh< number_of_groops_;hh++)
		PutVaDouble  	(constant_of_classifying_function_[hh],out,25, 10,'l');
	out << endl ;



//	out << "GROUP CLASSIFYING COEFFICIENTS" << endl;


	for (int hh=0; hh< number_of_groops_;hh++)
	{
		for (int ii=0; ii < number_of_variables_;ii++)
			PutVaDouble 	(group_classifying_coefficient_[ii][hh],out,25, 10,'l');

		out << endl ;
	}
}

void 	Discriminant_stepwise::
get_apriori_class_content_tare  ()
{
	string source_file_name = new_extension_file_name ( data_file_name_ , "class_occurence" );

	ifstream  s_stream ( source_file_name .c_str() );
	if ( ! s_stream )	{	cout << "can't find file " << source_file_name << endl;
		assert (  s_stream );		exit (1);	}


	//apriori_class_content_tare_.resize( number_of_cases_  ) ;
	vector < double > tmp_vector;

	double d_value;
	while ( s_stream >> d_value ) 
		tmp_vector.push_back ( d_value ) ;

	assert ( tmp_vector.size() == number_of_groops_ ) ;

	if ( tmp_vector.size() != number_of_groops_ ) 
	{
		cout << "Check number of values in " << data_file_name_ << ".class_occurence file" << endl;
		exit (1);
	}

	apriori_class_content_tare_.resize( number_of_groops_ ) ;
	for ( int ii=0; ii< number_of_groops_;ii++ )
		apriori_class_content_tare_[ii] = log ( tmp_vector [ii] ) ;

}