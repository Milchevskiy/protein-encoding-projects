#include "array_max_value_index.h"


int array_max_value_index ( 
	const double *current_probability, 
	const int number_of_groops )
{

	double	best_prob = -1;
	int		best_index = -1;
	for (int ii=0;ii<number_of_groops;ii++)
	{
		if ( current_probability[ii] >  best_prob ) 
		{
			best_prob = current_probability [ii] ;
			best_index = ii;
		}
	}

	return best_index;
}

