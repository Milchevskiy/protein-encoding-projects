#ifndef TASKSET_H
#define TASKSET_H

#include <string>
#include <fstream>
#include <map>

using namespace std; 

string 	taskset_get_path	() ;

void  	taskset_get_option	( 
			ifstream & parm_stream, 
			map <string, string> & options);

#endif
