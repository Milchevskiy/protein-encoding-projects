#pragma warning( disable : 4786 )

#include "Sheduler.h"

Sheduler *Handle_option ( int argc,char  **argv )
{
		string data_file_name = string ( argv[1] );
		string option_file_name = "dia_subtle.option";
		string Fisher_for_single_calc  = "***";


		for ( int ii=1; ii< argc ; ii++ )
		{
			if (argv[ii][0] == '-')
			{
				switch ( argv[ii][1] )
				{
					case 'F': case 'f':
						Fisher_for_single_calc	= string ( argv[ii] + 2 ); 		break;
					case 'O': case 'o':
						option_file_name		= string ( argv[ii] + 2 );		break;
				}
			}
		}

		Sheduler *task_option		= new Sheduler     ( option_file_name );

	//	task_option->add_extern_item ( string("DATA_FILE_NAME"), string( argv[1] ) );
        string aaa = string("DATA_FILE_NAME");         string bbb = string( argv[1]);

        task_option->add_key_meaning_record ( aaa,bbb );
		if ( Fisher_for_single_calc != "***" )
		{
//	task_option->add_extern_item (string ("RUN_MODE") ,string ("SINGLE_CALCULATION") );
            aaa=string("RUN_MODE");      bbb=string("SINGLE_CALCULATION");
            task_option->add_key_meaning_record (aaa ,bbb );
            aaa=string("FISHER_FOR_SINGLE_CALC");      //bbb=string("SINGLE_CALCULATION");

			task_option->add_key_meaning_record (aaa,Fisher_for_single_calc);
		}


	//	string protocol_file_name = new_extension_file_name ()
	//	task_option->add_extern_item (string ("PROTOCOL_FILE"),Fisher_for_single_calc);

	//	PROTOCOL_FILE

		return task_option;
}
