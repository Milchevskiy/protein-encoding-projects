#include "../Statistical_utilits/Statistic_general_purpose.h"
#include <cstdlib>
#include "../Common/CommonFunc.h"



void da_covar_addition
(	const int wcount,
	double *current_values,
	double *group_average_value,
	int  & case_group_index,
	double	*marix_w)
{

	double *new_group_average_value = new double [wcount];


//	vector < double > new_group_average_value = group_average_value;
//	memcpy (new_group_average_value ,group_average_value,wcount*sizeof(double));

	case_group_index ++;

	for ( int ii=0;ii<wcount;ii++ )
		new_group_average_value[ii]  = ( ( case_group_index - 1 ) * group_average_value[ii] + current_values[ii] ) / case_group_index;

	for (  int   ii=0;ii<wcount;ii++ )
		for (int jj=ii; jj<wcount;jj++)
			marix_w[ one_dimensional_matrix_index (ii,jj,wcount) ] += ( current_values[ii] - group_average_value[ii] ) * ( current_values[jj] - new_group_average_value[jj] );

//	group_average_value = new_group_average_value;
	memcpy (group_average_value,new_group_average_value,wcount*sizeof(double));

	delete [] new_group_average_value;

}




void da_covar_subtraction
(	const int wcount,
	double *current_values,
	double *group_average_value,
	int  & case_group_index,
	double	*marix_w )
{

	double *prev_group_average_value = new double [wcount];

	for ( int ii=0;ii<wcount;ii++ )
		prev_group_average_value[ii]  = ( case_group_index * group_average_value[ii] - current_values[ii] ) / ( case_group_index -1 );

	for ( int    ii=0;ii<wcount;ii++ )
		for (int jj=ii; jj<wcount;jj++)
			marix_w[ one_dimensional_matrix_index (ii,jj,wcount) ] -= ( current_values[ii] - prev_group_average_value[ii] ) * ( current_values[jj] - group_average_value[jj] );


	memcpy (group_average_value,prev_group_average_value,wcount*sizeof(double));
	delete [] prev_group_average_value ;


	case_group_index --;

}

