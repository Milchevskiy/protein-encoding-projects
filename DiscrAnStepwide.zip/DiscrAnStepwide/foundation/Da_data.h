#ifndef DA_DATA_H
#define DA_DATA_H

#include <string>
#include <vector>
#include <fstream>

using namespace std;

class Sheduler;


class Da_data
{
public:

	Da_data(  Sheduler	*options );
	~Da_data() ;

	bool 	get_record ( 
		const int record_index, 
		double *current_variables, 
		int *current_group_number );

	int number_of_groops	() const { return number_of_groops_; }
	int number_of_variables () const { return number_of_variables_;  }

	int		*case_group_index()					const { 
		return case_group_index_; }
	double	*group_average_value(const int ii)	const { return group_average_value_[ii]; }
	double	*intra_group_cross_marix()			const { return intra_group_cross_marix_; }

	void show_data_as_txt_file ( const string & show_text_file);

	int number_of_record () const { return number_of_record_ ;}

	void squeeze_database () ;

	void prepare_squeeze_record (
		const int record_index, 
		const vector < int > &squeeze_index,
		double *current_values,
		double *squeeze_values,
		int &group_index );

private:

	void prepare_cross_sum_data ();
	void suck_up_cross_sum_data ();


	//void squeeze_database () ;
	vector < int > 	get_squeeze_index ();

	void make_squeeze_database (); 



	Sheduler	*options_; 

	string		binary_file_name_;
	ifstream	binary_source_stream_;

	void convert_txt_to_binary ( const string & data_file_name);
	void allocate_arrays ();

	int number_of_groops_;
	int number_of_variables_;

	int number_of_record_;

	int		*case_group_index_;
	double  *intra_group_cross_marix_;
	double  **group_average_value_;

	int upper_triange_matrix_size_;

	int initial_address_shift_; 

};

// binary file format
//
// 	number_of_groops_,		sizeof (int)  );
//	number_of_variables_,	sizeof (int)  );
//
// *** futher each records : 
//
// current_values,	number_of_variables_*sizeof (double) & current_group_number stored as double 
//
//

#endif

