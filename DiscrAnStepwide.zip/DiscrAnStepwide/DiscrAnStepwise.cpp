#include <string>
#include <fstream>
#include <iostream>

#include "foundation/Sheduler.h"
#include "foundation/Da_solution.h"
#include "Common/CommonFunc.h"

using namespace std;

ofstream log_stream;

void show_usage () ;

int  main(int argc,char  **argv)
{
	string  output_file ("log");
	log_stream.open (output_file.c_str()  );

	if (argc == 1)
		show_usage ();
	else
	{
	    string key, value;

        Sheduler *task_option		= new Sheduler ();

/// SETTING GENERAL PARAMETERS SPECIFIC TO THE MODE SINGLE_CALCULATION
        key=string("RUN_MODE");      value=string("SINGLE_CALCULATION");
        task_option->add_key_meaning_record (key ,value );

        key=string("INPUT_FILE_FORMAT");    value=string("TXT");
        task_option->add_key_meaning_record (key ,value );

        key=string("IS_CROSSUM_YET");      value=string("NO");
        task_option->add_key_meaning_record (key ,value );

		key=string("TOLERANCE"); value=string("0.1");     /// 0.1 value is suitable for the vast majority of cases
		task_option->add_key_meaning_record (key ,value );
///*********************************************************************


        string Fisher_for_single_calc;

        for ( int ii=1; ii< argc ; ii++ )
		{
			if (argv[ii][0] == '-')
			{
				switch ( argv[ii][1] )
				{
					case 'F': case 'f':
						Fisher_for_single_calc	= string ( argv[ii] + 2 ); 		break;
				}
			}
		}
/// SETTING PARAMETERS FROM THE COMMAND LINE
        key=string("DATA_FILE_NAME");      value=string(argv[1]);
        task_option->add_key_meaning_record (key ,value );

		key=string("FISHER_FOR_SINGLE_CALC"); value=Fisher_for_single_calc;
		task_option->add_key_meaning_record (key ,value );

		Da_solution	das (task_option);
        das.single_calculation ();
///******************************************

		delete task_option;
	}
}
void show_usage ()
{

    cout << "USAGE:\t\t DiscrAnStepwise [data_file_name] -f[Fisher statistic threshold]" << endl << endl;
    cout << "EXAMPLE: \t DiscrAnStepwise ex.dat -f5" << endl << endl;


    cout << "For the given example, the program will create files:" << endl;
    cout << "\t1) file containing significant predictors \t\t\t(ex.single_calculation_var_significant)" << endl;
    cout << "\t2) Prediction results as an confusion matrix \t\t\t(ex.single_calculation_PREDICTION_TABLE )" << endl;
    cout << "\t3) Prediction probabilities for each class in learning sample \t(ex.single_calculation_orthodox) " << endl;

}
