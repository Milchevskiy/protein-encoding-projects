#include "pb16_to_index.h"
#include <cassert>
#include <iostream>
#include <string>


int pb16_to_index ( const char aa )
{
	static	map <char, int> aa_index = set_index_by_pb16();
	if ( aa_index.find(aa) != aa_index.end()  )
	{
        int index = aa_index  [ aa  ];
        return  index;
    }

	else
	{
//		assert(0);
		return -1;
	}

}

map <char, int>  set_index_by_pb16()
{
	map < char, int >  aa_index ;

    aa_index  [  'A'  ] = 0  ;
    aa_index  [  'B'  ] = 1  ;
    aa_index  [  'C'  ] = 2  ;
    aa_index  [  'D'  ] = 3  ;
    aa_index  [  'E'  ] = 4  ;
    aa_index  [  'F'  ] = 5  ;
    aa_index  [  'G'  ] = 6  ;
    aa_index  [  'H'  ] = 7  ;
    aa_index  [  'I'  ] = 8  ;
    aa_index  [  'J'  ] = 9  ;
    aa_index  [  'K'  ] = 10  ;
    aa_index  [  'L'  ] = 11  ;
    aa_index  [  'M'  ] = 12  ;
    aa_index  [  'N'  ] = 13  ;
    aa_index  [  'O'  ] = 14  ;
    aa_index  [  'P'  ] = 15  ;
    aa_index  [  'X'  ] = 16;
	return aa_index ;
}

char index_to_16pb ( const int  index )
{
	static	map < int, char >  index_aa =  set_pb16_by_index () ;
	if ( index_aa  .find(index) != index_aa .end()  )
	return  index_aa [ index  ];
	else
	{

		assert(0);
		return -2;
	}

}


map <int , char >  set_pb16_by_index ()
{
	map < int, char >  index_aa ;

    index_aa [ 0   ] ='A' ;
    index_aa [ 1   ] ='B' ;
    index_aa [ 2   ] ='C' ;
    index_aa [ 3   ] ='D' ;
    index_aa [ 4   ] ='E' ;
    index_aa [ 5   ] ='F' ;
    index_aa [ 6   ] ='G' ;
    index_aa [ 7   ] ='H' ;
    index_aa [ 8   ] ='I' ;
    index_aa [ 9   ] ='J' ;
    index_aa [ 10  ] ='K'  ;
    index_aa [ 11  ] ='L'  ;
    index_aa [ 12  ] ='M'  ;
    index_aa [ 13  ] ='N'  ;
    index_aa [ 14  ] ='O'  ;
    index_aa [ 15  ] ='P'  ;
    index_aa [ -1  ] ='*'  ;

	return index_aa;
}

char get_letter_pb16 ( int  pb_index)
{
    pb_index = toupper (pb_index);

    switch ( pb_index )
    {
        case 0:   return    'A';
        case 1:   return    'B';
        case 2:   return    'C';
        case 3:   return    'D';
        case 4:   return    'E';
        case 5:   return    'F';
        case 6:   return    'G';
        case 7:   return    'H';
        case 8:   return    'I';
        case 9:   return    'J';
        case 10:  return    'K';
        case 11:  return    'L';
        case 12:  return    'M';
        case 13:  return    'N';
        case 14:  return    'O';
        case 15:  return    'P';
        case -1:  return    '*';
       default:
        cout << "error!! wrong index " << pb_index << endl ;
        throw   "error!! wrong index ";
        break;
    }


}
