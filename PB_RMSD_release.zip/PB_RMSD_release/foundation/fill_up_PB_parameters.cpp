#include "CommonFunc.h"
#include <fstream>

using namespace std;

 extern ofstream log_stream;

double ** fill_up_PB_parameters (
    const string &path_to_PB_data,
    int &fragment_length,
    int &number_of_classes )
{

   	ifstream in ( path_to_PB_data.c_str());

	if ( ! in )	{
		log_stream	 << "ERROR -  can't find file containing Protein Blocks data:" << path_to_PB_data<< endl;
		cout    	 << "ERROR -  can't find file containing Protein Blocks data:" << path_to_PB_data<< endl;
		exit(-1);
	}

	string current_line;

    getline( in  , current_line, '\n' );


///   16 # Number of clusters (Protein Blocks)
	getline( in  , current_line, '\n' );
	{
        istringstream ist (current_line);
        ist >> number_of_classes;
	}

///   5 # Fragment length
   	getline( in  , current_line, '\n' );
   	{
        istringstream ist (current_line);
        ist >> fragment_length;
	}

    double **claster_motif_coordinates = new double* [number_of_classes] ;
    for ( int ii=0; ii < number_of_classes; ii++  )
        claster_motif_coordinates[ii]  = new double [fragment_length*9];


        for (int ii=0;ii<number_of_classes;ii++)
        {
            for (int kk=0;kk<fragment_length*9;kk++)
            {
                double temp;
                in >> temp;
                claster_motif_coordinates[ii][kk]=temp;
            }
        }

    return claster_motif_coordinates;

}
