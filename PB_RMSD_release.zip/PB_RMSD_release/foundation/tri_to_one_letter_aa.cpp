#pragma warning( disable : 4786 )

#include <vector>
#include <map>
#include "tri_to_one_and_vice_versa_aa_translation.h"

using namespace std;

	map < string, char >    init_tri_one_map	() ;
	map < char , string  >  init_one_tri_map	() ;

char tri_to_one_letter_aa ( const string & tri_letter_aa )
{
	string upper_letter_tri_letter_aa;
	upper_letter_tri_letter_aa.resize ( tri_letter_aa.size() ) ;
    for( int i=0;  i<tri_letter_aa .size();  ++i )
		upper_letter_tri_letter_aa [i] = toupper( tri_letter_aa [i] );


	static map < string, char > tri_one_map = init_tri_one_map () ;

	if ( tri_one_map.find( upper_letter_tri_letter_aa ) !=  tri_one_map.end()  )
		return tri_one_map [upper_letter_tri_letter_aa ] ;
	else
		return 'X';
}

// convetrs tri-letter amionoacid sequence to one-letter sequence
string tri_to_one_letter_sequence ( const vector < string >  & tri_letter_sequence )
{
		string one_letter_sequence ;

		for ( int kk=0; kk < tri_letter_sequence.size(); kk++ )
			one_letter_sequence += tri_to_one_letter_aa ( tri_letter_sequence[kk] );

		return one_letter_sequence;
}


map < string, char > init_tri_one_map ()
{

	map < string, char > tri_one_map ;

    tri_one_map ["ALA"] =  'A' ;
    tri_one_map ["ARG"] =  'R' ;
    tri_one_map ["ASN"] =  'N' ;
    tri_one_map ["ASP"] =  'D' ;
    tri_one_map ["VAL"] =  'V' ;
    tri_one_map ["HIS"] =  'H' ;
    tri_one_map ["GLY"] =  'G' ;
    tri_one_map ["GLN"] =  'Q' ;
    tri_one_map ["GLU"] =  'E' ;
    tri_one_map ["ILE"] =  'I' ;
    tri_one_map ["LEU"] =  'L' ;
    tri_one_map ["LYS"] =  'K' ;
    tri_one_map ["MET"] =  'M' ;
    tri_one_map ["PRO"] =  'P' ;
    tri_one_map ["SER"] =  'S' ;
    tri_one_map ["TYR"] =  'Y' ;
    tri_one_map ["THR"] =  'T' ;
    tri_one_map ["TRP"] =  'W' ;
    tri_one_map ["PHE"] =  'F' ;
    tri_one_map ["CYS"] =  'C';

	return tri_one_map ;
}

string  one_to_tri_letter_aa ( const char	one_letter_aa)
{
	char upper_one_letter_aa  = toupper( one_letter_aa );

	static map < char , string  > one_tri_map = init_one_tri_map () ;

	if ( one_tri_map.find( upper_one_letter_aa  ) !=  one_tri_map.end()  )
		return one_tri_map[upper_one_letter_aa  ] ;
	else
		return "???";
}

map < char , string  >  init_one_tri_map ()
{
	map < char , string  > one_tri_map ;

    one_tri_map ['A'] =   "ALA";
    one_tri_map ['R'] =   "ARG";
    one_tri_map ['N'] =   "ASN";
    one_tri_map ['D'] =   "ASP";
    one_tri_map ['V'] =   "VAL";
    one_tri_map ['H'] =   "HIS";
    one_tri_map ['G'] =   "GLY";
    one_tri_map ['Q'] =   "GLN";
    one_tri_map ['E'] =   "GLU";
    one_tri_map ['I'] =   "ILE";
    one_tri_map ['L'] =   "LEU";
    one_tri_map ['K'] =   "LYS";
    one_tri_map ['M'] =   "MET";
    one_tri_map ['P'] =   "PRO";
    one_tri_map ['S'] =   "SER";
    one_tri_map ['Y'] =   "TYR";
    one_tri_map ['T'] =   "THR";
    one_tri_map ['W'] =   "TRP";
    one_tri_map ['F'] =   "PHE";
    one_tri_map ['C'] =   "CYS";

	return  one_tri_map ;
}

bool is_standard_tri_letter_aminoacid (const string & aa)
{
	map < string, char > tri_one_map = init_tri_one_map () ; ;
//har ch = tri_one_map ["PRO"];
//h = tri_one_map ["ALA"];
//h = tri_one_map ["CYS"];
	bool flag = tri_one_map.find( aa  ) !=  tri_one_map.end()  ;
	return flag;

}

bool is_standard_tri_letter_aminoacid_sequence (const vector <string> & current_sequence)
{
	bool flag = true;
	for (int ii=0;ii<current_sequence.size();ii++)
		flag = flag & is_standard_tri_letter_aminoacid(current_sequence[ii]);

	return flag;
}
