#include "CommonFunc.h"
#include <fstream>

#include "pb16_to_index.h"

extern ofstream log_stream;

using namespace std;

void output_result(
     string &pdb_chain_ID,
     vector <int> &PB_index_set,
     string &sequence,
     string path_to_assignment_result )
{

 //   string path_to_assignment_results = pdb_chain_ID + string(".rmsd_assignment.txt");

	ofstream  res_out ( path_to_assignment_result.c_str() );
	if ( ! res_out )	{
		cout				<< "Can't create "   << path_to_assignment_result << endl;
		log_stream			<< "Can't create "   << path_to_assignment_result << endl;
		exit (1);
	}

    res_out << sequence[0] << endl;
    res_out << sequence[1] << endl;

    int index_len = PB_index_set.size();
	for (int ii=0;ii<index_len;ii++)
	{
       char letter = index_to_16pb(PB_index_set[ii]);
       res_out << sequence[ii+2] << "\t" << PB_index_set[ii] <<  "\t" << letter << endl;
       log_stream<< sequence[ii] << "\t" << PB_index_set[ii] <<  "\t" << letter << endl;
    }

    res_out << sequence[index_len] << endl;
    res_out << sequence[index_len+1] << endl;
//	out << sequence[ii] << endl;
//	out << sequence[ii+1] << endl;
}
