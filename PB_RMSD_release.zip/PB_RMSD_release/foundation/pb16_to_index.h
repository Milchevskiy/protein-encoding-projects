#ifndef PB16_TO_INDEX_H_INCLUDED
#define PB16_TO_INDEX_H_INCLUDED

#include <map>
//#include "pb16_to_index"
#include <cassert>

using namespace std;

int pb16_to_index ( const char aa );
map <char, int>  set_index_by_pb16();


char index_to_16pb ( const int  index );
map <int , char >  set_pb16_by_index ();


char get_letter_pb16 ( int  pb_index);

//int get_size_aminoacid_set ();

/*
bool is_standard_aa ( const char aa )
{
	int index = aminoacid_to_index (aa) ;
	return ( index  >= 0 &&  index <= 21 ) ;
}
*/

/*
int get_virtual_residue_index ()
{
	return aminoacid_to_index ('O');
}
*/


#endif // PB16_TO_INDEX_H_INCLUDED
