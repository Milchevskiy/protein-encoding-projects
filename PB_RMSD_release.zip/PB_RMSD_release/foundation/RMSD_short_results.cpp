#include "CommonFunc.h"
#include "Censorship.h"

#include "Fragment_base/Chain_binary.h"
//#include "Chain_store/Chain_Residue_Set.h"
#include "PB_RMSD.h"
#include "pb16_to_index.h"
#include "tri_to_one_and_vice_versa_aa_translation.h"

extern ofstream log_stream;

void   RMSD_short_results (
        Chain_binary *chain,
        double **claster_motif_coordinates,
        const int fragment_length,
        const int number_of_classes,
        const string & current_extension )
{

/// Residue sequence number

        string output_file = chain->get_pdb_chain_ID() + current_extension;

        ofstream  res_out ( output_file.c_str() );
        if ( ! res_out )	{
            cout				<< "Can't create "   << output_file << endl;
            log_stream			<< "Can't create "   << output_file << endl;
            exit (1);
        }


/// Handle RMSD
        vector < vector < double > >   set_of_coordinate_in_clasters_system;
        chain->	positioning_chain_by_clasters_set(
            claster_motif_coordinates,
            fragment_length,
            number_of_classes,
            set_of_coordinate_in_clasters_system);

        vector <int> PB_index_set = get_PB_index_set (set_of_coordinate_in_clasters_system) ;


/// Handle RMSDA
        vector < vector < double > >   set_of_coordinate_in_clasters_system_RMSDA;
        chain->	positioning_chain_by_clasters_set_by_RMSDA(
            claster_motif_coordinates,
            fragment_length,
            number_of_classes,
            set_of_coordinate_in_clasters_system_RMSDA);
        vector <int> PB_index_set_RMSDA = get_PB_index_set (set_of_coordinate_in_clasters_system_RMSDA, -9999.0) ;

//        int *serial_index   =   chain->get_serial_index();
        string sequence     =   chain->get_sequence();
//        vector<string> chain_residue_number = chain->get_in_chain_residue_number();

        int shift = fragment_length/2;

        string RMSD_set, RMSDA_set;

        int assignment_length = set_of_coordinate_in_clasters_system.size();
        for (int ii=0;ii<assignment_length;ii++)
        {
            char letter_RMSD = index_to_16pb(PB_index_set[ii]);
            RMSD_set += letter_RMSD;

            char letter_RMSDA = index_to_16pb(PB_index_set_RMSDA[ii]);
            RMSDA_set += letter_RMSDA;
        }

        PutVa("Sequence:",res_out,10,0,'l');
        res_out << sequence << endl;

        PutVa("RMSD",res_out,10,0,'l');
        for (int ii=0;ii<shift;ii++)
            res_out <<'*';
        res_out << RMSD_set ;
        for (int ii=0;ii<shift;ii++)
            res_out <<'*';
        res_out << endl;

        PutVa("RMSDA",res_out,10,0,'l');
        for (int ii=0;ii<shift;ii++)
            res_out <<'*';
        res_out << RMSDA_set ;
        for (int ii=0;ii<shift;ii++)
            res_out <<'*';
        res_out << endl;

}
