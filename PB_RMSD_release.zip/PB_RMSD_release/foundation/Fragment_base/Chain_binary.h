#ifndef CHAIN_BINARY_H
#define CHAIN_BINARY_H

#include <vector>
#include <string>

using namespace std;

class Chain_binary
{
public:
	Chain_binary ( const string & pdb_chain_ID );


	Chain_binary ( // ������ ��� ������ ����� ���������� ������� ���� ������� �����.
		const string & pdb_chain_ID,
		int		number_of_residues_,
		double	*coord_set_);

	Chain_binary( //  Make protein chain by dihedral angles. Default values setted for residue numbers.
		const string & pdb_chain_ID,
		vector <double> & Phi_set,
		vector <double> & Psi_set,
		vector <double> & Ome_set);

    Chain_binary( //  Make protein chain by dihedral angles. Default values setted for residue numbers.
        const string & pdb_chain_ID,
        vector <double> & Phi_set,
        vector <double> & Psi_set,
        vector <double> & Ome_set,
        double *coord_set_for_external) ;


	~Chain_binary ();

	int		get_number_of_residues	() const { return number_of_residues_; }
	string	get_pdb_chain_ID		() const { return pdb_chain_ID_; }

	vector <string> get_residue_names () ;
	vector <string> get_in_chain_residue_number ();

	string	get_sequence () ;


	int		*get_serial_index			() ;
	bool    *get_is_there_coord			() ;
	bool	*get_is_geometry_admissible () ;
	double  *get_coord_set				() ;

	void	print_protocol ();

	bool	extract_fragment (const int start_pos, const int length, double *coord );

	void	save_pdb_fragment (const int start_pos,const int length, const string & path_to_pdb);
//	void	save_pdb_fragment (const double *coord,const int length, const string & path_to_pdb);

	void	save_pdb_fragment (
		const double *coord,
		const int length,
		const string & path_to_pdb,
		vector <string> & residue_names,
		vector <string> & in_chain_residue_number);

	void save_pdb_fragment (
		const double *coord,
		const int length,
		const string & path_to_pdb,
		vector <string> & residue_names,
		vector <string> & in_chain_residue_number,
		char chain_ID);

	void	fragment_to_principal_axes (
		const int start_pos,
		const int length,
		double *coord );

	vector < vector < double > >  const & get_set_of_coordinate_in_clasters_system() const
	{
		return set_of_coordinate_in_clasters_system_;
	}

	void
		positioning_chain_by_helical_parameters(
			const int fragment_length,
			vector < double > & set_of_rise_per_residue,
			vector < double > & disp_set_of_rise_per_residue,
			vector < double > & set_cos_rotation_angle,
			vector < double > & disp_disp_of_cos_rotation_angles,
			vector < double > & set_of_rotation_angle_degrees,
			vector < double > & disp_set_of_rotation_angle_degrees);

// The same as positioning_chain_by_helical_parameters(), but aminoacid chain starts on  CA atom
	void
		positioning_chain_by_helical_parameters_PPII(
			const int fragment_length,
			vector < double > & set_of_rise_per_residue,
			vector < double > & disp_set_of_rise_per_residue,
			vector < double > & set_cos_rotation_angle,
			vector < double > & disp_disp_of_cos_rotation_angles,
			vector < double > & set_of_rotation_angle_degrees,
			vector < double > & disp_set_of_rotation_angle_degrees);


	void
		positioning_chain_by_clasters_set(
			double **claster_motif_coordinates,
			const int fragment_length,
			const int number_of_classes,
			vector < vector < double > >  & set_of_coordinate_in_clasters_system);


    void
        positioning_chain_by_clasters_set_by_RMSDA(
            double **claster_motif_coordinates,
            const int fragment_length,
            const int number_of_classes,
            vector < vector < double > >  & set_of_coordinate_in_clasters_system);

	void
		positioning_chain_by_clasters_set_PPII(
			double **claster_motif_coordinates,
			const int fragment_length,
			const int number_of_classes,
			vector < vector < double > >  & set_of_coordinate_in_clasters_system);

    // ������, ���������� ������������ ��������!!!!!! ���������� ������ �������
	vector < vector < double > >   & positioning_chain_by_clasters_set (
		double **claster_motif_coordinates,
		const int fragment_length,
		const int number_of_classes ) ;

	vector < vector < double > >  positioning_chain_by_clasters_set (
		double **claster_motif_coordinates,
		const int fragment_length,
		const int number_of_classes,
		const int sequence_length) ;  // ������� - ���� ��� number_of_residues_ & get_sequence();





	vector < double > get_torsion_angles ();

	int get_number_of_residues ()  { return number_of_residues_;}


	void center_of_mass(vector < double > & c_m_coord);

	double* get_coord_set() const { return coord_set_; }

	bool is_there_binary_file() const { return is_there_binary_file_; }

private:
	string	pdb_chain_ID_ ;
	int		number_of_residues_;
//	char	**residue_names_;
//	char	**in_chain_residue_number_;

	int		*serial_index_;
	bool	*is_there_coord_;
	bool	*is_geometry_admissible_;
	double	*coord_set_;

	char	*data_from_bin_;
	void	suck_in_file ();

	vector < vector < double > > set_of_coordinate_in_clasters_system_;

	bool is_there_binary_file_;
};

vector < vector < double > >
two_chain_distance_set (
	const string & pdb_chain_ID_1,
	const string & pdb_chain_ID_2,
	const int fragment_length );

bool align_two_chains (
		double *cord_set_1,
		double *cord_set_2,
		int fragment_length);


// old version
/*
void positioning_chain_by_clasters_set(
	double **claster_motif_coordinates,
	const int fragment_length,
	const int number_of_classes,
	double	*coord_set,
	const int number_of_residues,
	bool *  is_geometry_admissible_,
	bool *  is_there_coord_,
	vector < vector < double > >  & set_of_coordinate_in_clasters_system);
*/

void positioning_chain_by_clasters_set(
	double **claster_motif_coordinates,
	const int fragment_length,
	const int number_of_classes,
	double	*coord_set,
	const int number_of_residues,
	bool *  is_geometry_admissible_,
	bool *  is_there_coord_,
	vector < vector < double > >  & set_of_coordinate_in_clasters_system,
	const bool is_remove_first_CA,
	const bool is_remove_last_N);


#endif

