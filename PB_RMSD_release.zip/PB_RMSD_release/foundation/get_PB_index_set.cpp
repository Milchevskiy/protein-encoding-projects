#include "get_nearest_claster_index.h"



vector <int>  get_PB_index_set (
    vector < vector < double > >   & set_of_coordinate_in_clasters_system)
{

    int array_size = set_of_coordinate_in_clasters_system.size();
    vector <int>  PB_index_set; PB_index_set.resize(array_size);

    for (int ii=0;ii<set_of_coordinate_in_clasters_system.size();ii++)
    {
        if (set_of_coordinate_in_clasters_system[ii][0]==-1)
        {
            PB_index_set[ii]=-1;
            continue;
        }

        int nearest_index =  get_nearest_claster_index( set_of_coordinate_in_clasters_system[ii] );
        PB_index_set[ii] = nearest_index;
    }

    return PB_index_set;

}



vector <int>  get_PB_index_set (
    vector < vector < double > >   & set_of_coordinate_in_clasters_system,
    double  flag_value)
{

    int array_size = set_of_coordinate_in_clasters_system.size();
    vector <int>  PB_index_set; PB_index_set.resize(array_size);

    for (int ii=0;ii<set_of_coordinate_in_clasters_system.size();ii++)
    {
        if (set_of_coordinate_in_clasters_system[ii][0]==flag_value)
        {
            PB_index_set[ii]=-1;
            continue;
        }

        int nearest_index =  get_nearest_claster_index( set_of_coordinate_in_clasters_system[ii] );
        PB_index_set[ii] = nearest_index;
    }

    return PB_index_set;

}
