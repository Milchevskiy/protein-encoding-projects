#ifndef GEOMETRY_UTIL_H
#define GEOMETRY_UTIL_H

#include <cmath>
#include <limits>

// shifts center of mass to coordinate origin
void origin_to_zero (
	double *cord_set,
	int length);


void make_rotation_matrix_by_cartesian_triad (
	double *c_1,
	double *cur,
	double *c_2,
	double *rotation_matrix_nb);


namespace Geometry_util {

	inline double	Pythagorean_Number () { static double value = 4*atan (1.0); return value ; }
	inline double	epsilon_float(){ return ( std::numeric_limits<float>::epsilon()  );}

	static double identity_matrix [9] = {	1,0,0,
											0,1,0,
											0,0,1	};

/*
void make_rotation_matrix_by_cartesian_triad (
	double *c_1,
	double *cur,
	double *c_2,
	double *rotation_matrix_nb);
	*/

void  transfer_to_new_system (
			const double	cart_initial[3],
			const double	new_origin_pos[3],
			const double	new_origin_matr[9],
			double			cart_new[3]	);

// new form for  mk_NIMBLE_Rotation_XZ
void	make_rotation_matrix_X_Z  (
			const double angle_around_X,
			const double angle_around_Z,
			double  * rotation_matrix_X_Z ) ;

// new form for  mk_NIMBLE_Rotation_XZX
void	make_rotation_matrix_X_Z_X  (
			const double first_angle_around_X,
			const double angle_around_Z,
			const double second_angle_around_X,
			double  * rotation_matrix_X_Z_X );

void	normalize_vector (double &Ax, double &Ay,double &Az) ;

double	solve_sin_cos_indeterminacy(
			const double sin_val,
			const double cos_val);

void multiplication_matrixes_3x3_by_3x3	(
	const double	a[9],
	const double	b[9],
	double			r[9] ) ;

void multiplication_matrixes_3x3_by_trasposed_3x3	(
	const double	a[9],
	const double	b[9], // transposed matrix
	double			r[9] ) ;

void  multiplication_rowx3_by_3x3 (
	const double a[13],
	const double b[9],
	double		 r[3] ) ;

// meanwhile multiplication_matrixes_rowx3_by_3x3() does not handle with row number more then 4
void	multiplication_matrixes_rowx3_by_3x3 (
			const int row_number,
			const double a[12],
			const double b[9],
			double r[12] );

void	multiplication_row_by_3x3 (
			const double a[3],
			const double b[9],
			double r[3] );

void  multiplication_row_by_3x3_by_transposed (
	const double	a[3],
	const double	b[9],
	double			r[3] );


void	make_rotation_matrix_by_euler_angles(
			const double Ph,
			const double Ks,
			const double Te,
			double rotation_matrix [9]  );

double	diheral_by_four_poins (
			double p1[3],
			double p2[3],
			double p3[3],
			double p4[3] );

void	substract_coordinates (
			const double p_2[3] ,
			const double p_1[3],
			double r[3] ) ;

void	vector_product (
			const double A[3],
			const double B[3],
			double AxB[3]);

double cos_by_vectors (
			const double l[3],
			const double m[3] ) ;

double determinant_3x3 (
			const double matrix [9] );

double distance (
			const double l[3],const double m[3] );


double BondAngle(
			const double *p1,
			const double *p2,
			const double *p3);




}
#endif // GEOMETRY_UTIL_H
