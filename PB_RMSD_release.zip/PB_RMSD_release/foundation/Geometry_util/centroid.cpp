#include "Macros.h"

#include "Fragmrent_tranformation.h"

void centroid ( double *coord, const int length)
{
	double  x0=0,y0=0,z0=0;
	for (int ii=0;ii<9*length;ii+=3)
	{
			x0	+= coord[ii];
			y0	+= coord[ii+1];
			z0	+= coord[ii+2];;
	}
		
	x0	/=(3*length);
	y0	/=(3*length);
	z0	/=(3*length);

	int ii;
	for ( ii=0;ii<9*length;ii+=3)
	{
		coord[ii]	-=	x0;
		coord[ii+1] -=	y0;
		coord[ii+2] -=	z0;
	}
}


void centroid_no_idiotic(double *coord, const int atom_number)
{
	double  x0 = 0, y0 = 0, z0 = 0;

	for (int ii = 0; ii < 3 * atom_number; ii += 3)
	{
		x0 += coord[ii];
		y0 += coord[ii + 1];
		z0 += coord[ii + 2];;
	}

	x0 /=  atom_number;
	y0 /=  atom_number;
	z0 /=  atom_number;

	for (int ii = 0; ii < 3 * atom_number; ii += 3)
	{
		coord[ii]		-= x0;
		coord[ii + 1]	-= y0;
		coord[ii + 2]	-= z0;
	}



}