#include "Matrix_utilits.h"
#include "../CommonFunc.h"

void print_rectangular_matrix ( 
	string & header, 
	ofstream & res_stream, 
	const vector < vector <double > > & matrix )
{
	int number_of_rows		= matrix.size();
	int number_of_columns	= matrix[0].size();

	header << header << endl;
	for (int ii=0 ; ii < number_of_rows; ii++ )
	{
		for (int kk=0; kk<number_of_columns; kk++	)
			PutvaDouble ( matrix [ii][kk],res_stream, 8, 6, 'l' );
		
		res_stream << endl;
	}
}