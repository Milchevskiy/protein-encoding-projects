

double det_3x3 ( const double M [3][3] ) {	

 	 double Determinant =0;

/*					 0  1  2    00 01 02
					 3  4  5    10 11 12
					 6  7  8    20 21 22
*/ 
		Determinant +=	M[0][0]*M[1][1]*M[2][2] ;  
		Determinant +=  M[1][0]*M[2][1]*M[0][2] ;
		Determinant +=  M[0][1]*M[1][2]*M[2][0] ;     
		Determinant	-= 	M[2][0]*M[1][1]*M[0][2];
		Determinant	-=	M[1][0]*M[0][1]*M[2][2] ;
		Determinant	-=  M[2][1]*M[1][2]*M[0][0] ;

		return  Determinant ;

}  
/*
		Determinant +=	M[0]*M[4]*M[8] ;
		Determinant +=  M[3]*M[7]*M[2] ;
		Determinant +=  M[1]*M[5]*M[6] ;
		Determinant	-= 	M[6]*M[4]*M[2] ;
		Determinant	-=	M[3]*M[1]*M[8] ;
		Determinant	-=  M[7]*M[5]*M[0] ;
*/