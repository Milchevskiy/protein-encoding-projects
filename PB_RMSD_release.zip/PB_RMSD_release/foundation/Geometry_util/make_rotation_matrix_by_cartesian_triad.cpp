#include "Geometry_util.h"

using namespace Geometry_util;

void make_rotation_matrix_by_cartesian_triad (
	double *c_1,
	double *cur,
	double *c_2,
	double *rotation_matrix_nb)
{
	double VeNULL[3],Lg[3],Lf[3];
	VeNULL[0] = 0;	VeNULL[1] = 0;	VeNULL[2] = 0;

	Geometry_util::substract_coordinates ( c_1, cur, Lf);
	Geometry_util::substract_coordinates ( c_2, cur, Lg);
	
	Geometry_util::vector_product (Lg,Lf,rotation_matrix_nb +6 );
	Geometry_util::normalize_vector ( rotation_matrix_nb[6], 
					   rotation_matrix_nb[7], 
					   rotation_matrix_nb[8]) ;

	Geometry_util::substract_coordinates (VeNULL,Lf,rotation_matrix_nb );
	Geometry_util::normalize_vector ( rotation_matrix_nb[0], 
					   rotation_matrix_nb[1], 
					   rotation_matrix_nb[2]) ;

	Geometry_util::vector_product (rotation_matrix_nb +6,rotation_matrix_nb ,rotation_matrix_nb +3 );
	Geometry_util::normalize_vector ( rotation_matrix_nb[3], 
					   rotation_matrix_nb[4], 
					   rotation_matrix_nb[5]);
}


