/*
rotation_matrix_by_neighbours ( double * rotation_matrix_nb )
{
	if ( ! is_core_atom () ) 
	{
		cout		<< "Attempt to calculate rotation_matrix for non core atom" << endl; 
		log_stream	<< "Attempt to calculate rotation_matrix for non core atom" << endl; 
		exit(0);
	}

	Atom * 	atom_in  = get_neighbors (0);
	Atom * 	atom_fix = get_neighbors (1);

	bool c1 = ( atom_in->is_cartesian()  == true  );
	bool c2 = ( atom_fix->is_cartesian() == true );
	bool c3 = ( this->is_cartesian()     == true );
	bool res_bool = c1 && c2 && c3 ;


//else 
	if ( c1 && c2 && c3 ) 
	{
		double VeNULL[3],Lg[3],Lf[3],c_1[3],c_2[3],cur[3];
		VeNULL[0] = 0;	VeNULL[1] = 0;	VeNULL[2] = 0;

		c_1[0] = atom_in->x();	c_1[1] = atom_in->y();	c_1[2] = atom_in->z();
		c_2[0] = atom_fix->x();	c_2[1] = atom_fix->y();	c_2[2] = atom_fix->z();
		cur[0] =         x();	cur[1] =         y();	cur[2] =         z();

		substract_coordinates ( c_1, cur, Lf);
		substract_coordinates ( c_2, cur, Lg);
		
		vector_product (Lg,Lf,rotation_matrix_nb +6 );
		normalize_vector ( rotation_matrix_nb[6], 
						   rotation_matrix_nb[7], 
						   rotation_matrix_nb[8]) ;

		substract_coordinates (VeNULL,Lf,rotation_matrix_nb );
		normalize_vector ( rotation_matrix_nb[0], 
						   rotation_matrix_nb[1], 
						   rotation_matrix_nb[2]) ;

		vector_product (rotation_matrix_nb +6,rotation_matrix_nb ,rotation_matrix_nb +3 );
		normalize_vector ( rotation_matrix_nb[3], 
						   rotation_matrix_nb[4], 
						   rotation_matrix_nb[5]);

		is_rotation_matrix_by_neighbour_coord_ = true;
	}
	else 
}
*/