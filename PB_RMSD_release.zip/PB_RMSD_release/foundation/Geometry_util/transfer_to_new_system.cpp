#include "Geometry_util.h"

using namespace Geometry_util;

void  Geometry_util::transfer_to_new_system ( 
	const double	cart_initial[3],
	const double	new_origin_pos[3], 
	const double	new_origin_matr[9],
	double			cart_new[3]	) 
{
	double cart_intervening[3];

	substract_coordinates( 
		cart_initial, 
		new_origin_pos, 
		cart_intervening );

     //multiplication_row_by_3x3 (	
	multiplication_row_by_3x3_by_transposed (
		 cart_intervening , 
		 new_origin_matr, 
		 cart_new);
}