#ifndef __MACROS
#define __MACROS

 
#define		MULT_MTR_COL(_RESULT, _MATRIX, _VECTOR)	\
	_RESULT[X] = (_MATRIX)[0]*(_VECTOR)[0] + (_MATRIX)[1]*(_VECTOR)[1] + (_MATRIX)[2]*(_VECTOR)[2]; \
	_RESULT[X] = (_MATRIX)[3]*(_VECTOR)[0] + (_MATRIX)[4]*(_VECTOR)[1] + (_MATRIX)[4]*(_VECTOR)[2]; \
	_RESULT[X] = (_MATRIX)[6]*(_VECTOR)[0] + (_MATRIX)[7]*(_VECTOR)[1] + (_MATRIX)[8]*(_VECTOR)[2]; 


#endif 