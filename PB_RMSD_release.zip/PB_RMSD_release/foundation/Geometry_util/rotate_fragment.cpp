#include <cstring>
#include "Fragmrent_tranformation.h"


void rotate_fragment (const int length,double *coord,const double vect[3][3])
{
	double a[3],r[3];
	for (int ii=0;ii<3*length;ii++)
	{
		memcpy (a,coord+3*ii,3*sizeof(double));
		rotate_vector (a,vect,r);
		memcpy (coord+3*ii,r,3*sizeof(double));

	}

}


//
void rotate_vector (const double a[3], const double b[3][3],double r[3])
{
	r [0] = a[0]*b[0][0] + a[1]*b[1][0] + a[2]*b[2][0];
	r [1] = a[0]*b[0][1] + a[1]*b[1][1] + a[2]*b[2][1];               
	r [2] = a[0]*b[0][2] + a[1]*b[1][2] + a[2]*b[2][2];
}
/*

	0 1 2      00 01 02
	3 4 5      10 11 12 
	6 7 8      20 21 22

	r [0] = a[0]*b[0] + a[1]*b[3] + a[2]*b[6];
	r [1] = a[0]*b[1] + a[1]*b[4] + a[2]*b[7];
	r [2] = a[0]*b[2] + a[1]*b[5] + a[2]*b[8];
*/