#include <math.h>
#include "Geometry_util.h"

double Geometry_util::BondAngle(const double *p1,const double *p2,const double *p3 ) 
{
		double A[3],B[3];

		Geometry_util::substract_coordinates  (p1,p2,A );
		Geometry_util::substract_coordinates  (p3,p2,B );

		double Result = Geometry_util::cos_by_vectors (A,B); 
		Result = acos ( Result );

		return  Result ;
}