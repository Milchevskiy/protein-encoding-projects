void inertia_tensor (double ti[3][3], double *coord, const int length)
{
	ti[0][0]=0;
	ti[0][1]=0;
	ti[0][2]=0;
	ti[1][0]=0;
	ti[1][1]=0;
	ti[1][2]=0;
	ti[2][0]=0;
	ti[2][1]=0;
	ti[2][2]=0;

	for (int ii=0;ii<9*length;ii+=3)
	{
		double X = coord[ii];
		double Y = coord[ii+1];
		double Z = coord[ii+2];

		ti[0][0] += Y*Y+Z*Z; 	ti[0][1] += -X*Y; 		ti[0][2] += -X*Z;
		ti[1][0] += -Y*X;		ti[1][1] += X*X+Z*Z;	ti[1][2] += -Y*Z;
		ti[2][0] += -Z*X;		ti[2][1] += -Z*Y;		ti[2][2] += X*X+Y*Y;

	}
}