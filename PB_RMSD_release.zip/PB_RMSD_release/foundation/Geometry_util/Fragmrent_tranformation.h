#ifndef FRAGMRENT_TRANFORMATION_H
#define FRAGMRENT_TRANFORMATION_H

// shifts coorditanes to cent
void centroid				(double *coord,		const int length);  // Idiotic version: length - residue number!!!
void centroid_no_idiotic	(double *coord,		const int atom_number);
void inertia_tensor  (double ti[3][3], double *coord,const int length);
void rotate_fragment (const int length,double *coord,const double vect[3][3]);
void rotate_vector	 (const double a[3], const double b[3][3],double r[3]);
double det_3x3 ( const double M [3][3] );	






#endif