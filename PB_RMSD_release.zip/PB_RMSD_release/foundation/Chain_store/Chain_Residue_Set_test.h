#ifndef CHAIN_RESIDUE_TEST_H
#define CHAIN_RESIDUE_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Chain_Residue_Set_test: public Simple_test
{
public:
	~Chain_Residue_Set_test();

    void run()
    {
        old_jopa();
        //debug_protocol_handling()


	}
	void old_jopa();  // давно нашел пример где не работает этот класс. Теперь разбираем жопу
	void debug_protocol_handling();
};

#endif



