#ifndef DSSP_SINGLE_POINT_H 
#define DSSP_SINGLE_POINT_H 

#include <string>
#include <fstream>
#include <vector>
#include <map>

using namespace std;

class  DSSP_single_point 
{
public:
	DSSP_single_point (
		const char  one_letter_aa_name,
		const string & in_chain_residue_number);

	char	get_one_letter_aa_name	() const { return one_letter_aa_name_; }
	char	get_extended_DSSP_name	() const { return extended_DSSP_name_; }
	bool    get_is_there_cysteine_bridge() const { return is_there_cysteine_bridge_;}
	string	get_in_chain_residue_number	() const { return in_chain_residue_number_; }

	string	get_bridge_partners			() const { return bridge_partners_; }

	void put_extended_DSSP_name			(const char extended_DSSP_name )		{extended_DSSP_name_ = extended_DSSP_name; } 
	void put_bridge_partners			(const string  bridge_partners )		{bridge_partners_= bridge_partners; } 
	void put_is_there_cysteine_bridge	(const bool is_there_cysteine_bridge )	{is_there_cysteine_bridge_= is_there_cysteine_bridge;}
	void put_one_letter_aa_name			(const char one_letter_aa_name )		{one_letter_aa_name_ = one_letter_aa_name ;}

	//void put_bridge_partners			(const string & bridge_partners )		{bridge_partners_ = bridge_partners; }

private:
	char one_letter_aa_name_;
	char extended_DSSP_name_;  //eight letter

	string in_chain_residue_number_; // corresponds to resudue number in PDB file
	string bp1_;
	string bp2_;

	string bridge_partners_;

	bool is_there_cysteine_bridge_;
};

#endif