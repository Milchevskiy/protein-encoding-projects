#pragma warning( disable : 4786 )

#include "PDB_util.h"

bool is_atom_line (const string & line )
{
	string	atom_field			= line.substr(0,6);
	return (  atom_field == "ATOM  " || atom_field == "HETATM" );
}

//ANISOU    1  N  AGLY A 192     1105    949   1058    339    378    380       N  
// 123456789 123456789 123456789 123456789 123456789 123456789
bool is_atom_line (const string & line, const char chain_ID, const int  altLoc  )
{
	string	atom_field			= line.substr(0,6);
	return ( ( atom_field == "ATOM  " || atom_field == "HETATM")  && ( line[21] ==  chain_ID ||  line[21] == ' ' ) &&  ( line [16] == ' ' || line [16] == altLoc ) ); 

}


bool is_TER_line ( const string & line )
{
	string	atom_field			= line.substr(0,6);
	return (  atom_field == "TER   "); 
}
