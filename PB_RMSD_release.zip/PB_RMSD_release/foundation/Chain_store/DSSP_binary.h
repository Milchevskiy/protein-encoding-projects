// ��� ����� ���� ������� DSSP_binar� ��������� ������ �� Chain_binary

#ifndef DSSP_BINARY_H
#define DSSP_BINARY_H

#include <string>
#include <fstream>
#include <vector>
#include <map>

#include "DSSP_single_point.h"

#ifndef DSSP_BINARY_OPERATING_MODES_H
#define DSSP_BINARY_OPERATING_MODES_H

enum DSSP_BINARY_operating_modes
{
	COMMON_USAGE,
	FILL_UP
} 
;
#endif


class	Sheduler;

using namespace std; 



class  DSSP_binary
{
public:
	DSSP_binary () {}  ;

	DSSP_binary (	const string & pdb_file_list,
					const DSSP_BINARY_operating_modes run_mode ) ;

	~DSSP_binary ();

	string	get_sequence	() ;// { return sequence_; }
	string	get_extended_DSSP_sequence	();// { return extended_DSSP_sequence_; }
//	string	get_tri_letter_DSSP_sequence	() const { return extended_DSSP_sequence_; }

//	vector <string> get_DSSP_record_set () const 

	string	get_tri_letter_DSSP_sequence ();

	map<int,char> get_serial_index_to_DSSP()			{ return serial_index_to_DSSP_; }
	map<int,char> get_serial_index_to_amino_acid_name() { return serial_index_to_amino_acid_name_;}

	map<int,string> get_serial_index_to_bridge_partners(){ return serial_index_to_bridge_partners_;}

	void print_protocol();

	void fill_up_true_dssp_seq_and_seq();  // Similae to print_protocol() but no protocol

	bool is_there_binary_file() const { return is_there_binary_file_; }

private:
	Sheduler	*sheduler_;	

	string pdb_chain_ID_;

	void create_binary();
	void init_binary  ();

	int number_of_dsss_residues_ ;

	map<int,char> serial_index_to_DSSP_;
	map<int,char> serial_index_to_amino_acid_name_;

	map<int,string> serial_index_to_bridge_partners_;

	string sequence_;
	string extended_DSSP_sequence_;

	vector <string> DSSP_record_set_;

	char *data_from_bin_;

	//map <string,int> in_chain_residue_number_true_index_;

	vector <DSSP_single_point> DSSP_array_;  // 

	bool is_there_binary_file_;
};


string correct_fummy_DSSP_aa_seq ( string & dssp_aa_seq );
string correct_extended_DSSP_sequence (string & extended_DSSP_sequence );

#endif