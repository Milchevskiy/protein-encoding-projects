#ifndef TRI_TO_ONE_AND_VICE_VERSA_AA_TRANSLATION_H
#define TRI_TO_ONE_AND_VICE_VERSA_AA_TRANSLATION_H

#include <string>

using namespace std;

char	tri_to_one_letter_aa ( const string & tri_letter_aa ) ;
string  one_to_tri_letter_aa ( const char		one_letter_aa ) ;
bool is_standard_tri_letter_aminoacid (const string & aa);
bool is_standard_tri_letter_aminoacid_sequence (const vector <string> & current_sequence);


// convetrs tri-letter amionoacid sequence to one-letter sequence
string tri_to_one_letter_sequence ( const vector < string >  & tri_letter_sequence ) ;


#endif
