#pragma warning( disable : 4786 )

#include "Chain_store.h"

#include "Chain_Residue_Set.h"

//#include "Residue.h"

#include "../Censorship.h"

#include "../CommonFunc.h"

#include "../Sheduler.h"

#include "PDB_util.h"

extern Censorship configuration;
extern ofstream log_stream;

//vector < string > get_pdb_list ( const string & pdb_chain_file_list  );


Chain_store::
~Chain_store()
{
	if (!sheduler_ )
		delete sheduler_;

}

Chain_store::
Chain_store ( const string & pdb_chain_file_list ) :
 is_empty_ (true),
 sheduler_ (0)
{
  	sheduler_		= new Sheduler     ( configuration.option_meaning("Path_to_Chain_store")  + string ("sheduler") ) ;

	double Treshold_C_N_Distance	=	atof( sheduler_->option_meaning("TRESHOLD_C_N_DISTANCE").c_str() );
	double distance_epsilon			=	atof( sheduler_->option_meaning("DISTANCE_EPSILON").c_str() );
	double angle_epsilon			=	atof( sheduler_->option_meaning("ANGLE_EPSILON").c_str() );;



	vector < string >  pdb_list = get_pdb_list ();

	 string full_path_to_rejected =
		configuration.option_meaning("Path_to_Chain_store") +
		"rejected";

//	ofstream reject_stream ( full_path_to_rejected.c_str(),ios::app  );
	ofstream reject_stream ( full_path_to_rejected.c_str() );
	if ( ! reject_stream )
	{
		cout		<< " Can't create file " << full_path_to_rejected << endl;
		log_stream	<< " Can't create file " << full_path_to_rejected << endl;
		exit (1);
	}


	 string full_path_to_accepted =
		configuration.option_meaning("Path_to_Chain_store") +
		"accepted";

//	ofstream accepted_stream ( full_path_to_accepted.c_str(),ios::app  );
	ofstream accepted_stream ( full_path_to_accepted.c_str() );
	if ( ! accepted_stream )
	{
		cout		<< " Can't create file " << full_path_to_accepted	<< endl;
		log_stream	<< " Can't create file " << full_path_to_accepted	 << endl;
		exit (1);
	}


//*******/
		string accepted_chain_list_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		string ("accepted_chain_list.bin") ;


	ofstream accepted_binary_stream ( accepted_chain_list_file_name .c_str(),ios::binary );

	if ( ! accepted_binary_stream )	{
		log_stream	 << "ERROR -  can't create binary file" << accepted_chain_list_file_name << endl;
		cout		 << "ERROR -  can't create binary file" << accepted_chain_list_file_name << endl;
		exit (1);
	}


//*******/

	int total_length=0;
	int total_valid_residue_number=0;


	for ( int ii=0; ii < pdb_list.size(); ii++ )
	{
			Chain_Residue_Set crs (
			pdb_list [ii],
			Treshold_C_N_Distance,
			distance_epsilon,
			angle_epsilon);

		crs.print_protocol();


		if ( ! crs.is_pdb_file() )
		{
			add_rejected_list (reject_stream, pdb_list [ii], string ("PDB file or chain not found") );
			continue;
		}
		if ( ! crs.is_accord_seqres_atom() )
		{
			add_rejected_list (reject_stream, pdb_list [ii], string ("Sequence by SEQRES contradict given by ATOM pull") ) ;
			continue;
		}
		else
			crs.save_as_binary();

		int length					= crs.get_length();
		int valid_residue_number	= crs.get_valid_residue_number();

		total_length += length;
		total_valid_residue_number += valid_residue_number;


		string message ;
		{
			ostringstream ost ;
			PutVa ( length ,				ost , 6,5, 'l') ;
			PutVa ( valid_residue_number,	ost , 6,5, 'l') ;
			message = ost.str();
		}
		add_rejected_list (accepted_stream, pdb_list [ii], message  ) ;

		cout << pdb_list [ii] << "  " << ii << "\t" << total_valid_residue_number << endl;

		accepted_binary_stream.write( (char* ) pdb_list [ii].c_str(), 5*sizeof (char) );
		accepted_binary_stream.write( (char* ) &length, sizeof (int) );
	}
}
// ������� ���� ����, � accepted_binary_stream �� �������
Chain_store::
Chain_store ( const string &pdb_chain_ID,
			  const Chain_store_run_mode run_mode  ) :
 is_empty_ (true),
 sheduler_ (0)
{
  	sheduler_		= new Sheduler     ( configuration.option_meaning("Path_to_Chain_store")  + string ("sheduler") ) ;

	double Treshold_C_N_Distance	=	atof( sheduler_->option_meaning("TRESHOLD_C_N_DISTANCE").c_str() );
	double distance_epsilon			=	atof( sheduler_->option_meaning("DISTANCE_EPSILON").c_str() );
	double angle_epsilon			=	atof( sheduler_->option_meaning("ANGLE_EPSILON").c_str() );;


	Chain_Residue_Set crs (
		pdb_chain_ID,
		Treshold_C_N_Distance,
		distance_epsilon,
		angle_epsilon);

	crs.print_protocol();


	if ( ! crs.is_pdb_file() )
	{
		cout << "PDB file or chain not found" << endl;
		exit(-1);
	}
	if ( ! crs.is_accord_seqres_atom() )
	{
		cout << "Sequence by SEQRES contradict given by ATOM pull"<< endl;
		exit(-1);
	}
	else
		crs.save_as_binary();

	int length					= crs.get_length();
	int valid_residue_number	= crs.get_valid_residue_number();


	string message ;
	{
		ostringstream ost ;
		PutVa ( length ,				ost , 6,5, 'l') ;
		PutVa ( valid_residue_number,	ost , 6,5, 'l') ;
		message = ost.str();
	}
	cout << message << endl;

}


void Chain_store::add_rejected_list (
	ofstream &reject_stream,
	const string & pdb_chain_ID,
	const string & exlanation )
{
	reject_stream << pdb_chain_ID << " " << exlanation << endl;
	rejected_chain_number_ ++ ;
}

void Chain_store::add_accepted_list (
	  ofstream &accepted_stream,
	  const string & pdb_chain_ID,
	  const string & exlanation )
{
	accepted_stream << pdb_chain_ID << " " << exlanation << endl;
	accepted_chain_number_++ ;
}

//This function is usually used only in this program





// ���� ����������� ������������, ��� ������ PDB chain ID ������� ����
Chain_store::
Chain_store(vector < string >  & pdb_list) :
	is_empty_(true),
	sheduler_(0)
{
	sheduler_ = new Sheduler(configuration.option_meaning("Path_to_Chain_store") + string("sheduler"));

	double Treshold_C_N_Distance = atof(sheduler_->option_meaning("TRESHOLD_C_N_DISTANCE").c_str());
	double distance_epsilon = atof(sheduler_->option_meaning("DISTANCE_EPSILON").c_str());
	double angle_epsilon = atof(sheduler_->option_meaning("ANGLE_EPSILON").c_str());;



//	vector < string >  pdb_list = get_pdb_list();

	string full_path_to_rejected =
		configuration.option_meaning("Path_to_Chain_store") +
		"rejected";

	//	ofstream reject_stream ( full_path_to_rejected.c_str(),ios::app  );
	ofstream reject_stream(full_path_to_rejected.c_str());
	if (!reject_stream)
	{
		cout << " Can't create file " << full_path_to_rejected << endl;
		log_stream << " Can't create file " << full_path_to_rejected << endl;
		exit(1);
	}


	string full_path_to_accepted =
		configuration.option_meaning("Path_to_Chain_store") +
		"accepted";

	//	ofstream accepted_stream ( full_path_to_accepted.c_str(),ios::app  );
	ofstream accepted_stream(full_path_to_accepted.c_str());
	if (!accepted_stream)
	{
		cout << " Can't create file " << full_path_to_accepted << endl;
		log_stream << " Can't create file " << full_path_to_accepted << endl;
		exit(1);
	}


	//*******/
	string accepted_chain_list_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		string("accepted_chain_list.bin");


	ofstream accepted_binary_stream(accepted_chain_list_file_name.c_str(), ios::binary);

	if (!accepted_binary_stream) {
		log_stream << "ERROR -  can't create binary file" << accepted_chain_list_file_name << endl;
		cout << "ERROR -  can't create binary file" << accepted_chain_list_file_name << endl;
		exit(1);
	}


	//*******/

	int total_length = 0;
	int total_valid_residue_number = 0;


	for (int ii = 0; ii < pdb_list.size(); ii++)
	{
		Chain_Residue_Set crs(
			pdb_list[ii],
			Treshold_C_N_Distance,
			distance_epsilon,
			angle_epsilon);

		crs.print_protocol();


		if (!crs.is_pdb_file())
		{
			add_rejected_list(reject_stream, pdb_list[ii], string("PDB file or chain not found"));
			continue;
		}
		if (!crs.is_accord_seqres_atom())
		{
			add_rejected_list(reject_stream, pdb_list[ii], string("Sequence by SEQRES contradict given by ATOM pull"));
			continue;
		}
		if (!crs.is_present_CA_C_N_backbone())
		{
			add_rejected_list(reject_stream, pdb_list[ii], string("Not all backbone atoms (N,Ca,C) fouund in PDB"));
			continue;
		}

		else
			crs.save_as_binary();

		int length = crs.get_length();
		int valid_residue_number = crs.get_valid_residue_number();

		total_length += length;
		total_valid_residue_number += valid_residue_number;


		string message;
		{
			ostringstream ost;
			PutVa(length, ost, 6, 5, 'l');
			PutVa(valid_residue_number, ost, 6, 5, 'l');
			message = ost.str();
		}
		add_rejected_list(accepted_stream, pdb_list[ii], message);

		cout << pdb_list[ii] << "  " << ii << "\t" << total_valid_residue_number << endl;

		accepted_binary_stream.write((char*)pdb_list[ii].c_str(), 5 * sizeof(char));
		accepted_binary_stream.write((char*)&length, sizeof(int));
	}
}



void prepare_ls_and_control_set(
    const string &source_name,
    const int ls_control_rate,
    const int init_shift);
