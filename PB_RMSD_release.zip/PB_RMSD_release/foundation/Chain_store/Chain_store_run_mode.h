#ifndef CHAIN_STORE_RUN_MODE_H
#define CHAIN_STORE_RUN_MODE_H

enum Chain_store_run_mode
{
	ADD_ONLY_SINGLE_CHAIN_DONT_TOUCH_ALL_ANOTHER_BESES
} 
;
#endif