#include "Residue.h"

#include <cstring>

Residue::Residue (
	const string in_chain_residue_number,
	const string & name_3,
	const double * chain_coordinates	):
 in_chain_residue_number_	(in_chain_residue_number),
 name_3_					(name_3),
 coord_						(0),
 is_there_coord_            (false),
 is_geometry_admissible_    (false),
 point_to_continues_set_    (-1)
{
	 if ( chain_coordinates )
		 full_up_coordinates ( chain_coordinates);
}

Residue::
Residue (	const int serial_index,
			const string & name_3 ):
 in_chain_residue_number_	("***"),
 serial_index_				(serial_index),
 name_3_					(name_3),
 coord_						(0),
 is_there_coord_            (false),
 is_geometry_admissible_    (false),
 point_to_continues_set_    (-1)
{
}

Residue::~Residue ( )
{
	if ( coord_ )
		delete [] coord_ ;
}

void Residue::
full_up_coordinates ( const double * coord	)
{
	coord_ = new double [9];
	memcpy (coord_,coord, 9*sizeof(double) );
	is_there_coord_ = true;
}

