#ifndef CHAIN_STORE_TEST_H
#define CHAIN_STORE_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

using namespace std;

class  Chain_store_test: public Simple_test
{
public:
	~Chain_store_test();

    void run()
    {

/// сравнить файлы *.dist_data для моделей
   // dist_data_compare_test ();

    //creating_chain_binary_files_for_some_subset_test();
        constructor_test ();

    //
    //check_geometry_for_subset();


        /// in fact analyses presence and percentage of nonstandare aminoacids
        //clean_out_nonstastard_containing_chains();

     /// separate X-ray and non-X-ray chains and high quality X-ray chains
   //     analyse_quality_for_subsets();

    /// collect x-ray chains
      //  collect_xray_list();


        /// äåëèì îáó÷àþùóþ âûáîðêó íà ÷àñòè - îáó÷àþùóþ è êîíòðîëü
     //   prepare_ls_and_control_set_test();

     /// Áûëî ñäåëàíà âûáîðêà èç íîâîãî ôîðìàòà (see /home/milch/projects/Didona/Store/PDBselect/2020_poit_of_view
        //prepare_pdb_list_2020_style();


///________________________
    /// íèæå äàâíî áûëî óæê çàáûë
     //   calc_total_pull_size();



	//	revision_existing_database();  // èùåì è óäàëÿåì öåïè ãäå ìíîãî íåñòàíäàðòíûõ àìèíîêèñëîò

	//		prepare_elm_alternative_sequence_set();
  //      revision_existing_database();
	}
	void dist_data_compare_test ();
    void check_geometry_for_subset();
	void clean_out_nonstastard_containing_chains();
    void analyse_quality_for_subsets();
	void collect_xray_list();
	void prepare_ls_and_control_set_test();
	void prepare_pdb_list_2020_style();
	void creating_chain_binary_files_for_some_subset_test();
	void constructor_test ();
	void revision_existing_database();
	void calc_total_pull_size();
	void prepare_elm_alternative_sequence_set();
};




#endif
