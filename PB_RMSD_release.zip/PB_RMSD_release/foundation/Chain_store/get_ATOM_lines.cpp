#pragma warning( disable : 4786 )

#include "PDB_util.h"

#include <sstream>


vector <string> get_ATOM_lines (
	ifstream & source_stream,
	const char chain_ID,
	const char  altLoc )
{
	vector <string> atom_record_pull;
	bool is_reached_yet = false;

	string current_line;
	while ( getline(source_stream,current_line,'\n' ) )
	{
		if ( is_atom_line  ( current_line,  chain_ID, altLoc   ) )
		{
			if ( is_reached_yet == false )		is_reached_yet = true;
			atom_record_pull.push_back(current_line);
		}
		if ( is_reached_yet && ( current_line[21] !=  chain_ID ) && ( current_line[21] !=  ' ' ) )
			break;

		if ( is_TER_line ( current_line ) )
		{
			if ( is_reached_yet == true )
				break;
		}
	}

	return atom_record_pull;
}

