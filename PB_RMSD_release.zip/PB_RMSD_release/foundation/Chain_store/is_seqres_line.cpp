#pragma warning( disable : 4786 )

#include "PDB_util.h"

bool is_seqres_line (const string & line )
{
	return ( line.substr(0,6) == "SEQRES" );
}

bool is_seqres_line (const string & line, const char chain_ID  )
{
	if ( chain_ID == 'A'  )
		return ( line.substr(0,6) == "SEQRES"  &&  ( line[11] == chain_ID || line[11] == ' ' )  );
	else 
		return ( line.substr(0,6) == "SEQRES"  &&  line[11] == chain_ID );

}
