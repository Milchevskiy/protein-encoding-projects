#include "DSSP_binary.h"

#include "../Censorship.h"

#include "../Sheduler.h"

#include "../CommonFunc.h"
#include <iostream>
#include <fstream>

#include "../tri_to_one_and_vice_versa_aa_translation.h"

#include "../Fragment_base/Chain_binary.h"

#include "DSSP_single_point.h"

#include <cassert>
#include <sstream>

using namespace std;

#define INFO_FIELD_SIZE 40   // the first part of string containig usefull info

extern Censorship configuration;
extern ofstream log_stream;

DSSP_binary::
~DSSP_binary()
{
	 if (	data_from_bin_	)	delete [] data_from_bin_;
 	 if (!sheduler_ ) 			delete sheduler_;
}

DSSP_binary::DSSP_binary (
	const string & pdb_chain_ID,
	const DSSP_BINARY_operating_modes run_mode ):
 pdb_chain_ID_ (pdb_chain_ID),
 data_from_bin_ (0)
{
	switch ( run_mode  )
	{

		case COMMON_USAGE:
			init_binary ();
			break;
		case FILL_UP:
			create_binary();
			break;
		default :
			log_stream	<< "Inadmissible run mode for DSSP_binary class" << endl;
			cout		<< "Inadmissible run mode for DSSP_binary class" << endl;
			exit (-1);
	}

}


void DSSP_binary::init_binary ()
{

	string binary_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		string ("/DSSP_store/")	+ string ("/binary/") + string (pdb_chain_ID_)  + string (".bin");

	ifstream binary_stream ( binary_file_name.c_str(),ios::binary );

	if ( ! binary_stream )	{
		log_stream	 << "ERROR -  can't find binary file" << binary_file_name<< endl;
		cout		 << "ERROR -  can't find binary file" << binary_file_name<< endl;
		exit (1);
	}

	binary_stream.seekg(0,ios::end);
	//int file_length = binary_stream.tellg();
	streamoff file_length = binary_stream.tellg();

	int test = (int) file_length ;


	number_of_dsss_residues_ = ( (int) file_length ) / (INFO_FIELD_SIZE);

	data_from_bin_ = new char [(int) file_length];
	binary_stream.seekg(0,ios::beg);
	binary_stream.read( (char* ) data_from_bin_, file_length*sizeof (char) );


// INIT CHAIN BYNARY
		Chain_binary cbi( pdb_chain_ID_);
		int number_of_residues_in_chain = cbi.get_number_of_residues();
		vector <string> residue_names			= cbi.get_residue_names ();
		vector <string> in_chain_residue_number = cbi.get_in_chain_residue_number ();
		bool*			is_there_coord			= cbi.get_is_there_coord();
		bool*			is_geometry_admissible  = cbi.get_is_geometry_admissible() ;


//		DSSP_array_.resize(number_of_residues_in_chain);

		//string current_in_chain_residue_number = "33a";

		string current_in_chain_residue_number;// = in_chain_residue_number[3];



		map <string,int> in_chain_residue_number_true_index_;
		for  (int kk=0;kk<number_of_residues_in_chain;kk++)
		{
			if ( in_chain_residue_number[kk] != "***" )
			{
				current_in_chain_residue_number = in_chain_residue_number[kk];
				in_chain_residue_number_true_index_[current_in_chain_residue_number] = kk;
			}

			char current_aa_name = tri_to_one_letter_aa ( residue_names[kk]) ;
			DSSP_single_point current_DSSP_point(
				current_aa_name,
				current_in_chain_residue_number);

			DSSP_array_.push_back(current_DSSP_point);
		}




//    1    2 A L              0   0  168      0, 0.0     2,-0.1     0, 0.0     3,-0.0   0.000 360.0 360.0 360.0 114.5   -9.7  -13.3   53.4
//   16   20 A T  H  X S+     0   0   83     -4,-2.2     4,-1.9    -5,-0.2    -1,-0.2   0.937 110.6  41.6 -59.2 -52.8   37.1   -9.1   17.3
//    6    6 A I  E     +ab  39  69A   1     32,-3.5    34,-3.7    -2,-0.5     2,-0.3  -0.939  20.8 174.2-115.1 128.8   14.7   23.4   61.9
// 123456789 123456789 123456789 123456789
// 123456789 123456789 123456789
//287   84 B V  E     -gh 260 308B   4    -28,-2.6   -26,-2.4    -2,-0.5     2,-0.3  -0.998  14.4-149.6-124.2 124.1  -22.1    2.2   10.9

	string current_pdb_number;
	char chain_ID;
	char amino_acid_name;
	char current_dssp;


//	int current_serial_index;
	for (int ii=0;ii<number_of_dsss_residues_;ii++)
	{
		unsigned start_pos = ii* INFO_FIELD_SIZE;

		current_pdb_number.resize(0);

		int start = start_pos + 5;
		int end = start +6;
		for (int kk=start;kk<end ;kk++)
		{
			if (data_from_bin_[kk] == ' ')
				continue;
			current_pdb_number.push_back(data_from_bin_[kk]);
		}



	//	current_serial_index = ii;

		chain_ID		= data_from_bin_[start_pos + 11];

		amino_acid_name = data_from_bin_[start_pos + 13];


//����������� � ���������� ������� ����� �������
		bool is_there_cysteine_bridge=false;
		if (islower (amino_acid_name)  )
		{
			is_there_cysteine_bridge = true;
			amino_acid_name = 'C';
		}

		current_dssp	= data_from_bin_[start_pos + 16];

		if (current_dssp ==32)
			current_dssp = '-';

/*		serial_index_to_DSSP_[current_serial_index]=current_dssp;
		serial_index_to_amino_acid_name_[current_serial_index]=amino_acid_name;

		string current_bridge_partners;
		current_bridge_partners += data_from_bin_[start_pos + 23];
		current_bridge_partners += data_from_bin_[start_pos + 24];

		serial_index_to_bridge_partners_[current_serial_index] = current_bridge_partners;
*/

		string current_bridge_partners;
		current_bridge_partners += data_from_bin_[start_pos + 23];
		current_bridge_partners += data_from_bin_[start_pos + 24];


		if ( in_chain_residue_number_true_index_ .find(current_pdb_number) == in_chain_residue_number_true_index_.end()  )
		{
			cout		<< "cant'n find residue "  << current_pdb_number << " in "  << pdb_chain_ID_ << endl;
			log_stream  << "cant'n find residue "  << current_pdb_number << " in "  << pdb_chain_ID_ << endl;
			//DSSP_array_[current_true_index].put_extended_DSSP_name('?');
		}
		else
		{
			int current_true_index = in_chain_residue_number_true_index_[current_pdb_number];
			DSSP_array_[current_true_index].put_extended_DSSP_name(current_dssp);
			DSSP_array_[current_true_index].put_is_there_cysteine_bridge (is_there_cysteine_bridge);
			DSSP_array_[current_true_index].put_bridge_partners (current_bridge_partners);

				char current_aa_name_by_cb = tri_to_one_letter_aa ( residue_names[current_true_index]) ;
				if ( amino_acid_name != current_aa_name_by_cb  )
					cout << " alarm: amino_acid_name != current_aa_name_by_cb" << endl;
				assert (amino_acid_name == current_aa_name_by_cb  );
// ����� ��������� - �������� bp1_ bp2_
		}
	}
	//fill_up_true_dssp_seq_and_seq();
}

void DSSP_binary::create_binary()
{
	// toupper
	string temp; 	for (unsigned ii=0;ii<pdb_chain_ID_.size();ii++) temp += toupper ( pdb_chain_ID_[ii]);

	string	pdb_ID   =  temp.substr(0,4);
	char	target_chain_ID = pdb_chain_ID_[4];

	string binary_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		string ("/DSSP_store/")	+ string ("/binary/") + string (pdb_chain_ID_)  + string (".bin");
	ofstream binary_stream ( binary_file_name.c_str(),ios::binary );
	if ( ! binary_stream )	{
		log_stream	 << "ERROR -  can't create binary file" << binary_file_name<< endl;
		cout		 << "ERROR -  can't create binary file" << binary_file_name<< endl;
		exit (1);
	}

	string path_to_DSSP_source =
		configuration.option_meaning("Path_to_Chain_store") +
		string ("/DSSP_store/") + string (pdb_ID) + string (".DSSP");

	is_there_binary_file_ = true;
	ifstream dssp_stream  ( path_to_DSSP_source.c_str() );
	if ( ! dssp_stream )
	{
		cout		<<	path_to_DSSP_source  << " not found in local PDB bank" << endl;
		log_stream	<<	path_to_DSSP_source  << " not found in local PDB bank" << endl;
		//exit(-1);
		is_there_binary_file_ = false;
	}



	string current_line;
	while( getline( dssp_stream  , current_line, '\n' ) )
	{
		if ( current_line[2] == '#' )
			break; // ��������� �����
	}

//    1    2 A L              0   0  168      0, 0.0     2,-0.1     0, 0.0     3,-0.0   0.000 360.0 360.0 360.0 114.5   -9.7  -13.3   53.4
//    6    6 A I  E     +ab  39  69A   1     32,-3.5    34,-3.7    -2,-0.5     2,-0.3  -0.939  20.8 174.2-115.1 128.8   14.7   23.4   61.9
// 123456789 123456789 123456789 123456789
	string in_chain_residue_number;

	while( getline( dssp_stream  , current_line, '\n' ) )
	{
		if (current_line.size() < 3 )
			break;// ��� �����


		string curren_chain_ID = current_line.substr(11,1);

		if ( target_chain_ID != curren_chain_ID[0] )
			continue;

	//	in_chain_residue_number = current_line.substr(5,5);
	//	char one_letter_aminoacid_name = current_line[13];

		string info_field = current_line.substr(0,INFO_FIELD_SIZE);
		binary_stream.write( (char* ) (info_field.c_str()) , INFO_FIELD_SIZE*sizeof (char) );

	}
}





//*****************************
void DSSP_binary::
fill_up_true_dssp_seq_and_seq()
{
		Chain_binary cbi( pdb_chain_ID_);
		int number_of_residues= cbi.get_number_of_residues();
		vector <string> residue_names			= cbi.get_residue_names ();
		vector <string> in_chain_residue_number = cbi.get_in_chain_residue_number ();
		bool*			is_there_coord			= cbi.get_is_there_coord();
		bool*			is_geometry_admissible  = cbi.get_is_geometry_admissible() ;




		map<int,char> serial_index_to_amino_acid_name	= get_serial_index_to_amino_acid_name();
		map<int,char> serial_index_to_DSSP				= get_serial_index_to_DSSP();
		map<int,string> serial_index_to_bridge_partners = get_serial_index_to_bridge_partners();


		sequence_.resize(number_of_residues);
		extended_DSSP_sequence_.resize(number_of_residues);



		for (unsigned ii=0;ii<number_of_residues;ii++)
		{
//			PutVa(residue_names[ii],			output,8,3,'l' );

			char one_letter_aminoacid = tri_to_one_letter_aa ( residue_names[ii]) ;

//			PutVa(in_chain_residue_number[ii],	output,8,3,'l' );

			//output << one_letter_aminoacid <<  "  " ;

			sequence_[ii] = one_letter_aminoacid;


//			string tmp;
//			istringstream ist ( in_chain_residue_number[ii]);
//			ist >> tmp;
//			int curren_in_pdb_number = atoi(in_chain_residue_number[ii].c_str() );

			int curren_in_pdb_number = ii;

			if ( serial_index_to_DSSP .find(curren_in_pdb_number) != serial_index_to_DSSP .end()  )
			//	output << '\"' << serial_index_to_DSSP [curren_in_pdb_number] << '\"';
				extended_DSSP_sequence_[ii] = serial_index_to_DSSP [curren_in_pdb_number];
			else
//				output << '?';
				extended_DSSP_sequence_[ii]= '?';


/*
			if ( serial_index_to_bridge_partners_ .find(curren_in_pdb_number) != serial_index_to_bridge_partners_ .end()  )
				output << '\"' << serial_index_to_bridge_partners_ [curren_in_pdb_number] << '\"';
			else
				output << ' ';
*/



//			output << endl;
		}

		delete [] is_there_coord;
		delete [] is_geometry_admissible;
}

string DSSP_binary::
get_tri_letter_DSSP_sequence ()
{
	int seq_len = extended_DSSP_sequence_.size();
	string tri_letter_DSSP_sequence;
	tri_letter_DSSP_sequence.resize(seq_len);

	for (int ii=0;ii<seq_len;ii++)
	{
		char ch = extended_DSSP_sequence_[ii];
		switch(ch) {
			case 'S' : case 'T': case ' ':
				tri_letter_DSSP_sequence[ii]='c';
				break;
			case 'H' : case 'G': case 'I':
				tri_letter_DSSP_sequence[ii]='H';
				break;
			case 'E' : case 'B':
				tri_letter_DSSP_sequence[ii]='E';
				break;
			case '?' :
				tri_letter_DSSP_sequence[ii]='?';
				break;
			default:
				throw "Unknown dssp letter";

		}
	}

	return tri_letter_DSSP_sequence;

}

string correct_fummy_DSSP_aa_seq ( string & dssp_aa_seq )
{
	int aa_size = dssp_aa_seq.size();
	for (int ii=0;ii<aa_size; ii++)
	{
		if (! isupper (dssp_aa_seq[ii]) )
			dssp_aa_seq[ii] = 'C';

	}
	return dssp_aa_seq;;
}

string correct_extended_DSSP_sequence (string & extended_DSSP_sequence )
{
	int size = extended_DSSP_sequence.size();
	for (int ii=0;ii<size; ii++)
	{
		if (extended_DSSP_sequence[ii] == ' ')
			extended_DSSP_sequence[ii] = 'c';


	}
	return extended_DSSP_sequence;

}


void DSSP_binary::
print_protocol()
{
		Chain_binary cbi( pdb_chain_ID_);

		string protocol_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		string ("/DSSP_store/")	+ string ("/protocol/") + string (pdb_chain_ID_)  + string (".protocol");

		ofstream output ( protocol_file_name.c_str() );
		if ( ! output )
		{
			log_stream	<< "can't create " << endl;
			cout		 << "can't create " << endl;
			exit (1);
		}

		map<int,char> serial_index_to_amino_acid_name	= get_serial_index_to_amino_acid_name();
		map<int,char> serial_index_to_DSSP				= get_serial_index_to_DSSP();

		map<int,string> serial_index_to_bridge_partners = get_serial_index_to_bridge_partners();

		int number_of_residues= cbi.get_number_of_residues();
		vector <string> residue_names			= cbi.get_residue_names ();
		vector <string> in_chain_residue_number = cbi.get_in_chain_residue_number ();
		bool*			is_there_coord			= cbi.get_is_there_coord();
		bool*			is_geometry_admissible  = cbi.get_is_geometry_admissible() ;

		for (unsigned ii=0;ii<number_of_residues;ii++)
		{
			PutVa(residue_names[ii],			output,8,3,'l' );

			char one_letter_aminoacid = tri_to_one_letter_aa ( residue_names[ii]) ;
			PutVa(in_chain_residue_number[ii],	output,8,3,'l' );

			output << one_letter_aminoacid <<  "  " ;

			char one_letter_aa_name = DSSP_array_[ii].get_one_letter_aa_name();
			output << one_letter_aa_name << " ";

			char extended_DSSP_name = DSSP_array_[ii].get_extended_DSSP_name();
			output << extended_DSSP_name << " ";

			string bridge_partners = DSSP_array_[ii].get_bridge_partners();
			output << bridge_partners << " ";

			output << endl;
		}
//
//		delete [] is_there_coord;
	//	delete [] is_geometry_admissible;
}

string DSSP_binary::
get_sequence	()
{
	int true_size =  DSSP_array_.size();  //

	string aa_sequence;
	for (int ii=0;ii<true_size;ii++)
	{
		char cu_aa = DSSP_array_[ii].get_one_letter_aa_name();
		aa_sequence.push_back(cu_aa);
	}

	return aa_sequence;
}


string DSSP_binary::
get_extended_DSSP_sequence	()
{
	int true_size =  DSSP_array_.size();  //

	string extended_DSSP_sequence;
	for (int ii=0;ii<true_size;ii++)
	{
		char cu_dssp = DSSP_array_[ii].get_extended_DSSP_name();
		extended_DSSP_sequence.push_back(cu_dssp);
	}

	return extended_DSSP_sequence;
}
