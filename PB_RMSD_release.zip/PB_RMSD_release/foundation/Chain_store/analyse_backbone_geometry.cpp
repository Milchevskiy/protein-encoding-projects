#include "Residue.h"
#include "../Geometry_util/Geometry_util.h"

#include <cstring>

using namespace Geometry_util;


void analyse_backbone_geometry (
	Residue *res_left,
	Residue *res_right,
	const double distance_epsilon,
	const double angle_epsilon	)
{

	static  double template_length[5]			= { 1.453, 1.53,  1.325, 1.453, 1.53 };
//  static  double template_bond_angle[4]		= { 121.0, 109.3, 115.0, 121.0};

	static  double template_bond_angle[4]		= { 2.111848395 , 1.907644872, 2.00712864, 2.111848395 };

	double coord[18];

	if ( !res_left->get_is_there_coord() || !res_right->get_is_there_coord()  )
		return ;


	memcpy(coord,	res_left->get_coord(), 9*sizeof(double) );
	memcpy(coord+9, res_right	->get_coord(), 9*sizeof(double) );

	double ds[5];
	double ba[4];
	int ii;
	for ( ii=0; ii<5; ii++)
		ds[ii] =  Geometry_util::distance (coord+3*ii,coord+3*(ii+1) );

	for (  ii=0; ii<4; ii++)
		ba[ii] =  BondAngle(coord+3*ii,	coord+3*(ii+1),	coord+3*(ii+2) );

	bool distance_flag=true;
	for (ii=0;ii<5;ii++)
		distance_flag = distance_flag	& ( fabs( ds[ii] - template_length[ii]) < distance_epsilon )  ;

	bool angle_flag=true;
	for (ii=0;ii<4;ii++)
		angle_flag = angle_flag		& ( fabs( ba[ii] - template_bond_angle[ii] ) < angle_epsilon )  ;

	bool flag = angle_flag & distance_flag;

	if (flag == true)
	{
		res_left->set_is_geometry_admissible (true);
		res_right->set_is_geometry_admissible(true);
	}
}

