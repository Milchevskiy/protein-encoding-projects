#pragma warning( disable : 4786 )

#include "PDB_util.h"

bool is_anisou_line ( const string & line,  char chain_ID  ) 
{
	string	 field			= line.substr(0,6);
	return ( field == "ANISOU");
}

