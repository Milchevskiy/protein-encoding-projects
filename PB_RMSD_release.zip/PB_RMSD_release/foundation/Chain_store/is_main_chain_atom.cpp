#pragma warning( disable : 4786 )

#include "PDB_util.h"

bool is_main_chain_atom ( const string & current_atom_name ) 
{
	return ( current_atom_name == "N" || current_atom_name == "CA" || current_atom_name == "C" );
}