#ifndef DSSP_STORE_H
#define DSSP_STORE_H

#include <string>
#include <fstream>
#include <vector>
#include <map>

#ifndef DSSP_STORE_OPERATING_MODES_H
#define DSSP_STORE_OPERATING_MODES_H

enum DSSP_store_operating_modes
{
	COMMON_USAGE,
	FILL_UP
} 
;
#endif


class	Sheduler;

using namespace std; 

class  DSSP_store
{

public:
	DSSP_store () {}  ;

	DSSP_store (	const string & pdb_file_list,
					const Abu_Maimonides_Rambam_operating_modes run_mode ) ;

	~DSSP_store ();

	string	get_sequence	() const { return sequence_; }
	string	get_extended_DSSP_sequence	() const { return extended_DSSP_sequence_; }
	string	get_tri_letter_DSSP_sequence	() const { return extended_DSSP_sequence_; }

	vector <string> get_DSSP_record_set () const 



private:
	Sheduler	*sheduler_;								
//	bool		is_empty_;

//	void add_rejected_list (
//	  ofstream &reject_stream, 
//	  const string & pdb_chain_ID,
//	  const string & exlanation );


//	void add_accepted_list (
//	  ofstream &reject_stream, 
//	  const string & pdb_chain_ID,
//	  const string & exlanation );

//	int accepted_chain_number_;
//	int rejected_chain_number_;

	string sequence_;
	string extended_DSSP_sequence_;

	vector <string> DSSP_record_set_;

};


#endif