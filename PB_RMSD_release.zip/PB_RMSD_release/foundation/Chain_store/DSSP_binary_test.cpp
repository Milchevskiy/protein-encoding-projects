#pragma warning( disable : 4786 )

#include "DSSP_binary_test.h"
#include "DSSP_binary.h"

#include "../Fragment_base/Chain_binary.h" 

#include "../CommonFunc.h"

#include <fstream>
#include <iostream>

#include "tri_to_one_and_vice_versa_aa_translation.h"

#include "../Fragment_base/accepted_chain_data.h"

using namespace std;

extern ofstream log_stream;

DSSP_binary_test::~DSSP_binary_test()
{
	cout << "DSSP_binary_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;

}
void DSSP_binary_test::check_some_chain() 
{
		DSSP_binary curr_dssp ("1F52A",COMMON_USAGE) ;

		string sequence					= curr_dssp.get_sequence();
		string extended_DSSP_sequence	= curr_dssp.get_extended_DSSP_sequence();
		string tri_letter_DSSP_sequence	= curr_dssp.get_tri_letter_DSSP_sequence();
		cout << sequence					<< endl;
		cout << extended_DSSP_sequence		<< endl;
		cout << tri_letter_DSSP_sequence	<< endl;
	
}


void DSSP_binary_test::fill_up_test ()
{
//		DSSP_binary dsb_fil("2H5CA",FILL_UP) ;
//		DSSP_binary dsb_com("2H5CA",COMMON_USAGE) ;

		DSSP_binary dsb_com("2H5CA",COMMON_USAGE) ;

		dsb_com.print_protocol();

/*		string sequence = dsb_com.get_sequence();
		string extended_DSSP = dsb_com.get_extended_DSSP_sequence();

		ofstream out ( "D:/Didona/Test/fill_up_true_dssp_seq_and_seq_test");
		if ( ! out )	
		{	
			log_stream	<< "can't create " << endl;
			cout		 << "can't create " << endl;
			exit (1);	
		}
*/
}

void DSSP_binary_test::fill_up_data ()
{

	vector < string >	accepted_chain_ID_list; 
	vector < int >      accepted_chain_lenth;
	string				path_to_accepted_chain_list_file;


	string binary_file_name ("accepted_chain_list.bin");

	fill_up_accepted_chain_data ( 
		accepted_chain_ID_list, 
		accepted_chain_lenth,
		binary_file_name );

//	accepted_chain_ID_list.push_back("3DELB");

	for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
	{
		DSSP_binary dsb_fil(accepted_chain_ID_list[ii],FILL_UP) ;
		DSSP_binary dsb_com(accepted_chain_ID_list[ii],COMMON_USAGE) ;

		dsb_com.print_protocol();
		cout << ii << " " << accepted_chain_ID_list[ii] << endl;
	}


}


void DSSP_binary_test::fill_up_true_dssp_seq_and_seq_test ()
{
		DSSP_binary dsb_fil("2H5CA",COMMON_USAGE) ;

		ofstream out ( "D:/Didona/Test/fill_up_true_dssp_seq_and_seq_test");
		if ( ! out )	
		{	
			log_stream	<< "can't create " << endl;
			cout		 << "can't create " << endl;
			exit (1);	
		}

		string sequence					= dsb_fil.get_sequence();
		string extended_DSSP_sequence	= dsb_fil.get_extended_DSSP_sequence();
		string tri_letter_DSSP_sequence	= dsb_fil.get_tri_letter_DSSP_sequence();

		for (int ii=0;ii<sequence.size();ii++)
		{
			out << sequence[ii]	<< '\t';
			out << extended_DSSP_sequence[ii]	<<  '\t';;
			out << tri_letter_DSSP_sequence[ii]	<< endl;
		}
}