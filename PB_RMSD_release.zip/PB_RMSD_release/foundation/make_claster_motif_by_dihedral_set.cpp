#include "Fragment_base/Fragment_base_subtle.h"

#include "by_Qmol/kabsch_stolen.h"

#include "Fragment_base/Chain_binary.h"

#include "Cluster_set/Cluster_set.h"
#include "CommonFunc.h"

#include "BioPolymerMechanics/foundation/Model.h"
#include "BioPolymerMechanics/foundation/Core_iterator.h"
#include "BioPolymerMechanics/foundation/Atom.h"

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

using namespace std;

#ifndef GET_ANGLES_FROM_TUNE_FILE_H
#define GET_ANGLES_FROM_TUNE_FILE_H

void	get_angles_from_tune_file (
		vector <vector <double > >  & Phi_set,
		vector <vector <double > >  & Psi_set,
		vector <vector <double > >  & Omega_set,
		vector <string>				& conformation_name,
		const string				& data_filename);

#endif

extern ofstream log_stream;

double ** make_claster_motif_by_dihedral_set(
	string & path_to_dihedral_store,
	int & number_of_classes,
	int & fragment_length)
{
	double **claster_motif_coordinates;

	ifstream  in_stream ( path_to_dihedral_store.c_str() );
	if ( ! in_stream )	{
		log_stream << "ERROR -  can't find tune file" << path_to_dihedral_store << endl;
		cout       << "ERROR -  can't find tune file" << path_to_dihedral_store << endl;
		exit (1);
	}
	vector <vector <double> >	Phi_set;
	vector <vector <double> >	Psi_set;
	vector <vector <double> >	Omega_set;
	vector <string> conformation_name;

	get_angles_from_tune_file (
		Phi_set,
		Psi_set,
		Omega_set,
		conformation_name,
		path_to_dihedral_store);

	number_of_classes = Omega_set.size();
	fragment_length = Omega_set[0].size();

	Model* model = new Model;

	//int len_seq = 5;
	model->join_aminoacid("Gly",1);
	for (int ii=0;ii<fragment_length-1;ii++)
		model->join_aminoacid("Gly",0);

	claster_motif_coordinates = new double*[number_of_classes];
	for (int ii = 0; ii < number_of_classes; ii++)
		claster_motif_coordinates[ii] = new double[fragment_length * 9];

	vector <double> phi, psi, ome;
	phi.resize(fragment_length);
	psi.resize(fragment_length);
	ome.resize(fragment_length);;

	model->init_phi_psi_owega_backbone_set ();   // ������ ��� ������������

	for (int kk=0;kk<Phi_set.size(); kk++)
	{
		for (int ii=0; ii < fragment_length; ii++ )
		{

			double phi = Phi_set[kk][ii];
			double psi = Psi_set[kk][ii];
			double ome = Omega_set[kk][ii];

			model->set_phi(ii,Phi_set[kk][ii]*Pythagorean_Number ()/180);
			model->set_psi(ii,Psi_set[kk][ii]*Pythagorean_Number ()/180);
			model->set_ome(ii,Omega_set[kk][ii]*Pythagorean_Number()/180);
		}

		vector < Atom * > core_atoms = model->get_core_atoms();
		Atom * initial_atom = core_atoms.front();
		vector < double > matrix; matrix.resize(9);
		matrix[0]=1;
		matrix[4]=1;
		matrix[8]=1;
		initial_atom->set_rotation_matrix(matrix);
		initial_atom->set_x(0);
		initial_atom->set_y(0);
		initial_atom->set_z(0);

		model->calc_cartesain_coordinates ( initial_atom );

	//	model->save_as("aaaa.ent");

	for (int tt=0;tt<core_atoms.size(); tt++)
		{
			string pdb_atom_name = core_atoms[tt]->get_pdb_atom_name();
			if ( pdb_atom_name == "N" || pdb_atom_name == "CA" || pdb_atom_name == "C") {
				claster_motif_coordinates[kk][3*tt]=core_atoms[tt]->x();
				claster_motif_coordinates[kk][3*tt+1]=core_atoms[tt]->y();
				claster_motif_coordinates[kk][3*tt+2]=core_atoms[tt]->z();
				cout << claster_motif_coordinates[kk][3*tt] << " ";
				cout << claster_motif_coordinates[kk][3*tt+1] << " ";
				cout << claster_motif_coordinates[kk][3*tt+2] << endl;
			}
		}
		// ��� ��������� ����������
	}
	return claster_motif_coordinates;
}
