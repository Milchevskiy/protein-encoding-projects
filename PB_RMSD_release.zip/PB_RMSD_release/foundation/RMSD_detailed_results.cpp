#include "CommonFunc.h"
#include "Censorship.h"

#include "Fragment_base/Chain_binary.h"
//#include "Chain_store/Chain_Residue_Set.h"
#include "PB_RMSD.h"
#include "pb16_to_index.h"
#include "tri_to_one_and_vice_versa_aa_translation.h"

extern ofstream log_stream;

void   RMSD_detailed_results (
        Chain_binary *chain,
        double **claster_motif_coordinates,
        const int fragment_length,
        const int number_of_classes,
        const string & current_extension )
{

/// Residue sequence number

        string output_file = chain->get_pdb_chain_ID() + current_extension;

        ofstream  res_out ( output_file.c_str() );
        if ( ! res_out )	{
            cout				<< "Can't create "   << output_file << endl;
            log_stream			<< "Can't create "   << output_file << endl;
            exit (1);
        }


/// Handle RMSD
        vector < vector < double > >   set_of_coordinate_in_clasters_system;
        chain->	positioning_chain_by_clasters_set(
            claster_motif_coordinates,
            fragment_length,
            number_of_classes,
            set_of_coordinate_in_clasters_system);

        vector <int> PB_index_set = get_PB_index_set (set_of_coordinate_in_clasters_system) ;


/// Handle RMSDA
        vector < vector < double > >   set_of_coordinate_in_clasters_system_RMSDA;
        chain->	positioning_chain_by_clasters_set_by_RMSDA(
            claster_motif_coordinates,
            fragment_length,
            number_of_classes,
            set_of_coordinate_in_clasters_system_RMSDA);
        vector <int> PB_index_set_RMSDA = get_PB_index_set (set_of_coordinate_in_clasters_system_RMSDA, -9999.0) ;



        int *serial_index   =   chain->get_serial_index();
        string sequence     =   chain->get_sequence();
        vector<string> chain_residue_number = chain->get_in_chain_residue_number();


        int shift = fragment_length/2;

        res_out << "//AA3    - residue name one letter code" << endl;
        res_out << "//AA1    - residue name three-letter code"<< endl;
        res_out << "//Ser.ind - residue serial number in aminoacid sequence"<< endl;
        res_out << "//Re.se.nu - Residue sequence number in PDB file"<< endl;
        res_out << "//PB - nearest Protein Block ID letter for RMSD assignment"<< endl;
        res_out << "//RMSD - RMSD (angstrom) between current structure centered in this residue to nearest Protein Block" << endl;

        res_out << "//PB - nearest Protein Block ID letter for RMSDA assignment"<< endl;
        res_out << "//RMSDA - RMSDA (degree) between current structure centered in this residue to nearest Protein Block" << endl;


        res_out << endl;


        PutVa("AA3",res_out, 5,2,'l');
        PutVa("AA1",res_out, 5,2,'l');
        PutVa("Ser.ind",res_out, 10,1,'l');
        PutVa("Re.se.nu",res_out, 10,1,'l');
        PutVa("PB->",res_out, 3,1,'l');
        PutVa("RMSD",res_out,6,2,'l');

        res_out << "     ";

        PutVa("PB->",res_out, 3,1,'l');
        PutVa("RMSDA",res_out,6,2,'l');


        res_out << endl;


        for (int ii=0;ii<shift;ii++)
        {


            PutVa(one_to_tri_letter_aa ( sequence[ii] ),res_out, 5,2,'l');
            PutVa(sequence[ii],res_out, 5,2,'l');
            PutVa(serial_index[ii],res_out, 10,1,'l');
            PutVa(chain_residue_number[ii],res_out, 10,1,'l');
            PutVa('*',res_out, 3,1,'l');
            PutVa('*',res_out, 8,2,'l');
            res_out << "     ";
            PutVa('*',res_out, 3,1,'l');
            PutVa('*',res_out, 8,2,'l');

            res_out << endl;
        }

        int assignment_length = set_of_coordinate_in_clasters_system.size();
        for (int ii=0;ii<assignment_length;ii++)
        {
            char letter_RMSD = index_to_16pb(PB_index_set[ii]);
            double currentRMSD = set_of_coordinate_in_clasters_system[ii][ PB_index_set[ii] ];

            char letter_RMSDA = index_to_16pb(PB_index_set_RMSDA[ii]);
            double currentRMSDA = set_of_coordinate_in_clasters_system_RMSDA[ii][ PB_index_set_RMSDA[ii] ];


            PutVa(one_to_tri_letter_aa ( sequence[ii+shift] ),res_out, 5,2,'l');
            PutVa(sequence[ii+shift],res_out, 5,2,'l');
            PutVa(serial_index[ii+shift],res_out, 10,1,'l');

            PutVa(chain_residue_number[ii+shift],res_out, 10,1,'l');

            PutVa(letter_RMSD,res_out, 3,1,'l');
            if (letter_RMSD=='*')
                PutVa("*  ",res_out,8,2,'l');
            else
            {
                res_out <<"->";
                PutVaDouble(currentRMSD,res_out,6,2,'l');
            }

            res_out << "     ";

            PutVa(letter_RMSDA,res_out, 3,1,'l');
            if (letter_RMSDA=='*')
                PutVa("*  ",res_out,8,2,'l');
            else
            {
                res_out <<"->";
                PutVaDouble(currentRMSDA,res_out,6,2,'l');
            }



            res_out << endl;

        }

        for (int ii=assignment_length+shift; ii<assignment_length+2*shift;ii++)
        {
            PutVa(one_to_tri_letter_aa ( sequence[ii] ),res_out, 5,2,'l');
            PutVa(sequence[ii],res_out, 5,2,'l');
            PutVa(serial_index[ii],res_out, 10,1,'l');
            PutVa(chain_residue_number[ii],res_out, 10,1,'l');
            PutVa('*',res_out, 3,1,'l');
            PutVa('*',res_out, 8,2,'l');
            res_out << "     ";
            PutVa('*',res_out, 3,1,'l');
            PutVa('*',res_out, 8,2,'l');

            res_out << endl;
        }

}
