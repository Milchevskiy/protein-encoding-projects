#ifndef EIGENVALUES3D_H
#define EIGENVALUES3D_H

void EigenValues3D(double a[3][3], double val[3]);
bool EigenSystem3D(double a[3][3], double vect[3][3], double val[3]);


#endif
