
#include "kabsch_stolen.h"
#include "../Geometry_util/Fragmrent_tranformation.h"

double kabsch_rmsd (double *ref, double *vec, double *w, const int num, bool & error_flag)
{
	centroid ( ref, num/3); 
	centroid ( vec, num/3);

	kabsch_stolen	(ref, vec, w, num, error_flag );

	if (error_flag)
		return -1;
	
	double RMSD = rmsd	(ref, vec, w, num );
	return RMSD;
}

double kabsch_rmsd_flexible_centroid(double *ref, double *vec, double *w, const int num, bool & error_flag)
{
	centroid_no_idiotic(ref, num );
	centroid_no_idiotic(vec, num );

	kabsch_stolen(ref, vec, w, num, error_flag);

	if (error_flag)
		return -1;

	double RMSD = rmsd(ref, vec, w, num);
	return RMSD;
}