
#include <iostream>

using namespace std;

void usage_print ()
{
    cout << "PB_RMSD [option] input-file chain-ID" << endl;

    cout << "\tinput-file\t standard PDB (Protein Data Bank) file"<<endl;
    cout << "\tchain-ID\t choosern protein chain ID"<<endl;
    cout << "\t-h\t\tDisplay this message" << endl;
    cout << "\t-v\t\tprint version" << endl ;
    cout << "\t-s\t\tshort result only" << endl << endl;





    cout << "USAGE EXAMPLE: PB_RMSD pdb8acn.ent A"<< endl;

    cout << "\tprocesses a protein chain 'A' from file pdb8acn.ent" << endl << endl;

    cout << "ATTENSION: setting rarely changed parameters in a file \"sheduler\" " << endl<< endl;;
}
