#ifndef PB_RMSD_H_INCLUDED
#define PB_RMSD_H_INCLUDED

#include "CommonFunc.h"
#include "Fragment_base/Chain_binary.h"

double ** fill_up_PB_parameters (
    const string &path_to_PB_data,
    int &fragment_length,
    int &number_of_classes );

vector <int>  get_PB_index_set (
    vector < vector < double > >   & set_of_coordinate_in_clasters_system);


vector <int>  get_PB_index_set (
    vector < vector < double > >   & set_of_coordinate_in_clasters_system,
    double  flag_value);

void output_result(
     string &pdb_chain_ID,
     vector <int> &PB_index_set,
     string &sequence,
     string path_to_assignment_result );


void   RMSD_detailed_results (
        Chain_binary *chain,
        double **claster_motif_coordinates,
        const int fragment_length,
        const int number_of_classes,
        const string & current_extension );

void   RMSD_short_results (
        Chain_binary *chain,
        double **claster_motif_coordinates,
        const int fragment_length,
        const int number_of_classes,
        const string & current_extension );



#endif // PB_RMSD_H_INCLUDED
