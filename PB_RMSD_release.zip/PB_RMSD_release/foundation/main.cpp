#pragma warning( disable : 4786 )


#include "Censorship.h"

#include <iostream>
#include <cstdlib>

#include <cstdio>

//#include "ServerUtil/ServerUtil.h"


using namespace std;

Censorship configuration;
ofstream log_stream;

using namespace std;

void usage_print() ;

///void rmsd_assignment (const string & sourcefilename,const char chain_ID);

void rmsd_assignment (
    const string & sourcefilename,
    const char chain_ID,
    string  &short_flag);


int main(int argc,char  **argv)
{
	string  output_file ("log");
	log_stream.open (output_file.c_str()  ); // fix log or not log

	string current_version = "PB_RMSD version 1.0 2021-01-25";

	char chain_ID;
	bool is_setted_chain_ID = false;
    bool is_exist_source_frag = false;

    string sourcefilename;

//    string protocol_flag    = "Y";
//    string detailed_flag    = "Y";
    string short_flag       = "No";



	for (int ii=1;ii<argc;ii++)
	{
		if (argv[ii][0]=='-')
		{
			switch (argv[ii][1])
			{
                case 'h' :
                    usage_print();
                    exit(-1);
                case 'v' :
                    cout << current_version << endl;
                    exit(-1);
                case 's' :
                    short_flag = "Y";
                    break;
                default:
                   cout << "unrecognised option: -" << argv[ii] << endl;
                   exit(-1);
			}
		}
	}

    if (argv[1]!=NULL)
        sourcefilename = string (argv[1]);
    else {
          cout << "PDB file was not specified. " << endl;
          log_stream << "PDB file was not specified. " << endl;

          cout << "SEE USAGE:" << endl << endl;
          usage_print();
          exit (-1);

    }

    if (argv[2]!=NULL)
        chain_ID = argv[2][0];
    else {
        cout << "Chain ID was not specified. " << endl;
        log_stream << "Chain ID was not specified. " << endl;

        cout << "SEE USAGE:" << endl << endl;
        usage_print();

        exit(-1);
    }




	rmsd_assignment (
        sourcefilename,
        chain_ID,
        short_flag);

//	configuration.init("config") ;



}

