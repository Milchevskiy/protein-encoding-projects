#ifndef RMSDA_FAIL_TEST_INCLUDED
#define RMSDA_FAIL_TEST_INCLUDED

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

// Тут куча функций и тестов нужных только для выведениф на чистую воду
// жулика De Brewern & K с его говеным подходом к использованию RMSDA

class  RMSDA_fail_test: public Simple_test
{
public:
	~RMSDA_fail_test();

    void run()
    {
        dummy_usefull_sample();
    //    calc_RMSDA_test ();
        //creating_table_for_paper ();

	}
	void dummy_usefull_sample();
	void calc_RMSDA_test ();
	void creating_table_for_paper ();
};


#endif // RMSDA_FAIL_TEST_INCLUDED
