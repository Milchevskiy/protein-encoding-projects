//#include "../Fragment_base/Fragment_base_subtle.h"

#include "../CommonFunc.h"
#include "../Censorship.h"

#include "../Fragment_base/Chain_binary.h"

#include "../Fragment_base/fill_up_fragment_torsion_angles.h"

#include <fstream>

#include <iostream>
#include <sstream>

#include <cassert>

using namespace std;

extern ofstream log_stream;

double calc_RMSDA(
    const double *frag_1,
    const double *frag_2,
    const int fragment_length)
{

    vector < double > tors_1;
    vector < double > tors_2;

    fill_up_fragment_torsion_angles (
         frag_1,
         fragment_length,
         tors_1,'d');

    fill_up_fragment_torsion_angles (
         frag_2,
         fragment_length,
         tors_2,'d');

     int tors_num = tors_1.size();

     double sum =0;

     for (int ii=0;ii<tors_num;ii++)
     {
        double test1=tors_1[ii];
        double test2=tors_2[ii];

        if(tors_1[ii]<0)
            tors_1[ii]=360-fabs(tors_1[ii]);

       if(tors_2[ii]<0)
            tors_2[ii]=360-fabs(tors_2[ii]);

        if (ii%3==1)
            continue;

        double difference = test1-test2;
        if ( fabs(difference) > 180 )
            difference = 360 - fabs(difference);

       sum +=difference*difference ;

     }

     int psi_phi_num = 2*(fragment_length-1);
     sum /=psi_phi_num;

     double rmsda = sqrt(sum);

     return rmsda;
}
