#pragma warning( disable : 4786 )

#include "../Fragment_base/Fragment_base_subtle.h"

#include "../CommonFunc.h"
#include "../Censorship.h"

#include "../Fragment_base/Chain_binary.h"

#include "RMSDA_fail_test.h"
#include "RMSDA_fail.h"

#include "../Pair_int_double.h"
#include "../by_Qmol/kabsch_stolen.h"


#include <fstream>
#include <iostream>
#include <sstream>

#include <cassert>

#include "../Fragment_base/fill_up_fragment_torsion_angles.h"

using namespace std;

extern ofstream log_stream;

RMSDA_fail_test::
~RMSDA_fail_test()
{
	cout << "RMSDA_fail_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}
void RMSDA_fail_test::
dummy_usefull_sample()
{
    Fragment_base_subtle ob("5b",FRAGMENT_BASE_SUBTLE_COMMON_USAGE);

    int index_1 = 2861604;
    int index_2 = 1903675;

    int fragment_length =    ob.get_fragment_length();

    double *coord_1 = new double [ fragment_length * 9 * sizeof (double) ];
    double *coord_2 = new double [ fragment_length * 9 * sizeof (double) ];

   	double *w	= new double [fragment_length*9];
	for ( int kk=0;kk<(fragment_length*9);kk++)		w[kk] = 1;


    bool is_there_coord_1 = ob.get_coord(index_1,coord_1);
    bool is_there_coord_2 = ob.get_coord(index_2,coord_2);


    bool error_flag=true;;
    double current_distance = kabsch_rmsd (
            coord_1,
            coord_2,
            w,
            3*fragment_length,
            error_flag);


     int chain_serial_number_1,position_in_chain_1;
    int chain_serial_number_2,position_in_chain_2;


   // ob.get_coord (index_1,frag_1 );
  //  ob.get_coord (index_2,frag_2 );

     ob.get_chain_index (
        index_1,
		&chain_serial_number_1,
		&position_in_chain_1 );

     ob.get_chain_index (
        index_2,
		&chain_serial_number_2,
		&position_in_chain_2 );


	string PDB_id_1 = 	ob.get_accepted_chain_ID_by_index(chain_serial_number_1);
	string PDB_id_2 = 	ob.get_accepted_chain_ID_by_index(chain_serial_number_2);

    Chain_binary cb_1( PDB_id_1);
	Chain_binary cb_2( PDB_id_1);

	string sequence_1 = cb_1.get_sequence();
    string sequence_2 = cb_2.get_sequence();

    string sub_sequence_1 = sequence_1.substr(position_in_chain_1,fragment_length);
    string sub_sequence_2 = sequence_2.substr(position_in_chain_2,fragment_length);



    delete [] coord_1 ;
    delete [] coord_2 ;


}

void RMSDA_fail_test::
creating_table_for_paper()
{
    int Iteration_number = 10000;

    Fragment_base_subtle ob("5b",FRAGMENT_BASE_SUBTLE_COMMON_USAGE);

    string host_dir = ob.get_host_dir();
    string path_to_protocol_file = host_dir + string ("creating_table_for_paper.txt");

    int total_fragment_number = ob.get_total_fragment_number();

    ofstream  out( path_to_protocol_file.c_str() );

	if ( ! out)	{
		log_stream << "can't create file" << path_to_protocol_file << endl;
		cout       << "can't create file" << path_to_protocol_file << endl;
		exit (1);
	}

	 int fragment_length =    ob.get_fragment_length();

    double *coord_1 = new double [ fragment_length * 9 * sizeof (double) ];
    double *coord_2 = new double [ fragment_length * 9 * sizeof (double) ];

   	double *w	= new double [fragment_length*9];
	for ( int kk=0;kk<(fragment_length*9);kk++)		w[kk] = 1;

	double *frag_1  = new double [fragment_length*9];
    double *frag_2  = new double [fragment_length*9];


	for (int ii=0;ii<Iteration_number;ii++)
	{
        int index_1 = rand()%total_fragment_number;
        int index_2 = rand()%total_fragment_number;

        bool is_there_coord_1 = ob.get_coord(index_1,coord_1);
        bool is_there_coord_2 = ob.get_coord(index_2,coord_2);

        bool error_flag=true;;
        double current_distance = kabsch_rmsd (
                coord_1,
                coord_2,
                w,
                3*fragment_length,
                error_flag);

//--------------------------------------

       int chain_serial_number_1,position_in_chain_1;
       int chain_serial_number_2,position_in_chain_2;


       ob.get_coord (index_1,frag_1 );
        ob.get_coord (index_2,frag_2 );

/*         ob.get_chain_index (
            index_1,
            &chain_serial_number_1,
            &position_in_chain_1 );

         ob.get_chain_index (
            index_2,
            &chain_serial_number_2,
            &position_in_chain_2 );


        string PDB_id_1 = 	ob.get_accepted_chain_ID_by_index(chain_serial_number_1);
        string PDB_id_2 = 	ob.get_accepted_chain_ID_by_index(chain_serial_number_2);

        Chain_binary cb_1( PDB_id_1);
        Chain_binary cb_2( PDB_id_1);

        string sequence_1 = cb_1.get_sequence();
        string sequence_2 = cb_2.get_sequence();

        string sub_sequence_1 = sequence_1.substr(position_in_chain_1,fragment_length);
        string sub_sequence_2 = sequence_2.substr(position_in_chain_2,fragment_length);

*/
        double rmsda = calc_RMSDA(frag_1,frag_2,fragment_length);


        PutVa (index_1,out,8, 3,'l');
//        PutVa (PDB_id_1,out,8, 3,'l');
//        PutVa (position_in_chain_1,out,8, 3,'l');
//        PutVa (sub_sequence_1,out,8, 3,'l');
//        out << '|';

        PutVa (index_2,out,8, 3,'l');
//        PutVa (PDB_id_2,out,8, 3,'l');
//        PutVa (position_in_chain_2,out,8, 3,'l');
//        PutVa (sub_sequence_2,out,8, 3,'l');
        out << ':';


        PutVaDouble (rmsda,out,12, 3,'l');
        PutVaDouble (current_distance,out,12, 3,'l');
        out << endl;

    }
    delete [] coord_1;
    delete [] coord_2;
    delete [] w;

    delete []   frag_1;
    delete []   frag_2;
}
void RMSDA_fail_test::
calc_RMSDA_test()
{
    Fragment_base_subtle ob("5b",FRAGMENT_BASE_SUBTLE_COMMON_USAGE);

    int fragment_length =    ob.get_fragment_length();

  	double *frag_1  = new double [fragment_length*9];
    double *frag_2  = new double [fragment_length*9];

    int index_1 = 333;
    int index_2 = 666;

    int chain_serial_number_1,position_in_chain_1;
    int chain_serial_number_2,position_in_chain_2;


    ob.get_coord (index_1,frag_1 );
    ob.get_coord (index_2,frag_2 );

     ob.get_chain_index (
        index_1,
		&chain_serial_number_1,
		&position_in_chain_1 );

     ob.get_chain_index (
        index_2,
		&chain_serial_number_2,
		&position_in_chain_2 );


	string PDB_id_1 = 	ob.get_accepted_chain_ID_by_index(index_1);
	string PDB_id_2 = 	ob.get_accepted_chain_ID_by_index(index_2);

    Chain_binary cb_1( PDB_id_1);
	Chain_binary cb_2( PDB_id_1);

	string sequence_1 = cb_1.get_sequence();
    string sequence_2 = cb_2.get_sequence();

    string sub_sequence_1 = sequence_1.substr(position_in_chain_1,fragment_length);
    string sub_sequence_2 = sequence_2.substr(position_in_chain_2,fragment_length);


    double rmsda = calc_RMSDA(frag_1,frag_2,fragment_length);

    vector < double > tors_1;
    vector < double > tors_2;

    fill_up_fragment_torsion_angles (
         frag_1,
         fragment_length,
         tors_1,'d');

    fill_up_fragment_torsion_angles (
         frag_2,
         fragment_length,
         tors_2,'d');

    string out_file_name = "../Test/calc_RMSDA_test";

   ofstream out(out_file_name.c_str());
    if (!out)
    {
        cout << "out file problem" << endl;
        exit(-1);
    }

    out << chain_serial_number_1 << "\t" << PDB_id_1 << "\t" << sub_sequence_1 << endl;
    out << chain_serial_number_2 << "\t" << PDB_id_2 << "\t" << sub_sequence_2 << endl;

    out << "RMSDA by function = " << rmsda << endl;

    int tors_number = tors_1.size();
    double sum=0;
    for (int ii=0;ii<tors_1.size();ii++)
    {
        double test1=tors_1[ii];
        double test2=tors_2[ii];

        PutVaDouble (test1,out,12, 3,'l');
        PutVaDouble (test2,out,12, 3,'l');

        if(tors_1[ii]<0)
            test1=360-fabs(tors_1[ii]);

        if(tors_2[ii]<0)
            test2=360-fabs(tors_2[ii]);

        double difference = test2-test1;
        if ( fabs(difference) > 180 )
            difference = 360- fabs(difference);


        if (ii%3==1)
            continue;
        else
        {
            PutVaDouble (test1,out,12, 3,'l');
            PutVaDouble (test2,out,12, 3,'l');

            PutVaDouble (difference,out,12, 3,'l');
            PutVaDouble (difference*difference,out,12, 3,'l');

            out<< endl;
            sum+=difference*difference;
        }
    }
    int psi_phi_num = 2*(fragment_length-1);
    sum /=psi_phi_num;

    rmsda = sqrt(sum);


    out << "RMSDA by test = " << rmsda << endl;

    delete []   frag_1;
    delete []   frag_2;
}

