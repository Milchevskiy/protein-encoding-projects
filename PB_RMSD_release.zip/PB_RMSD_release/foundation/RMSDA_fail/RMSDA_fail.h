#ifndef RMSDA_FAIL_H_INCLUDED
#define RMSDA_FAIL_H_INCLUDED

double calc_RMSDA(
    const double *frag_1,
    const double *frag_2,
    const int fragment_length);

#endif // RMSDA_FAIL_H_INCLUDED
