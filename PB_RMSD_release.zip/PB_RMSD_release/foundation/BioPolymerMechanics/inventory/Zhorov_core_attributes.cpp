
#include "Zhorov_core_attributes.h"

#include "Geometry_util.h"

#include <memory.h>

Zhorov_core_attributes::Zhorov_core_attributes()
{
    rotation_matrix_[0] = 0;
    rotation_matrix_[1] = 0;
    rotation_matrix_[2] = 0;
    rotation_matrix_[3] = 0;
    rotation_matrix_[4] = 0;
    rotation_matrix_[5] = 0;
    rotation_matrix_[6] = 0;
    rotation_matrix_[7] = 0;
    rotation_matrix_[8] = 0;
}

void Zhorov_core_attributes::set_vector_model( const Array < double > & vector_model )
{
    vector_model_ = vector_model;
}
void Zhorov_core_attributes::set_rotation_matrix(double a[9] )
{
    memcpy( rotation_matrix_, a ,9 * sizeof(double) );
}
double * Zhorov_core_attributes::rotation_matrix()
{
    INVARIANT;

    return rotation_matrix_;
}

void Zhorov_core_attributes::get_ray(int i, double * ray) const
{
		//fix 
		double check_unit_vecor = vector_model_ [3*i]*vector_model_ [3*i] + vector_model_ [3*i+1]*vector_model_ [3*i+1] + vector_model_ [3*i+2]*vector_model_ [3*i+2] - 1;
 //   REQUIRE("Unit vector",
   //     vector_model_ [3*i]*vector_model_ [3*i] + vector_model_ [3*i+1]*vector_model_ [3*i+1] + vector_model_ [3*i+2]*vector_model_ [3*i+2] - 1 < Geometry_util::epsilon_float() );

    ray[0]= vector_model_ [3*i] ;
    ray[1]= vector_model_ [3*i+1] ;
    ray[2]= vector_model_ [3*i+2] ;

}

bool Zhorov_core_attributes::invariant() const
{
    //fix
    /*if( rotation_matrix_[0] == 0 &&
        rotation_matrix_[1] == 0 &&
        rotation_matrix_[2] == 0 &&
        rotation_matrix_[3] == 0 &&
        rotation_matrix_[4] == 0 &&
        rotation_matrix_[5] == 0 &&
        rotation_matrix_[6] == 0 &&
        rotation_matrix_[7] == 0 &&
        rotation_matrix_[8] == 0   )
        return false;
    //*/
    return true;
}
