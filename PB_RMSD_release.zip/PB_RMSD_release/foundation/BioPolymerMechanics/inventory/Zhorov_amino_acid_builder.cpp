
#include "Zhorov_amino_acid_builder.h"

#include "Factory.h"
#include "Bond.h"
#include "Aminoacid_name_translator.h"
#include "Log.h"
#include "Config.h"
#include "Geometry_util.h"
#include "Pdb_attributes.h"
#include "Zhorov_model.h"

#include <fstream>
#include <string>

Zhorov_atom & Zhorov_amino_acid_builder::
new_terminal_atom( Element element )        //fix to prototype
{
    Zhorov_atom & new_atom = model().new_terminal_atom( element );
    new_atom.add_pdb_attributes( new Pdb_attributes() );
    return new_atom;
}

Zhorov_atom & Zhorov_amino_acid_builder::
new_core_atom( Element element )            //fix to prototype
{
    Zhorov_atom & new_atom = model().new_core_atom( element );
    new_atom.add_pdb_attributes( new Pdb_attributes() );
    return new_atom;
}

using namespace std;
namespace
{
    bool residue_name_is_a_name_of_natural_aminoacid( const Text & );
}

void Zhorov_amino_acid_builder::
new_aminoacid( const Text & residue_name, 
			   Array_of_references< Zhorov_atom > &   all_atoms,
			   Array_of_references< Zhorov_atom > &   core_atoms )
{
    REQUIRE( "", residue_name_is_a_name_of_natural_aminoacid( residue_name ) );

    const Text & name = aminoacid_name().translate( residue_name );

    Text path = Text( DIR_20aminoacids ) + residue_name + ".own";
    ifstream in	( path.c_str() );
    if ( ! in ) throw Flaw( Text( Text( "Can't find file " ) + residue_name + ".own" ) + " in " + __FILE__ + ", line " + __LINE__ );

    //Zhorov_atoms                                 core_atoms;
    //Array_of_references < Zhorov_terminal_atom > all_atoms;
    int ii;
    std::string buff;

    getline( in, buff );
    int number_of_atoms = atoi( buff.c_str() );

    Array < int > neighbours_1;
    Array < int > neighbours_2;
    Array < int > neighbours_3;
    Array < int > neighbours_4;

    //  atoms reading
    
    for ( ii = 0; ii < number_of_atoms ; ii++ )
    {
        int zhorov_atom_index;
        std::string element_name;
        std::string pdb_atom_name;
        std::string zhorov_atom_name;
        int residue_index;
        std::string residue_name;
        int neighbour1, neighbour2, neighbour3, neighbour4;
        double bond_length;
        double charge;

        in  >> zhorov_atom_index >> element_name >> pdb_atom_name
        >> zhorov_atom_name  >> residue_index >> residue_name
        >> neighbour1 >> neighbour2 >> neighbour3 >> neighbour4
        >> bond_length >> charge;

        Element element( element_name.c_str() );

        neighbours_1.push_back( neighbour1 );
        neighbours_2.push_back( neighbour2 );
        neighbours_3.push_back( neighbour3 );
        neighbours_4.push_back( neighbour4 );

        // Create atom =========================================================

//        Atom * current_atom = make_atom( Element( element_name.c_str() ) );
//        model_.add_atom( current_atom );
        Ref< Zhorov_atom > atom; 

        //if ( neighbour2 == 0 && ii != 0 )
		if ( neighbour2 == 0  )
        {
//            atom = model().new_terminal_atom( element );
            atom = new_terminal_atom( element );
            all_atoms.push_back( atom() );
        }
        else
        {
//            Zhorov_atom & zhorov_atom = model().new_core_atom( element );
            Zhorov_atom & zhorov_atom = new_core_atom( element );
            atom = zhorov_atom;

            all_atoms.push_back( atom()  );
            core_atoms.push_back         ( zhorov_atom );
        } //*/

        CHECK("", atom().has_pdb_attributes() );
        atom().set_zhorov_atom_index    ( zhorov_atom_index );
        atom().pdb().set_name           ( pdb_atom_name.c_str() );
        atom().set_zhorov_atom_name     ( zhorov_atom_name.c_str() );
        atom().pdb().set_residue_number ( residue_index );
        atom().pdb().set_residue_name   ( residue_name.c_str() );
        atom().set_length               ( bond_length );
//fix        atom().set_charge           ( charge );
    }

    //  assign bonds for atoms
    for ( ii = 0; ii < number_of_atoms ; ii++ )
    {

        if ( neighbours_1[ ii ] != 0 )
        {
            int n = neighbours_1[ ii ] - 1;
            Zhorov_atom & atom = all_atoms [ n ];
            all_atoms[ ii ].add_neighbor( atom );
        }
        if ( neighbours_2[ ii ] != 0 )
        {
            int n = neighbours_2[ ii ] - 1;
            Zhorov_atom & atom = all_atoms [ n ];
            all_atoms[ ii ].add_neighbor( atom );
        }

        if ( neighbours_3[ ii ] != 0 )
        {
            int n = neighbours_3[ ii ] - 1;
            Zhorov_atom & atom = all_atoms [ n ];
            all_atoms[ ii ].add_neighbor( atom );
        }

        if ( neighbours_4[ ii ] != 0 )
        {
            int n = neighbours_4[ ii ] - 1;
            Zhorov_atom & atom = all_atoms [ n ];
            all_atoms[ ii ].add_neighbor( atom );
        }
    }

    string dummy;
    int number_of_zhozov_atoms;
    in  >> dummy >> dummy >> number_of_zhozov_atoms;

    // vector model reading
  //  core_atoms.first();

    Array < double > vector_model ;
    /*vector_model.push_back ( 1 );
    vector_model.push_back ( 0 );
    vector_model.push_back ( 0 );
    core_atoms[0].set_vector_model ( vector_model );
*/
    //for ( core_atoms.next(); core_atoms.is_valid(); core_atoms.next() )
    for (  ii=0; ii< core_atoms.size(); ++ii )
    {
        in  >> dummy ;
		in  >> dummy ;

        vector_model.clear();;
        vector_model.push_back ( -1 );
        vector_model.push_back ( 0 );
        vector_model.push_back ( 0 );

			int check_number_of_neighbors = core_atoms[ii].number_of_neighbors();

        for ( int jj = 0; 
              jj < 3 * core_atoms[ii].number_of_neighbors()- 3; jj++ )
        {
               double value;
               in  >> value;
               vector_model.push_back ( value );
        }
        core_atoms[ii].core().set_vector_model ( vector_model );
    }

    in  >> dummy;
    in  >> dummy;
    in  >> number_of_zhozov_atoms;

    // dihedral angles reading
   // core_atoms.first();
   // for ( core_atoms.next(); core_atoms.is_valid(); core_atoms.next() )
   for (  ii=0; ii< core_atoms.size(); ++ii )
    {
        double dihedral;
        in >> dummy ;
        in >> dummy;
        in >> dihedral ;
        in >> dummy ;
        in >> dummy ;
        in >> dummy ;
        in >> dummy ;
        core_atoms[ii].core().set_dihedral ( dihedral );
    }
}

void Zhorov_amino_acid_builder::
add_aminoacid(  const Text & residue_name,
                const double Phi, const double Psi, const double Omeg )
{
	Array_of_references< Zhorov_atom >  core_atoms;
	Array_of_references< Zhorov_atom >  aminoacid;

    new_aminoacid( residue_name, aminoacid, core_atoms );

	for( int i=0;  i<aminoacid.size();  ++i )
		zhorov_peptide_.push_back( aminoacid[i] );

    Zhorov_atom & patient_N = aminoacid[1];
    CHECK("", patient_N.is_core_atom() );
//	patient_N.set_dihedral(Phi) ;
	patient_N.core().set_dihedral(Omeg) ;

    Zhorov_atom & patient_CA = aminoacid[2];
    CHECK("", patient_CA.is_core_atom() );
	patient_CA.core().set_dihedral(Phi) ;

    Zhorov_atom & patient_C = aminoacid[3];
    CHECK("", patient_C.is_core_atom() );
	patient_C.core().set_dihedral(Psi) ;

    Zhorov_atom * cartesian_origin; 

    if( joined_atom_.is_valid() ) 
    {
        join( aminoacid );
//        cartesian_origin = dynamic_cast<Zhorov_core_atom *>
//            (&joined_atom_().neighbor(0));
// fix
        cartesian_origin = &zhorov_peptide_[1];
        CHECK("", cartesian_origin->is_core_atom() );
        
        CHECK("cartesian_origin is the first Zhorov_core_atom", 
            cartesian_origin != 0 );        
    }
    else 
    {
        core_atoms[0].core().set_rotation_matrix (Geometry_util::identity_matrix );
        core_atoms[0].set_x(0);
        core_atoms[0].set_y(0); 
        core_atoms[0].set_z(0);

        cartesian_origin = &core_atoms[0];
    }

	int num = zhorov_peptide_.size();
	joined_atom_ = zhorov_peptide_[ num - 1 ];

	//model().calc_cartesain_coordinates ();
    model().calc_cartesain_coordinates( *cartesian_origin );
}

void Zhorov_amino_acid_builder::
add_aminoacid( const Text & residue_name )
{
	double defaut_angle = Geometry_util::Pythagorean_Number();
	
	add_aminoacid(  residue_name, defaut_angle, defaut_angle, defaut_angle );
}

void Zhorov_amino_acid_builder::
join ( Array_of< Zhorov_atom > & aminoacid )
{
    REQUIRE("both of joined atoms mush have only one neighbor", 
        joined_atom_().number_of_neighbors() == 1 && 
        aminoacid[0].number_of_neighbors() == 1 );

    Zhorov_atom & left_atom = joined_atom_().neighbor(0);
    CHECK("", left_atom.is_core_atom() );

    Zhorov_atom & right_atom = aminoacid[0].neighbor(0);
    CHECK("", right_atom.is_core_atom() );

	left_atom. change_neighbor( joined_atom_(), right_atom );
	right_atom.change_neighbor( aminoacid[0],   left_atom  );

    //fix make a function
//	int previous_residue_number = joined_atom_().aspect().pdb_atom().residue_number ();
	int previous_residue_number = joined_atom_().pdb().residue_number();
	for (int ii=0; ii<aminoacid.size(); ii++) {
//		aminoacid[ii].aspect().pdb_atom().set_residue_number ( previous_residue_number +1 );
		aminoacid[ii].pdb().set_residue_number ( previous_residue_number +1 );
	}

	// Fix !!! here must be inserted block for change resudue current serial number

    joined_atom_().kill();
    aminoacid[0].kill();
}

Zhorov_amino_acid_builder::Zhorov_amino_acid_builder(Zhorov_model & model )
:  model_ ( model )
{
}

namespace
{
    bool residue_name_is_a_name_of_natural_aminoacid( const Text &
       residue_name )
       {
           try
           {
               aminoacid_name().translate( residue_name );
           }
           catch( Flaw & )
           {
               return false;
           }
           return true;
    }
}
