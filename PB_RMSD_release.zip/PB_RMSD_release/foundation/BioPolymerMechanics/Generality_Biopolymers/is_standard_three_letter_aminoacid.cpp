#pragma warning( disable : 4786 )

#include <fstream>
#include <cassert>
#include <string>
#include <map>


using namespace std;

	bool is_standard_three_letter_aminoacid( const string & residue_name );
	map <string, int>  set_index_by_name() ;



/*
bool is_standard_three_letter_aminoacid_sequence (const string & current_sequence)
{
	bool flag = true;
	for (int ii=0;ii<current_sequence.size();ii++)
	{
		char ch = current_sequence[ii];
		flag = flag & is_standard_one_letter_aminoacid(ch);
	}

	return flag;
	
}
*/

bool is_standard_three_letter_aminoacid( const string & residue_name )
{
	static	map <string, int> map_3_n_ = set_index_by_name();
	int		index = map_3_n_[ residue_name ];
	return ( index > 0 ) ? true : false;
}



map <string, int>  set_index_by_name() 
{

	std::map < string , int >          map_3_n_ ;


    map_3_n_ [  "ALA"   ] =   1 ;
    map_3_n_ [  "ARG"   ] =   2 ;
    map_3_n_ [  "ASN"   ] =   3 ;
    map_3_n_ [  "ASP"   ] =   4 ;
    map_3_n_ [  "VAL"   ] =   5 ;
    map_3_n_ [  "HIS"   ] =   6 ;
    map_3_n_ [  "GLY"   ] =   7 ;
    map_3_n_ [  "GLN"   ] =   8 ;
    map_3_n_ [  "ILE"   ] =   9 ;
    map_3_n_ [  "GLU"   ] =   10 ;
    map_3_n_ [  "LEU"   ] =   11 ;
    map_3_n_ [  "LYS"   ] =   12 ;
    map_3_n_ [  "MET"   ] =   13 ;
    map_3_n_ [  "PRO"   ] =   14 ;
    map_3_n_ [  "SER"   ] =   15 ;
    map_3_n_ [  "TYR"   ] =   16 ;
    map_3_n_ [  "THR"   ] =   17 ;
    map_3_n_ [  "TRP"   ] =   18 ;
    map_3_n_ [  "PHE"   ] =   19 ;
    map_3_n_ [  "CYS"   ] =   20 ;
    map_3_n_ [  "HYP"   ] =   21 ;


	return map_3_n_;

}