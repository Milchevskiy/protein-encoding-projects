#include <string>

using namespace std;

string get_extension_file_name (const string & source_file_nake)
{
	
	int point_position = source_file_nake.find(".");
	string extension_file_name = source_file_nake.substr(point_position+1,source_file_nake.size() ) ;

	return  extension_file_name;
}