// ����� ������ � PDB ����
// ����������:
// 0 ���� ������ �� �������� ATOM � HETATM
// 1 ���� Ok
#include <string.h>
#include <ctype.h>
#include <fstream.h>
#include "..\\..\\include\\Atom.h"
#include "..\\..\\include\\Atom_Const.h"
#include "..\\..\\..\\Common\\include\\CommonFunc.h"

#include <assert.h>


void Atom::putRecPDB		(ostream &output,const int Add_chainID, const long Add_AtSeNu,	const long Add_ReSeNu ){

		PutVa ("ATOM\0",		output,6, 6 ,'l');	//   1 -  6        Record name     "ATOM  "                                            

		if(State & SET_ATOM_ATSENU	)	PutVa (AtSeNu + Add_AtSeNu,	output,5, 5,'r');	//   7 - 11        Integer         serial        Atom serial number.                   
		else 							PutVa ("     ",		output,5, 5,'r');

		PutVa (" \0",			output,1, 1,'l');	//** 12 

// !!!!!  �������� �������� ������ ���� 		_AtNa = 0;

		if(State & SET_ATOM_ATNA) {
 			if ( !isdigit(AtNa [0] ) ) {	
				PutVa (" \0",output,1, 1,'l');	
				PutVa (AtNa,	output,3, 3,'l');		
			}
			else PutVa (AtNa,			output,4, 4,'l');// 13 - 16        Atom            name          Atom name.                            
		}
		else 	PutVa ("    ",			output,4, 4,'r');
				
		PutVa (" \0",			output,1, 1,'l');	//** 17 �������     Character       altLoc        Alternate location indicator.         

		if(State & SET_ATOM_RENA)	PutVa (ReNa,output,3, 3,'l');	//   18 - 20        Residue name    resName       Residue name.                         
		else 						PutVa ("   ",output,3, 3,'l');	//   18 - 20        Residue name    resName       Residue name.                         

		PutVa (" \0",			output,1, 1,'l');   //** 21 �������

		char ChainIDLetter = 'A';
		output <<  ( (char)  (ChainIDLetter + Add_chainID ) );
//		PutVa (" \0",			output,1, 1,'l');   //** 22 �������     Character       chainID       Chain identifier.                     

		if(State & SET_ATOM_RESENU)	PutVa (ReSeNu + Add_ReSeNu ,output,4, 4,'r');	//   23 - 26        Integer         resSeq        Residue sequence number.              
		else 						PutVa ("    ",		output,4, 4,'r');

		PutVa (" \0",			output,1, 1,'l');	//** 27 �������      AChar           iCode         Code for insertion of residues.       
		PutVa ("   \0",			output,3, 3,'l');	//** 28-30 ������� 

		if(State & SET_ATOM_CARTCO) {
			PutVaDouble (CartCo[0],	output,8, 3,'r');	//31 - 38        Real(8.3)       x             Orthogonal coordinates for X in   Angstroms.                           
			PutVaDouble (CartCo[1],	output,8, 3,'r');	//39 - 46        Real(8.3)       y             Orthogonal coordinates for Y in       
			PutVaDouble (CartCo[2],	output,8, 3,'r');	//47 - 54        Real(8.3)       z             Orthogonal coordinates for Z in       
		}
		else {
			PutVa ("        ",	output,8, 3,'r');	//31 - 38        Real(8.3)       x             Orthogonal coordinates for X in   Angstroms.                           
			PutVa ("        ",	output,8, 3,'r');	//39 - 46        Real(8.3)       y             Orthogonal coordinates for Y in       
			PutVa ("        ",	output,8, 3,'r');	//47 - 54        Real(8.3)       z             Orthogonal coordinates for Z in       
		}
		output << endl;

	}
