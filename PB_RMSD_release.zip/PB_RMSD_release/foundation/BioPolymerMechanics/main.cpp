#pragma warning( disable : 4786 )

#include "foundation/Atom_test.h"	
#include "foundation/Model_test.h"	

#include "foundation/Core_iterator_test.h"


#include <vector>
#include <string>

using namespace std;

	const vector <string >  degeneration  ;

void main(int argc,char  **argv) 
{
	if (argc == 1)
	{
		Atom_test	atom_test_	; 
		atom_test_.run();

		Model_test	model_test_	; 
		model_test_.run();

		Core_iterator_test core_iterator_test_;
		core_iterator_test_.run();

	}
	else 
	{
		;;
	}
}
