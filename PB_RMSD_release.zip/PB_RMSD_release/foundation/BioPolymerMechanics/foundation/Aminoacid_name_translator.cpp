#pragma warning( disable : 4786 )

#include "Aminoacid_name_translator.h"

//#include "..//..//Generality_Biopolymers//Generality_Biopolymers.h"

#include <cassert>
#include <iostream>

bool is_standard_three_letter_aminoacid( const string & residue_name );


string Aminoacid_name_translator::translate( const string & name )
{

    map < string, string> map;
    string key;
    for( int i=0;  i<name.size();  ++i )
        key += (char) toupper( name[i] );

    switch ( name.size() )
    {
        case 1 :
            map = map_1_3_;
            break;
        case 3 :
		//	assert ( ! is_standard_three_letter_aminoacid( name )  );
			return key;
        default :
             cout << "Wrong aminoacid name." << endl;
			 assert (1);
    }

    string result = map [ key ];
    return result;
}

Aminoacid_name_translator  aminoacid_name()
{
    static Aminoacid_name_translator singleton;
    return singleton;
}
/*
Aminoacid_name_translator::Aminoacid_name_translator()
{
    map_1_3_ [ "A"] =   "ALA";
    map_1_3_ [ "R"] =   "ARG";
    map_1_3_ [ "N"] =   "ASN";
    map_1_3_ [ "D"] =   "ASP";
    map_1_3_ [ "V"] =   "VAL";
    map_1_3_ [ "H"] =   "HIS";
    map_1_3_ [ "G"] =   "GLY";
    map_1_3_ [ "Q"] =   "GLN";
    map_1_3_ [ "E"] =   "ILE"; !!!!!!!!!!!!!!!!!!!! ERROR
    map_1_3_ [ "I"] =   "GLU";
    map_1_3_ [ "L"] =   "LEU";
    map_1_3_ [ "K"] =   "LYS";
    map_1_3_ [ "M"] =   "MET";
    map_1_3_ [ "P"] =   "PRO";
    map_1_3_ [ "S"] =   "SER";
    map_1_3_ [ "Y"] =   "TYR";
    map_1_3_ [ "T"] =   "THR";
    map_1_3_ [ "W"] =   "TRP";
    map_1_3_ [ "F"] =   "PHE";
    map_1_3_ [ "C"] =   "CYS";
    map_1_3_ [ "O"] =   "HYP";
}
*/
