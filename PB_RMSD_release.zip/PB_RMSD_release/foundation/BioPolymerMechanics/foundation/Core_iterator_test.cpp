#pragma warning( disable : 4786 )

#include "Core_iterator_test.h"
#include "Core_iterator.h"
#include "Model.h"
#include "Config.h"
#include "Atom.h"

#include "../../CommonFunc.h"

#include <fstream> 
#include <iostream>

using namespace std;

Core_iterator_test::~Core_iterator_test()
{
	cout << "Core_iterator_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Core_iterator_test::
first_validity_test()
{
	
	Model model;  
	vector <double> dihedral_set ;  // here we'l try alpha helix (-57;-47;180)

	double Pi = Pythagorean_Number ();
	
	model.join_aminoacid("Gly",1);	dihedral_set.push_back(-0.994); dihedral_set.push_back(-0.820) ; dihedral_set.push_back(Pi ) ;      
	model.join_aminoacid("Gly",0);	dihedral_set.push_back(-0.994) ;   dihedral_set.push_back(-0.820) ; dihedral_set.push_back(Pi ) ;      
	model.join_aminoacid("Gly",0);	dihedral_set.push_back(-0.994) ;   dihedral_set.push_back(-0.820) ; dihedral_set.push_back(Pi ) ;      
	model.join_aminoacid("Gly",0);	dihedral_set.push_back(-0.994) ;   dihedral_set.push_back(-0.820) ; dihedral_set.push_back(Pi ) ;      
	model.join_aminoacid("Gly",0);	dihedral_set.push_back(-0.994) ;   dihedral_set.push_back(-0.820) ; dihedral_set.push_back(Pi ) ;      
	model.join_aminoacid("Gly",0);	dihedral_set.push_back(-0.994) ;   dihedral_set.push_back(-0.820) ; dihedral_set.push_back(Pi ) ;      
	model.join_aminoacid("Gly",0);	dihedral_set.push_back(-0.994) ;   dihedral_set.push_back(-0.820) ; dihedral_set.push_back(Pi ) ;      

	std::vector < Atom * > core_atoms = model.get_core_atoms();
	Atom * initial_atom = core_atoms.front();

	Core_iterator        it( initial_atom );

	string core_iterator_test_locaction = string (DIR_tests )  + string ("core_iterator_test") ;

	ofstream out( core_iterator_test_locaction.c_str() );


// it's supposed direct order of dihedlar angles stored in array (phi,pshi,omega)
	int counter = 0;
	while ( it.has_next() )
	{
		it.next();
		Atom * current_atom = it.current();

			double temp = dihedral_set [counter ];
		current_atom->set_dihedral( dihedral_set [counter ]);		
		counter ++;

		PutVa (current_atom->get_pdb_atom_number()	,out,5, 4,'l') ;
		PutVa (current_atom->get_element_name()		,out,5, 4,'l') ;
		PutVa (current_atom->get_pdb_atom_name()	,out,5, 4,'l') ;
		PutVa (current_atom->get_zhorov_atom_name()	,out,5, 4,'l') ;
		PutVa (current_atom->get_residue_index	()	,out,5, 4,'l') ;
		PutVa (current_atom->get_residue_name	()	,out,5, 4,'l') ;

		out << endl;

	}

// check
	initial_atom = core_atoms.front();

	vector < double > matrix; matrix.resize(9);
	matrix[0]=1;
	matrix[4]=1;
	matrix[8]=1;
	initial_atom->set_rotation_matrix(matrix);
	initial_atom->set_x(0);
	initial_atom->set_y(0);
	initial_atom->set_z(0);

	model.calc_cartesain_coordinates ( initial_atom );


	string Calc_cartesain_coordinates_test_locaction = string (DIR_tests )  + string ("testing_alpha_helix_assembling") + string(".pdb");

	model.save_as(Calc_cartesain_coordinates_test_locaction);


	model.init_phi_psi_owega_backbone_set();

	vector < double > phi_set = model.get_phi_set();
	vector < double > psi_set = model.get_psi_set();
	vector < double > ome_set = model.get_ome_set();


	for (unsigned ii=0; ii<phi_set.size(); ii++ )
	{
		PutVaDouble (phi_set[ii]	,cout,8, 4,'l') ;
		PutVaDouble (psi_set[ii]	,cout,8, 4,'l') ;
		PutVaDouble (ome_set[ii]	,cout,8, 4,'l') ;
		cout << endl;
	}
}