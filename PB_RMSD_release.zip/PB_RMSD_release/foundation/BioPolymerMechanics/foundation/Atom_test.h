#ifndef ATOM_TEST
#define ATOM_TEST

#include "../../Simple_test.h"

class  Atom_test: public Simple_test
{
public:
	~Atom_test();
    
    void run()
    {
		constructor_test ();
	}
	void constructor_test ();
};

#endif