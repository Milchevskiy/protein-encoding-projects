#ifndef MODEL_TEST
#define MODEL_TEST

#include "../../Simple_test.h"

class  Model_test: public Simple_test
{
public:
	~Model_test();
    
    void run()
    {
	//	load_test ();
	//	Aminoacid_name_translator_test();
		new_amino_acid_test ();
		join_amino_acid_test ();
		Calc_cartesain_coordinates_test();
	}
	void load_test ();
	void Aminoacid_name_translator_test();
	void new_amino_acid_test ();
	void join_amino_acid_test ();
	void Calc_cartesain_coordinates_test();
};

#endif