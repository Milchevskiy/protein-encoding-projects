#include "Core_attributes.h"

using namespace std;

Core_attributes::Core_attributes  () :
	vector_model_   (0),
	rotation_matrix_(0),
	dihedral_       (0)
{
}


//Core_attributes::Core_attributes  () {}

Core_attributes::~Core_attributes  ()
{
	if( vector_model_ )		delete [] vector_model_;
	if( rotation_matrix_ )	delete [] rotation_matrix_;
}
void Core_attributes::	set_vector_model	( const std::vector < double > & vector_model )
{
	int vector_model_size = vector_model.size() ;
	if ( ! vector_model_ )
		vector_model_ = new double [vector_model_size ];

	for (int ii=0;ii<vector_model_size;ii++)
		vector_model_[ii] = vector_model[ii];
}

void Core_attributes::	set_vector_model	( const double * vector_model )
{
//fix	check_ vector_model_size
	int vector_model_size = sizeof (vector_model) / sizeof(double) ;
	if ( ! vector_model_ )
		vector_model_ = new double [vector_model_size ];

	for (int ii=0;ii<vector_model_size;ii++)
		vector_model_[ii] = vector_model[ii];
}

void Core_attributes::	set_rotation_matrix ( const std::vector < double > & rotation_matrix)
{
	if ( !rotation_matrix_ )
		rotation_matrix_ = new double [9];

	for (int ii=0;ii<9;ii++)
		rotation_matrix_[ii] = rotation_matrix[ii];
}


void Core_attributes::	set_rotation_matrix ( const double * rotation_matrix)
{
	if ( !rotation_matrix_ )
		rotation_matrix_ = new double [9];

	for (int ii=0;ii<9;ii++)
		rotation_matrix_[ii] = rotation_matrix[ii];

}

void Core_attributes::	set_dihedral		( const double dihedral)
{
	dihedral_ = dihedral;
}

void Core_attributes::get_ray(const int i, double * ray) const
{
//fix :double check_unit_vecor = vector_model_ [3*i]*vector_model_ [3*i] + vector_model_ [3*i+1]*vector_model_ [3*i+1] + vector_model_ [3*i+2]*vector_model_ [3*i+2] - 1;

    ray[0]= vector_model_ [3*i] ;
    ray[1]= vector_model_ [3*i+1] ;
    ray[2]= vector_model_ [3*i+2] ;
}
