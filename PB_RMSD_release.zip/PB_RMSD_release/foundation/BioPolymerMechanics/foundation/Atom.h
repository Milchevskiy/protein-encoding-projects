//#pragma warning( disable : 4786 )

#ifndef ATOM_H
#define ATOM_H

//#include "Core_attributes.h"

#include <vector>
#include <string>

class Core_attributes;
class Atom;

class Atom
{
public:
//	Atom (std::string element_name);
	Atom ();

	Atom       (int   zhorov_atom_index,
                const std::string & element_name,
                const std::string & pdb_atom_name,
                const std::string & zhorov_atom_name,
                int        residue_index,
                const std::string & residue_name,
                double     bond_length,
                double     charge );

	~Atom () ;

	int					get_zhorov_atom_index	() const { return zhorov_atom_index_; }
	int					get_pdb_atom_number		() const { return pdb_atom_number_; }
	std::string			get_element_name		() const { return element_name_; }
	std::string			get_pdb_atom_name		() const { return pdb_atom_name_; }
	std::string			get_zhorov_atom_name	() const { return zhorov_atom_name_; }
	int					get_residue_index		() const { return residue_index_; }
	std::string			get_residue_name		() const { return residue_name_; }
	double				get_bond_length			() const { return bond_length_; }
	double				get_charge				() const { return charge_; }


	void set_zhorov_atom_index	( const int zhorov_atom_index )			{ zhorov_atom_index_ = zhorov_atom_index; } ;
	void set_pdb_atom_number	( const int pdb_atom_number)			{ pdb_atom_number_ = pdb_atom_number; } ;
	void set_element_name       ( const std::string & element_name )	{ element_name_ = element_name; }
	void set_name				( const std::string & pdb_atom_name )	{ pdb_atom_name_ = pdb_atom_name; } ;
	void set_zhorov_atom_name   ( const std::string & zhorov_atom_name) { zhorov_atom_name_ = zhorov_atom_name;}
	void set_residue_number		( const int residue_index )				{ residue_index_ = residue_index ; }
	void set_residue_name		( const std::string &residue_name)		{ residue_name_ = residue_name; }
	void set_length             ( const double bond_length )			{ bond_length_ = bond_length ;}
	void set_charge				( const double charge )					{ charge_ = charge ; }

	std::vector < Atom * >	get_neighbors		() const { return neighbors_;}
	Atom * 					get_neighbors		(const int index ) const ;
	Core_attributes *		get_Core_attributes	() const { return core_attributes_ ;}

    int                     number_of_neighbors () const   { return neighbors_.size(); }

    void    add_neighbor   ( Atom * atom );
    void	remove_neighbor( const int index );
    void	change_neighbor( Atom * old_neighbor, Atom *  new_neighbor );


	void	set_vector_model	( const std::vector < double > & vector_model );
	void	set_rotation_matrix	( const std::vector < double > & rotation_matrix);
	void	set_dihedral		( const double dihedral);
	void	get_ray				( const int i, double * ray) const;
	double	dihedral			() const ;

	int ray_serial_number		() const ;


	bool  is_core_atom () const;
	void  init_core_attributes ();


	void set_x (const double x) {x_= x;}
	void set_y (const double y) {y_= y;}
	void set_z (const double z) {z_= z;}

	double x() const {return x_;}
	double y() const {return y_;}
	double z() const {return z_;}

private:

	int         zhorov_atom_index_;
	int         pdb_atom_number_;
	std::string element_name_;
	std::string pdb_atom_name_;
	std::string zhorov_atom_name_;
	int         residue_index_;
	std::string residue_name_;
	double      bond_length_;
	double      charge_;

	int			atom_index_;

	std::vector < Atom * > neighbors_;

	Core_attributes * core_attributes_;

	double x_;
	double y_;
	double z_;


};

#endif

