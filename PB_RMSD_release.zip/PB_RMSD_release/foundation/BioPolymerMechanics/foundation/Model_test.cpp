#pragma warning( disable : 4786 )
#pragma warning( disable : 4503)

#include "Model.h"
#include "Atom.h"
#include "Config.h"
#include "Aminoacid_name_translator.h"

#include "Model_test.h"

#include "../../CommonFunc.h"

#include <iostream>
#include <fstream>
#include <cassert>
#include <string>

using namespace std;

Model_test::~Model_test()
{
	cout << "Model_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Model_test::load_test ()
{
	Model model_by_pdb;

	string source_pdb_location = string (DIR_tests )  + string ("pdb1mi5.ent") ;
	string result_seq_location = string (DIR_tests )  + string ("pdb1mi5.seq_") ;
	
	model_by_pdb.load(source_pdb_location);

	vector < vector < string > >  sequence = model_by_pdb.get_sequence();

	ofstream seq_stream ( result_seq_location.c_str() );
	if ( ! seq_stream ) 	{		cout << "can't reatte file " << "pdb1mi5.seq_" << endl;		assert (  seq_stream );	}
	
	for (int ii=0;ii<sequence.size();ii++) 
	{
		for (int jj=0;jj<sequence[ii].size();jj++) 
			seq_stream  << sequence[ii][jj] << " ";
		seq_stream  << endl;
	}
}


void Model_test:: Aminoacid_name_translator_test() 
{
	vector < string > residue_names;

	vector < string > translated_residue_names;
	
	residue_names.push_back("Ala");
	residue_names.push_back("Pro");
	residue_names.push_back("L");

	Aminoacid_name_translator name_translator = aminoacid_name();

	for (int ii=0;ii<residue_names.size();ii++)
	{
		string current_name = name_translator.translate(  residue_names[ii] );
		translated_residue_names.push_back (current_name) ;
	}


//	test( "tranlated name for Ala must be ALA", translated_residue_names[0] == "ALA");
//	test( "tranlated name for Pro must be PRO",	translated_residue_names[1] == "PRO");
//	test( "tranlated name for L must be LEU",	translated_residue_names[2] == "LEU");

}

void Model_test::new_amino_acid_test () 
{
		Model model;

		vector < Atom * >  all_atoms;
		vector < Atom * >  core_atoms;

		model.new_aminoacid( "Ile",	all_atoms,core_atoms );

		string new_acid_test_locaction = string (DIR_tests )  + string ("new_acid_test") ;

		ofstream output  ( new_acid_test_locaction.c_str() );
		if ( ! output  ) 	{
			cout << "can't create file " << "new_acid_test" << endl;
			assert (  output  );
		}
		output << "CORE ATOMS" << endl;
		PutVa (core_atoms.size(),output,5, 4,'l') ;
		output << endl;

		for (int ii=0;ii<core_atoms.size(); ii++)
		{
			PutVa (core_atoms[ii]->get_zhorov_atom_index(),output,5, 4,'l') ;
			PutVa (core_atoms[ii]->get_element_name(),output,5, 4,'l') ;
			PutVa (core_atoms[ii]->get_pdb_atom_name(),output,5, 4,'l') ;
			PutVa (core_atoms[ii]->get_zhorov_atom_name(),output,5, 4,'l') ;
			PutVa (core_atoms[ii]->get_residue_index(),output,5, 4,'l') ;
			PutVa (core_atoms[ii]->get_residue_name(),output,5, 4,'l') ;

			int number_of_neighbors = core_atoms[ii]->number_of_neighbors();
			for (int kk=0;kk<number_of_neighbors;kk++)
			{
				Atom * current_atom = core_atoms[ii]->get_neighbors(kk);
				PutVa (current_atom->get_zhorov_atom_index(),output,5, 4,'l') ;
			}
			for (int jj=0;jj<4-number_of_neighbors;jj++)
				PutVa (0,output,5, 4,'l') ;

			PutVa (core_atoms[ii]->get_bond_length(),output,6, 3,'l') ;
			PutVa (core_atoms[ii]->get_charge(),output,6, 4,'r') ;

			output << endl;
		}
		output << "VECTOR MODELS "<< core_atoms.size() << endl;

		for (int ii=0;ii<core_atoms.size(); ii++)
		{
			PutVa (core_atoms[ii]->get_pdb_atom_name(),output,5, 4,'l') ;

			int number_of_neighbors = core_atoms[ii]->number_of_neighbors();
			for (int kk=1;kk<number_of_neighbors;kk++)
			{
				double ray[3];
				core_atoms[ii]->get_ray(kk,ray);
				PutVa (ray[0],output,15, 10,'l') ;
				PutVa (ray[1],output,15, 10,'l') ;
				PutVa (ray[2],output,15, 10,'l') ;
			}
			output << endl;
		}

		output << "DIHEDRAL ANGLES "<< core_atoms.size() << endl;
		for ( int ii=0;ii<core_atoms.size(); ii++)
		{
			PutVa (core_atoms[ii]->get_pdb_atom_name(),output,5, 4,'l') ;
			PutVa (core_atoms[ii]->dihedral(),output,5, 4,'l') ;
			output << endl;
		}
}

void Model_test::join_amino_acid_test ()
{

	Model model;

	model.join_aminoacid("Ala",1);
	model.join_aminoacid("Ile",0);
	model.join_aminoacid("Arg",0);

	string join_amino_acid_test_locaction = string (DIR_tests )  + string ("join_amino_acid_test") ;


	model.save_own (join_amino_acid_test_locaction);

}

void Model_test::Calc_cartesain_coordinates_test()
{	

	Model model;
	model.join_aminoacid("Ala",1);
	model.join_aminoacid("Ile",0);
	model.join_aminoacid("Arg",0);

	string Calc_cartesain_coordinates_test_locaction = string (DIR_tests )  + string ("Calc_cartesain_coordinates_test") + string(".pdb");

	vector < Atom * > core_atoms = model.get_core_atoms  ();

	Atom * initial_atom = core_atoms.front();

	vector < double > matrix; matrix.resize(9);
	matrix[0]=1;
	matrix[4]=1;
	matrix[8]=1;
	initial_atom->set_rotation_matrix(matrix);
	initial_atom->set_x(0);
	initial_atom->set_y(0);
	initial_atom->set_z(0);

	model.calc_cartesain_coordinates ( initial_atom );

	model.save_as(Calc_cartesain_coordinates_test_locaction);
}