#pragma warning( disable : 4786 )

#include "Model.h"
#include "Atom.h"
#include "Config.h"
#include "Core_attributes.h"
#include "Core_iterator.h"

#include <cassert>

#include "Aminoacid_name_translator.h"

//#include <map>
#include <fstream>
//#include <iostream>
#include <cassert>
#include <cstdio>

#include "../../CommonFunc.h"
#include "Geometry_util/Geometry_util.h"

#include "../../Censorship.h"

extern ofstream log_stream;
extern Censorship configuration;


void  Model::load ( const string & source_file_name )
{
	ifstream source_stream ( source_file_name.c_str() );
	if ( ! source_stream ) 	{
		cout << "can't open file " << source_file_name << endl;
		assert (  source_stream );
	}
	std::map < std::string,  Coordinate > name_by_cartesian;
	std::map < std::string,  int> name_by_index;

	string extension = get_extension_file_name (source_file_name);

	if ( extension == "pdb" || extension == "PDB" ||
		 extension == "ent" || extension == "ENT" ||
		 extension == "brk" || extension == "BRK" )
	{
		string current_line;
		int current_count = 1;
		vector < string > current_sequence;
		int residue_index_reference_point = 0;
		while( getline( source_stream , current_line, '\n' ) )
		{
			string pdb_atom_name;
			int    residue_index;
			string residue_name;
			int	   pdb_atom_index;

			string atom_line_indicator = current_line.substr(0,3);

			if ( atom_line_indicator == string("TER") )
			{
				sequence_.push_back (current_sequence);
				current_sequence.clear();
				continue;
			}
			else if  ( atom_line_indicator == string("ATO") || atom_line_indicator == string("HET") )
			{

//ATOM    933  CG2 THR B  59       5.806  14.945 -11.007  1.00 32.16           C
// 123456789 123456789 123456789 123456789 123456789 123456789 123456789 123456789
				read_value_from_position_in_fixed_format_string (pdb_atom_index, current_line, 6 , 6);
				read_value_from_position_in_fixed_format_string (pdb_atom_name,  current_line, 12, 5);
				read_value_from_position_in_fixed_format_string (residue_name,   current_line, 16, 4);
				read_value_from_position_in_fixed_format_string (residue_index,  current_line, 22, 6);

// adding current residue name to sequence in case of the first atom in residues only
				if ( residue_index_reference_point != residue_index )
				{
					current_sequence.push_back (residue_name);
					residue_index_reference_point = residue_index ;
				}

				double x,y,z;
				read_value_from_position_in_fixed_format_string (x,  current_line, 30, 8);
				read_value_from_position_in_fixed_format_string (y,  current_line, 38, 8);
				read_value_from_position_in_fixed_format_string (z,  current_line, 46, 8);
				Coordinate current_cartesian_coord (x,y,z);

				ostringstream ost;
				ost << pdb_atom_name <<  "_" <<  residue_name << "_"  << residue_index;
				string exhaustive_name = ost.str() ;
				name_by_cartesian [ exhaustive_name  ] = current_cartesian_coord;

				name_by_index[ exhaustive_name  ] = current_count;

				current_count++;
			}

		}
// if last atom does follow by TER word
		if ( current_sequence.size () )
			sequence_.push_back (current_sequence);

	}
	else if ( extension == "mol" || extension == "MOL" )
	{
	}
	else
	{
		cout << extension << "?!! -  strange extension for molecular source " << endl;
		assert (  source_stream );
	}
}


void  Model::new_aminoacid(
	const string & residue_name,
	vector < Atom * > & all_atoms,
	vector < Atom * > & core_atoms)
{
	Aminoacid_name_translator name_translator = aminoacid_name();
	const string name = name_translator.translate(  residue_name );

///	const string path_to_shablon_residue = configuration.option_meaning("Path_to_20Aminoacids_template") + residue_name + string(".own");

    const string path_to_shablon_residue = "20Aminoacids/"  + residue_name + string(".own");


    ifstream in	( path_to_shablon_residue.c_str() );
    if ( ! in )
	{
		cout << "Can't find file " << path_to_shablon_residue << endl;		getchar ();
	}

    int ii;
    std::string buff;
    getline( in, buff );
    int number_of_atoms = atoi( buff.c_str() );

    vector < int > neighbours_1;
    vector < int > neighbours_2;
    vector < int > neighbours_3;
    vector < int > neighbours_4;

    //  atoms reading
    for ( ii = 0; ii < number_of_atoms ; ii++ )
    {
        int zhorov_atom_index;
        std::string element_name;
        std::string pdb_atom_name;
        std::string zhorov_atom_name;
        int residue_index;
        std::string residue_name;
        int neighbour1, neighbour2, neighbour3, neighbour4;
        double bond_length;
        double charge;

        in  >> zhorov_atom_index >> element_name >> pdb_atom_name
        >> zhorov_atom_name  >> residue_index >> residue_name
        >> neighbour1 >> neighbour2 >> neighbour3 >> neighbour4
        >> bond_length >> charge;

        neighbours_1.push_back( neighbour1 );
        neighbours_2.push_back( neighbour2 );
        neighbours_3.push_back( neighbour3 );
        neighbours_4.push_back( neighbour4 );

		Atom *atom = new Atom;

		atom->set_zhorov_atom_index	( zhorov_atom_index );
		atom->set_pdb_atom_number	( zhorov_atom_index );
		atom->set_element_name		( element_name.c_str() );
        atom->set_name				( pdb_atom_name.c_str() );
        atom->set_zhorov_atom_name  ( zhorov_atom_name.c_str() );
        atom->set_residue_number	( residue_index );
        atom->set_residue_name		( residue_name.c_str() );
        atom->set_length            ( bond_length );
        atom->set_charge			( charge );

		all_atoms.push_back(  atom );

		if ( neighbour2 != 0  )
            core_atoms.push_back         (  atom );
	}

    for ( ii = 0; ii < number_of_atoms ; ii++ )
    {

        if ( neighbours_1[ ii ] != 0 )
        {
            int n = neighbours_1[ ii ] - 1;
            Atom * current_atom = all_atoms [ n ];
            all_atoms[ ii ]->add_neighbor( current_atom );
        }
        if ( neighbours_2[ ii ] != 0 )
        {
            int n = neighbours_2[ ii ] - 1;
            Atom * current_atom = all_atoms [ n ];
            all_atoms[ ii ]->add_neighbor( current_atom );
        }

        if ( neighbours_3[ ii ] != 0 )
        {
            int n = neighbours_3[ ii ] - 1;
            Atom * current_atom = all_atoms [ n ];
            all_atoms[ ii ]->add_neighbor( current_atom );
        }

        if ( neighbours_4[ ii ] != 0 )
        {
            int n = neighbours_4[ ii ] - 1;
            Atom * current_atom = all_atoms [ n ];
            all_atoms[ ii ]->add_neighbor( current_atom );
        }
    }

    string dummy;
    int number_of_zhozov_atoms;
    in  >> dummy >> dummy >> number_of_zhozov_atoms;

	assert (number_of_zhozov_atoms == core_atoms.size() );

    vector < double > vector_model ;
	for ( unsigned int  ii=0; ii< core_atoms.size(); ii++ )
    {
        in  >> dummy ;	in  >> dummy ;

        vector_model.clear();;
        vector_model.push_back ( -1 );
        vector_model.push_back ( 0 );
        vector_model.push_back ( 0 );

		for ( int jj = 0;    jj < 3 * core_atoms[ii]->number_of_neighbors()- 3; jj++ )
		{
		   double value;
		   in  >> value;
		   vector_model.push_back ( value );
		}
		core_atoms[ii]->init_core_attributes();
		core_atoms[ii]->set_vector_model (vector_model);
    }

	in  >> dummy;    in  >> dummy;
    in  >> number_of_zhozov_atoms;

    for (  unsigned int ii=0; ii< core_atoms.size(); ii++ )
    {
        double dihedral;
        in >> dummy ;        in >> dummy;
        in >> dihedral ;
        in >> dummy ;        in >> dummy ;        in >> dummy ;        in >> dummy ;
        core_atoms[ii]->set_dihedral ( dihedral );
    }
}

void  Model::join_aminoacid(
	const string & residue_name, bool first_residue_status )
{

		vector < Atom * >  peptide_all_atoms;
		vector < Atom * >  peptide_core_atoms;

		new_aminoacid( residue_name,
			peptide_all_atoms,
			peptide_core_atoms );

		if ( all_atoms_.size() !=0 )
		{
			int residue_index_current	=	all_atoms_.back()->get_residue_index	();
			int pdb_atom_number_current =	all_atoms_.back()->get_pdb_atom_number	();

			int peptide_all_atoms_size = peptide_all_atoms.size();
			for (int kk=0;kk<peptide_all_atoms_size;kk++)
			{
				peptide_all_atoms[kk]->set_pdb_atom_number (++pdb_atom_number_current);
				peptide_all_atoms[kk]->set_residue_number	 (residue_index_current +1 );

			}

		}



		if ( first_residue_status || all_atoms_.size() == 0 )
			strand_origin_.push_back (peptide_core_atoms[0]);
		else
		{



			Atom * c_end_extra_atom = all_atoms_.back();
			Atom * n_end_extra_atom = peptide_all_atoms.front();

			Atom * left_atom	= c_end_extra_atom->get_neighbors(0);
			Atom * right_atom	= n_end_extra_atom->get_neighbors(0);

			left_atom->change_neighbor (c_end_extra_atom,right_atom );
			right_atom->change_neighbor (n_end_extra_atom,left_atom );

//fix erase

			c_end_extra_atom->~Atom();
			n_end_extra_atom->~Atom();

			all_atoms_.erase		(  all_atoms_.end()-1);
			peptide_all_atoms.erase	(  peptide_all_atoms.begin() );

		}

	//	int size = all_atoms_.size();

		all_atoms_.insert ( all_atoms_.end()	,peptide_all_atoms.begin(),		peptide_all_atoms.end() );
		core_atoms_.insert( core_atoms_.end()	,peptide_core_atoms.begin(),	peptide_core_atoms.end());

	//	size = all_atoms_.size();


		//sequence_.push_back(residue_name);

}
void  Model::
save_own (const std::string &filename)
{
	ofstream out( filename.c_str() );
	int number_of_atoms = all_atoms_.size();
	out << number_of_atoms << endl;

	 for( unsigned int i=0;  i<all_atoms_.size();  i++ )
	 {

		PutVa (all_atoms_[i]->get_pdb_atom_number()	,out,5, 4,'l') ;
		PutVa (all_atoms_[i]->get_element_name()	,out,5, 4,'l') ;
		PutVa (all_atoms_[i]->get_pdb_atom_name()	,out,5, 4,'l') ;
		PutVa (all_atoms_[i]->get_zhorov_atom_name(),out,5, 4,'l') ;
		PutVa (all_atoms_[i]->get_residue_index	()	,out,5, 4,'l') ;
		PutVa (all_atoms_[i]->get_residue_name	()	,out,5, 4,'l') ;

		PutVa (all_atoms_[i]->get_neighbors(0)->get_pdb_atom_number(),out,5, 4,'l') ;

		for (int kk=1;kk<4;kk++)
		{
			if (all_atoms_[i]->number_of_neighbors() > kk )
				PutVa (all_atoms_[i]->get_neighbors(kk)->get_pdb_atom_number() ,out,5, 4,'l') ;
			else
				PutVa ("0 ",out,5, 4,'l') ;
		}
		out <<  endl;
	}

	out << "VECTOR MODELS "<< core_atoms_.size() << endl;

	for ( unsigned int  ii=0;ii<core_atoms_.size(); ii++)
	{
		PutVa (core_atoms_[ii]->get_pdb_atom_name(),out,5, 4,'l') ;

		int number_of_neighbors = core_atoms_[ii]->number_of_neighbors();
		for (int kk=1;kk<number_of_neighbors;kk++)
		{
			double ray[3];
			core_atoms_[ii]->get_ray(kk,ray);
			PutVa (ray[0],out,15, 10,'l') ;
			PutVa (ray[1],out,15, 10,'l') ;
			PutVa (ray[2],out,15, 10,'l') ;
		}
		out << endl;
	}
	out << "DIHEDRAL ANGLES "<< core_atoms_.size() << endl;
	for ( unsigned int ii=0;ii<core_atoms_.size(); ii++)
	{
		PutVa (core_atoms_[ii]->get_pdb_atom_name(),out,5, 4,'l') ;
		PutVa (core_atoms_[ii]->dihedral(),out,5, 4,'l') ;
		out << endl;
	}

}

void  Model::
calc_cartesain_coordinates( Atom * initial_atom )
{
 //   REQUIRE("initial_atom.is_core_atom()", initial_atom.is_core_atom() );
    using namespace Geometry_util;

    double transform_matrix[ 9 ],	current_transform_matrix[ 9 ];

    double x = initial_atom->x();
    double y = initial_atom->y();
    double z = initial_atom->z();
    memcpy ( transform_matrix, initial_atom->get_Core_attributes()->rotation_matrix(),
    9 * sizeof ( double ) );

 //   CHECK( "True transform matrix for 1-st atom",
 //       fabs ( 1 - determinant_3x3( transform_matrix ) ) < epsilon_float() ) ;

    // setting cartesion coordinates for neighbors of the FIRST atom
    int number_of_neighbors_first = initial_atom->number_of_neighbors();
    for ( int  kk = 0 ; kk < number_of_neighbors_first; kk++ )
    {
        double ray[ 3 ],				oriented_ray[ 3 ];

        initial_atom->get_ray( kk, ray );
        multiplication_row_by_3x3
        ( ray, transform_matrix, oriented_ray );

        Atom * neighbor_atom = initial_atom->get_neighbors( kk );
        double length = neighbor_atom->get_bond_length();

        neighbor_atom->set_x ( x + oriented_ray[ 0 ] * length );
        neighbor_atom->set_y ( y + oriented_ray[ 1 ] * length );
        neighbor_atom->set_z ( z + oriented_ray[ 2 ] * length );
    }

    Core_iterator	it( initial_atom );
    while ( it.has_next() )
    {
        it.next();
        Atom * current_atom = it.current();
 //       CHECK( "current_atom.is_core_atom()",
  //          current_atom.is_core_atom());            //fix error !!!!!!!!!!

 //       CHECK( "Incoming atom should not terminal atom",
 //          current_atom.neighbor( 0 ).is_core_atom() );

        Atom * incoming_atom = current_atom->get_neighbors( 0 );
   //     CHECK( "incoming_atom.is_core_atom()",
    //        incoming_atom.is_core_atom() );

        double ray[ 3 ];
 //       int ray_serial_number = current_atom.ray_serial_number() ;
  //      incoming_atom.core().get_ray( ray_serial_number, ray );

		int ray_serial_number = current_atom->ray_serial_number() ;
        incoming_atom->get_ray( ray_serial_number, ray );

        double first_around_axis_X	=	- current_atom->dihedral();
        double around_axis_Z		=	- acos ( ray[ 0 ] );
        double second_around_axis_X;

        if( ray_serial_number == 1 )
        {
            make_rotation_matrix_X_Z( first_around_axis_X,
            around_axis_Z ,
            current_transform_matrix );
        }
        else
        {
			double zerro = 0.0;
            normalize_vector ( zerro , ray[ 1 ], ray[ 2 ] );
//			CHECK ( "",fabs(zerro) < epsilon_float() );
//			CHECK ( "",fabs( ray[1]*ray[1] + ray[2]*ray[2] -1 ) < epsilon_float() );


            second_around_axis_X =
            solve_sin_cos_indeterminacy( -ray[ 2 ], ray[ 1 ] ) ;

            make_rotation_matrix_X_Z_X(	first_around_axis_X,
            around_axis_Z ,
            second_around_axis_X,
            current_transform_matrix );
        }

        multiplication_matrixes_3x3_by_3x3( current_transform_matrix,
        incoming_atom->get_Core_attributes()->rotation_matrix(),
        transform_matrix );


        current_atom->get_Core_attributes()->set_rotation_matrix ( transform_matrix ) ;

        double current_x = current_atom->x();
        double current_y = current_atom->y();
        double current_z = current_atom->z();

         int number_of_neighbors = current_atom->number_of_neighbors(); // why
        // without () ???
        for ( int  kk = 1 ; kk < number_of_neighbors; kk++ )
        {
            double ray[ 3 ],				oriented_ray[ 3 ];
            current_atom->get_ray( kk, ray );
            multiplication_row_by_3x3
               (	ray, transform_matrix, oriented_ray );

            Atom * neighbor_atom = current_atom->get_neighbors( kk );
            double length = neighbor_atom->get_bond_length();

            neighbor_atom->set_x ( current_x + oriented_ray[ 0 ] * length );
            neighbor_atom->set_y ( current_y + oriented_ray[ 1 ] * length );
            neighbor_atom->set_z ( current_z + oriented_ray[ 2 ] * length );
        }
    }
}

void  Model::
save_as	( const std::string & file_name )
{

	string extension = get_extension_file_name (file_name);

	if ( extension == "pdb" || extension == "PDB" ||
		 extension == "ent" || extension == "ENT" ||
		 extension == "brk" || extension == "BRK" )
	{

		ofstream output( file_name.c_str() );
		if ( ! output )
		{
			cout << "can't create file " << file_name << endl;
			assert (  output );
		}




		for (unsigned int  ii=0;ii<all_atoms_.size(); ii++)
		{
			output << "ATOM  ";

			PutVa (all_atoms_[ii]->get_pdb_atom_number(),						output,5, 5 ,'5');	   			//   7 - 11        Atom serial number.
//			output << " ";						//** 12  space




			string 	AtNa = all_atoms_[ii]->get_pdb_atom_name();
			int len_Atna=AtNa.size();

			switch (len_Atna)
			{
				case (4) :
					output << AtNa << " ";
					break;
				case (3) :
					output << " " << AtNa << " ";
					break;
				case (2) :
					output << "  " << AtNa << " ";
					break;
				case (1) :
					output << "  " << AtNa << "  ";
					break;

			}
/*
 			if ( !isdigit(AtNa [0] ) ) {
				PutVa (" ",output,1, 1,'l');
				PutVa (AtNa,	output,3, 3,'r');
			}
			else PutVa (AtNa,output,4, 4,'r');	// 13 - 16        Atom name.
*/
			output <<  " ";						//** 17 �������     Character       altLoc        Alternate location indicator.
			PutVa (all_atoms_[ii]->get_residue_name(),
				output,3, 3,'l');				//   18 - 20        Residue name    resName       Residue name.

			// fix
			//char ChainIDLetter = 'A';
			//output <<  ( (char)  (ChainIDLetter + Add_chainID ) ); //** 22 �������     Character       chainID       Chain identifier.
			output <<  " ";						//** 22 �������     Character       chainID       Chain identifier.

			PutVa (all_atoms_[ii]->get_residue_index(),output,4, 4,'r');	//   23 - 26        Integer         resSeq        Residue sequence number.

			PutVa (" ",			output,1, 1,'l');		//** 27 �������      AChar           iCode         Code for insertion of residues.
			PutVa ("    ",			output,3, 3,'l');	//** 28-30 �������

			PutVaDouble (all_atoms_[ii]->x(),	output,8, 3,'r');	//31 - 38        Real(8.3)       x             Orthogonal coordinates for X in   Angstroms.
			PutVaDouble (all_atoms_[ii]->y(),	output,8, 3,'r');	//39 - 46        Real(8.3)       y             Orthogonal coordinates for Y in
			PutVaDouble (all_atoms_[ii]->z(),	output,8, 3,'r');	//47 - 54        Real(8.3)       z             Orthogonal coordinates for Z in

			output << endl;
		}



	}
	else if (extension == "own" || extension == "OWN"  )
	{
//		save_own (  file_name  );
	}
}


void Model::
init_phi_psi_owega_backbone_set ()
{
// ������������, ��� ������ ��� �������
	vector < Atom * > core_atoms = get_core_atoms();
	Atom * initial_atom = core_atoms.front();

	string Current_pdb_atom_name  = initial_atom->get_pdb_atom_name();
	if		(Current_pdb_atom_name == "N" )
		ome_atom_set_.push_back(initial_atom);
	else if (Current_pdb_atom_name == "CA" )
		phi_atom_set_.push_back(initial_atom);
	else if (Current_pdb_atom_name == "C" )
		psi_atom_set_.push_back(initial_atom);
	else {
		cout << "It's not main strand atom" << endl;
	}


	Core_iterator        it( initial_atom );

	int counter = 0;
	while ( it.has_next() )
	{
		it.next();
		Atom * current_atom = it.current();

		counter ++;

		string Current_pdb_atom_name  = current_atom->get_pdb_atom_name();
		if		(Current_pdb_atom_name == "N" )
			ome_atom_set_.push_back(current_atom);
		else if (Current_pdb_atom_name == "CA" )
			phi_atom_set_.push_back(current_atom);
		else if (Current_pdb_atom_name == "C" )
			psi_atom_set_.push_back(current_atom);
		else {
			cout << "It's not main strand atom" << endl;
			continue;
		}

	}

	unsigned seqlen = ome_atom_set_.size();
	assert (seqlen == phi_atom_set_.size());
	assert (seqlen == psi_atom_set_.size());

	for (unsigned ii = 0; ii< seqlen; ii++ )
	{
		backbone_set_.push_back(phi_atom_set_[ii]) ;
		backbone_set_.push_back(psi_atom_set_[ii]) ;
		backbone_set_.push_back(ome_atom_set_[ii]) ;
	}

}

vector <double> Model::get_phi_set ()
{
	unsigned int nu_phi = phi_atom_set_.size();

	vector < double > phi_dihedral_set;
	phi_dihedral_set.resize(nu_phi);

	for (unsigned int ii = 0; ii < nu_phi ; ii++ )
		phi_dihedral_set[ii]= phi_atom_set_[ii]->dihedral();

	return phi_dihedral_set;
}


vector <double> Model::get_psi_set ()
{
	unsigned int nu_psi = psi_atom_set_.size();

	vector < double > psi_dihedral_set;
	psi_dihedral_set.resize(nu_psi);

	for (unsigned int ii = 0; ii < nu_psi ; ii++ )
		psi_dihedral_set[ii]= psi_atom_set_[ii]->dihedral();

	return psi_dihedral_set;
}


vector <double> Model::get_ome_set ()
{
	unsigned int nu_ome = ome_atom_set_.size();

	vector < double > ome_dihedral_set;
	ome_dihedral_set.resize(nu_ome);

	for (unsigned int ii = 0; ii < nu_ome ; ii++ )
		ome_dihedral_set[ii]= ome_atom_set_[ii]->dihedral();

	return ome_dihedral_set;
}


void Model::set_phi (const int position_in_sequence, const double Phi)
{
	phi_atom_set_[position_in_sequence]->set_dihedral (Phi);
}

void Model::set_psi (const int position_in_sequence, const double Psi)
{
	psi_atom_set_[position_in_sequence]->set_dihedral (Psi);
}
void Model::set_ome (const int position_in_sequence, const double Ome)
{
	ome_atom_set_[position_in_sequence]->set_dihedral (Ome);
}

void Model::set_phi_set (const vector <double> & phi_dihedral_set)
{
	unsigned int nu_phi = phi_atom_set_.size();
	if (nu_phi != phi_atom_set_.size() )
	{
        log_stream << "nu_phi :"  << nu_phi << "phi_atom_set_.size()   " << phi_atom_set_.size()  << endl;
	}
//	assert ( nu_phi == phi_dihedral_set.size() );

	for (unsigned int ii = 0; ii < nu_phi ; ii++ )
		phi_atom_set_[ii]->set_dihedral(phi_dihedral_set[ii]);
}
void Model::set_psi_set (const vector <double> & psi_dihedral_set)
{
	unsigned int nu_psi = psi_atom_set_.size();
	assert ( nu_psi == psi_dihedral_set.size() );

	for (unsigned int ii = 0; ii < nu_psi ; ii++ )
		psi_atom_set_[ii]->set_dihedral(psi_dihedral_set[ii]);
}
void Model::set_ome_set (const vector <double> & ome_dihedral_set)
{
	unsigned int nu_ome = ome_atom_set_.size();
	assert ( nu_ome == ome_dihedral_set.size() );

	for (unsigned int ii = 0; ii < nu_ome ; ii++ )
		ome_atom_set_[ii]->set_dihedral(ome_dihedral_set[ii]);


}

void  Model::
calc_cartesain_coordinates()
{
	// ������ ���� � ������ ��������� � ���
	// � ���������� ����������
	Atom * initial_atom = core_atoms_.front();

	vector < double > matrix; matrix.resize(9);
	matrix[0]=1;
	matrix[4]=1;
	matrix[8]=1;
	initial_atom->set_rotation_matrix(matrix);
	initial_atom->set_x(0);
	initial_atom->set_y(0);
	initial_atom->set_z(0);

	calc_cartesain_coordinates ( initial_atom );

}

void  Model::assign_phi_psi_ome_by_cont_torsion_set(
		vector < double >  & cont_torsion_set, // ��� ���� ������� ��� ���� ������
		vector < double >  & phi_set,
		vector < double >  & psi_set,
		vector < double >  & ome_set)
{
	int length = cont_torsion_set.size()/3 +1;

	phi_set.resize(length );
	psi_set.resize(length );
	ome_set.resize(length );

	int phi_set_counter=0;
	int psi_set_counter=0;
	int ome_set_counter=0;

	phi_set[phi_set_counter] = 0;	phi_set_counter++;

	int counter=0;
	while ( counter < cont_torsion_set.size() )
	{
		psi_set[psi_set_counter++] = cont_torsion_set[counter++];
		ome_set[ome_set_counter++] = cont_torsion_set[counter++];
		phi_set[phi_set_counter++] = cont_torsion_set[counter++];
	}

	set_phi_set(phi_set);
	set_psi_set(psi_set);
	set_ome_set(ome_set);


}

// !!!!!!!!!!!!!!!!!!!!!!!!!!
void Model::fill_up_main_chain_coordinates(double *chain_coord)
{
	calc_cartesain_coordinates();

	vector < Atom * > backbone_set = get_core_atoms();
//	double *chain_coord = new double [backbone_set.size()];

	int counter = 0;
	for ( int ii=0;ii<backbone_set.size(); ii++ )
	{
		chain_coord[counter]=	backbone_set[ii]->x();  counter++;
		chain_coord[counter]=	backbone_set[ii]->y();	counter++;
		chain_coord[counter]=	backbone_set[ii]->z();	counter++;
	}
}
