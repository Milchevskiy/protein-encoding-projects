#pragma warning( disable : 4786 )

#ifndef CORE_ATTRIBUTES_H
#define CORE_ATTRIBUTES_H

#include <vector>

class Core_attributes
{
public:
	Core_attributes  ();
	~Core_attributes ();

	void set_vector_model		( const std::vector < double > & vector_model );
	void set_rotation_matrix	( const std::vector < double > & rotation_matrix);

	void set_vector_model		( const double * vector_model );
	void set_rotation_matrix	( const double * rotation_matrix);


	void set_dihedral			( const double dihedral);

	void	get_ray				( const int i, double * ray) const;
	double	dihedral			() const	{ return dihedral_;		}
	double	*vector_model		() const	{ return vector_model_;	}
    double  *rotation_matrix	() const	{ return rotation_matrix_;}
 
private:
	double	*vector_model_;
    double  *rotation_matrix_;
    double   dihedral_;
};

#endif