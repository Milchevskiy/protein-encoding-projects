
#include "Core_iterator.h"
#include "Atom.h"

Core_iterator::Core_iterator		( Atom * initial_atom )
{
	current_atom_ = initial_atom;
    find_neigbors();
}

bool Core_iterator::
has_next() const
{
    return ! stack_.empty();
}


Atom * Core_iterator::
current ()
{
    return current_atom_;
}

void Core_iterator::
next    ()
{ 
    current_atom_ = stack_.top();
    stack_.pop();
    find_neigbors();
}

void Core_iterator::
find_neigbors()
{
    int neighbor_size = current_atom_->number_of_neighbors();
    for (int ii=neighbor_size-1; ii>=1; --ii ) 
    {
        Atom * neighbor = current_atom_->get_neighbors(ii);
        if (  neighbor->is_core_atom() )
            stack_.push( neighbor );
    }
}