#ifndef GET_NEAREST_CLASTER_INDEX_H
#define GET_NEAREST_CLASTER_INDEX_H

#include "CommonFunc.h"
#include "Pair_int_double.h"

int get_nearest_claster_index( 	const vector <double> & distance_set );

int get_nearest_claster_index(
	const vector <double> & distance_set,
	double & value );

vector < Pair_int_double > get_sorted_indexed_dist_store( 	const vector <double> & distance_set );





#endif
