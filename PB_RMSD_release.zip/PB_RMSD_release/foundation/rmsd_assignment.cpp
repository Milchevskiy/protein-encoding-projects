#include "CommonFunc.h"
#include "Censorship.h"

#include "Fragment_base/Chain_binary.h"
#include "Chain_store/Chain_Residue_Set.h"

#include "Sheduler.h"

#include "PB_RMSD.h"
#include "Local_constants.h"
#include <cctype>

extern ofstream log_stream;

void rmsd_assignment (
    const string & sourcefilename,const char chain_ID,
    string  &short_flag)
{

    string path_to_outputfilename = new_extension_file_name	(sourcefilename , "RMSD_assignment");
    ofstream out( path_to_outputfilename .c_str() ,ios::binary);
	if ( ! out	)
	{
		log_stream << "ERROR: outputfilename    can't create " << path_to_outputfilename<< endl;
		cout       << "ERROR: outputfilename    can't create " << path_to_outputfilename<< endl;
		exit (1);
	}
	else
        log_stream << endl<< "Output file " << path_to_outputfilename << " was created"  << endl;

    Chain_Residue_Set crs(
        sourcefilename,//PDB_chain_ID ,
        chain_ID,
        Treshold_C_N_Distance,
        distance_epsilon,
        angle_epsilon);


    if ( ! crs.is_there_chain() ) 	{
        log_stream  << "Wrong PDB file or chain  " << chain_ID << " not fount" << endl;
        out << "Wrong PDB file or chain. Chain \' " << chain_ID << "\'   not fount" << endl;
        cout << "Wrong PDB file or chain. Chain \' " << chain_ID << "\'   not fount" << endl;
        exit (-1);
    }

    if ( ! crs.is_pdb_file() ) 	{
        cout << "PDB file or chain not found" << endl;
        log_stream<< "PDB file or chain not found" << endl;
        out << "Wrong PDB file or chain marked by ID " << chain_ID << "not fount" << endl;
        cout << "Wrong PDB file or chain marked by ID " << chain_ID << "not fount" << endl;
        exit (-1);
    }
    if ( ! crs.is_accord_seqres_atom() ) {
        cout << "Sequence by SEQRES contradict given by ATOM pull" << endl;
        out <<  "Sequence by SEQRES contradict given by ATOM pull" << endl;
        log_stream<< "Sequence by SEQRES contradict given by ATOM pull" << endl;
        cout<< "Sequence by SEQRES contradict given by ATOM pull" << endl;
        exit(-1);
    }

    if ( ! crs.is_standard_aminoacisds() ) 	{
        log_stream  << "Wrong aminoacids found  " << endl;
        out << "Wrong aminoacids found  " << endl;
        cout << "Wrong or non-standard aminoacids found  " << endl;
      //  exit (-1);
    }

    crs.save_as_binary();

    if (short_flag !="Y")
        crs.print_protocol ();

    string pdb_chain_ID =crs.get_pdb_chain_ID();
    Chain_binary *chain = new Chain_binary ( pdb_chain_ID );


    int fragment_length = 5;
    int number_of_classes = 16;

    double **claster_motif_coordinates = new double* [number_of_classes] ;
    for ( int ii=0; ii < number_of_classes; ii++  )
        claster_motif_coordinates[ii]  = new double [fragment_length*9];

     for (int ii=0;ii<number_of_classes;ii++)
     {
            for (int kk=0;kk<fragment_length*9;kk++)
                claster_motif_coordinates[ii][kk]=claster_motif_coordinates_[ii][kk];
     }




/// FIX - тут задать возможность передать директорию где заданы углы.
//    string path_to_PB_data= path_to_PB_folder + "cartesian_coordinates.txt";

 //   double **claster_motif_coordinates = fill_up_PB_parameters (
  //      path_to_PB_data,
   //     fragment_length,
     //   number_of_classes );



    string current_extension = ".RMSD_extended.txt";
    if (short_flag !="Y")
        RMSD_detailed_results (
            chain,
            claster_motif_coordinates,
            fragment_length,
            number_of_classes,
            current_extension);


    current_extension = ".RMSD_short.txt";
    RMSD_short_results (
            chain,
            claster_motif_coordinates,
            fragment_length,
            number_of_classes,
            current_extension );



	for (int kk=0; kk<number_of_classes; kk++)			delete [] claster_motif_coordinates[kk];
		delete [] claster_motif_coordinates;

    delete chain;
/*
    string qqq;

    for (int ii=0;ii<sourcefilename.size();ii++)
        qqq  += toupper(sourcefilename[ii]);

    string path_to_binary = new_extension_file_name	(qqq , "bin");

    if( remove(path_to_binary.c_str() ) ) {

        cout << "Error removing file" << endl;
        log_stream << "Error removing file" << endl;
    }
    */

}
