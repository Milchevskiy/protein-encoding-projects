// exact copy of the same name function realtin to Abu_Maimonides_Rambam class
#pragma warning( disable : 4786 )
#include "CommonFunc.h"
#include "Pair_int_double.h"

int get_nearest_claster_index( 	const vector <double> & distance_set )
{
	vector < Pair_int_double > indexed_dist_store;  		indexed_dist_store.clear();

	for ( int kk=0;kk<distance_set.size(); kk++)
		indexed_dist_store.push_back( Pair_int_double (kk,distance_set[kk]) );

	sort (indexed_dist_store.begin(),indexed_dist_store.end() );
	int		nearest_index 	=	indexed_dist_store.front().index() ;

	return nearest_index ;

}


int get_nearest_claster_index(
	const vector <double> & distance_set,
	double & value )
{
	vector < Pair_int_double > indexed_dist_store;  		indexed_dist_store.clear();

	for ( int kk=0;kk<distance_set.size(); kk++)
		indexed_dist_store.push_back( Pair_int_double (kk,distance_set[kk]) );

	sort (indexed_dist_store.begin(),indexed_dist_store.end() );
	int		nearest_index 	=	indexed_dist_store.front().index() ;
    value                   = 	indexed_dist_store.front().value() ;

	return nearest_index ;

}

// ��������: 'nj ����� ���������. FIX �����.
vector < Pair_int_double > get_sorted_indexed_dist_store( 	const vector <double> & distance_set )
{
	vector < Pair_int_double > indexed_dist_store;  		indexed_dist_store.clear();

	for ( int kk=0;kk<distance_set.size(); kk++)
		indexed_dist_store.push_back( Pair_int_double (kk,distance_set[kk]) );

	sort (indexed_dist_store.begin(),indexed_dist_store.end() );
//	int		nearest_index 	=	indexed_dist_store.front().index() ;

	return indexed_dist_store;

}
