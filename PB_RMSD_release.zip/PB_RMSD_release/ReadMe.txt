PB_RMSD 1.0
========

A program for assignment the local structure of a protein by Protein Blocks proposed in [1] 
PB  set contains 16 PBs, 5 residues long.
Geometrical parameters for 16 protein blocks (PB) are presented in the PB / angles.txt file.

Assignment is performed using the RMSD metric for the backbone atom, and the RMSDA metrics from [1] is also used for comparison.

[1] de Brevern AG, Etchebest C, Hazout S. Bayesian probabilistic approach for predicting the backbone network. Proteins. 2000; 287: 271-287.


Requirement
    Standard compliler g++  

Building 
    Run !Bulld_PD_RMSD (Linux) or <CodeBlocks_project_file>  PB_RMSD.cbr for CODE::BLOCKS. 
    Only standard С++ libraries used.  


USAGE:

PB_RMSD [option] input-file chain-ID
    input-file	 standard PDB (Protein Data Bank) file
    chain-ID	 choosern protein chain ID
    -h		Display this message
    -v		print version

USAGE EXAMPLE: PB_RMSD pdb8acn.ent A
    processes a protein ‘A’  from file pdb8acn.ent


Output 
	[PDBfilename].protocol 	- analisys of protein backbone geometry
	[PDBfilename].RMSD_extended.txt  - extended output
	[PDBfilename].RMSD_short.txt	 - short output 

