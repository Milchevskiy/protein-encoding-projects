#!/bin/sh
echo "Hello world"

gcc	src/Da_data.cpp src/Da_solution.cpp src/PutVaDouble.cpp src/Sheduler.cpp src/array_max_value_index.cpp src/da_covar_handle.cpp src/get_extension_file_name.cpp src/new_extensio_file_name.cpp src/sda.cpp src/sweep_operator.cpp src/taskset_get_option.cpp  qqq
rm -rf *.o
