SDA (Stepwise Discriminant Analysis)

This is modification of stepwise discriminant analysis (1).

This modification eliminates the uncertainty in choosing the optimal threshold F-statistics.
K-fold cross validation is carried out (where k is the number of all learning objects) for some diapason threshold F-statistics .
Based on the resulting models, the threshold F-statistics is selected, which gives the best results (That is, the largest number of correct classifications by class).


Requirement
___________
Any standard c++ compiler (only required default STL library)

Bulding
___________
LINUX: Run *build.sh.
Or use Code::Blocks Environment to build project. Project tune file is cda.cbr

WINDOWS: run something like "g++ *.cpp"  in folder sda/


Usage
__________

USAGE:   sda [data_file_name] -l[fisher_min] -u[Fisher_max] -s[step]" << endl;

EXAMLE:  sda ex.dat -l1 -u10 -s1

For clarity see bash file *run_example


TEST
______
Folder test contain ex,dat & ex,name. This files
This is a data file and a corresponding file with predictor names.
Bash file *run_example creates results for this data file.


(1) Ralston A., Wilf H.S., Enslein K. 1960. Mathematical methods for digital computers. New
York,: Wiley.


Support
________

milch@eimb.ru
