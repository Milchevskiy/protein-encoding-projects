
#include <sstream>
#include <map>
#include <fstream>

using namespace std;

void  taskset_get_option
	(ifstream & parm_stream, map <string, string> & options)
{
	string current_line;
	while( getline( parm_stream  , current_line, '\n' ) )
	{
		if (   current_line[0] == '/'  ||
			   current_line[0] == '#'  ||
			   current_line[0] == ' '  ||
			   current_line[0] == '\n' ||
			   current_line[0] == '\0')
			continue;

		string key,meaning;
		istringstream ist (current_line);
		ist >> key >> meaning;

		options [key] = meaning;
	}
}

