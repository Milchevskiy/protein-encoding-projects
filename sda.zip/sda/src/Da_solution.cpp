#include "Da_solution.h"

#include "Sheduler.h"

#include "Da_data.h"

#include "da_covar_handle.h"
#include "array_max_value_index.h"

#include "CommonFunc.h"
#include "Statistic_general_purpose.h"

#include <cassert>

extern ofstream log_stream;

//int one_dimensional_matrix_index (const int ii,const int jj,const int wc) ;
/*
void sweep_operator(
	const int wc,
	const int kk,
	const int flag,
	double *sumxy,
	double *x);
*/

#include <string>

using namespace std;

extern ofstream log_stream;

Da_solution::
~Da_solution()
{

	if ( group_average_value_ )
	{
		 for (int ii =0 ; ii< number_of_groops_; ii++ )
			 delete [] group_average_value_ [ii];
	}
	delete [] group_average_value_ ;

	if ( case_group_index_ )				delete [] case_group_index_;
	if ( intra_group_cross_marix_ ) 		delete [] intra_group_cross_marix_;
	if ( intra_group_cross_marix_diagonal_)	delete [] intra_group_cross_marix_diagonal_;
	if ( cross_marix_ )						delete [] cross_marix_;
	if ( average_value_ )					delete [] average_value_;


	if ( group_classifying_coefficient_	)
	{
		 for (int ii =0 ; ii< number_of_variables_; ii++ )
			 delete [] group_classifying_coefficient_ [ii];
	}
	delete [] group_classifying_coefficient_;

	delete [] constant_of_classifying_function_;

	delete [] apriori_class_content_tare_;

	delete da_da_;
}



Da_solution::
Da_solution( 	 Sheduler	*options ) :
	options_							(options ),
	number_of_groops_					(0),
	number_of_variables_				(0),
	number_of_record_					(0),
	number_of_included_					(0),
	group_average_value_				(0),
	case_group_index_					(0),
	intra_group_cross_marix_			(0),
	intra_group_cross_marix_diagonal_	(0),
	cross_marix_						(0),
	average_value_						(0),
	group_classifying_coefficient_		(0),
	constant_of_classifying_function_   (0),
	apriori_class_content_tare_         (0),
	da_da_								(0)
{
		da_da_	= new Da_data   ( options ) ;

		number_of_groops_	= da_da_->number_of_groops();
        number_of_record_	= da_da_->number_of_record();

		number_of_variables_= da_da_->number_of_variables();

		upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

		allocate ();
		assign_names          ();
}



void Da_solution::
plain_solution ()
{
	memcpy (case_group_index_,da_da_->case_group_index(),sizeof(int)*number_of_groops_ );

	for (int ii=0;ii<number_of_groops_;ii++)
		memcpy (group_average_value_[ii],da_da_->group_average_value(ii),sizeof(double)*number_of_variables_);

	memcpy(intra_group_cross_marix_, da_da_->intra_group_cross_marix(), sizeof(double)*upper_triange_matrix_size_);

	making_intra_group_covariation_matrix();
	prepare_particular_solution ();
	pull_out_discrimination_constants();


}

void Da_solution::
single_calculation ()
{

		double single_calculation_Fisher = atof (options_->option_meaning ("FISHER_FOR_SINGLE_CALC").c_str() ) ;
		refresh_fisher(
			single_calculation_Fisher,
			single_calculation_Fisher,
			atof ( options_->option_meaning ("TOLERANCE").c_str()   ) );
		plain_solution();



		int number_of_record = da_da_->number_of_record();
		double **orthodox_prediction = new double*[number_of_record];
		for (int kk = 0; kk<number_of_record; kk++)
		{
			orthodox_prediction[kk] = new double[number_of_groops_];
			memset(orthodox_prediction[kk], 0, sizeof(double) *number_of_groops_);
		}


//		int number_of_record = da_da_->number_of_record();
		int *array_of_group_index = new int [number_of_record];
		int *predicted_group_index = new int [number_of_record];


		double Quality_plain;
		calc_plain_prediction_table (
 			array_of_group_index,
			predicted_group_index,
			Quality_plain );

		show_prediction_table(
			single_calculation_Fisher,
			array_of_group_index,
			predicted_group_index );

		show_significant_variables ();
//	/*???*/	print_orthodox_result ();
//

		calc_orthodox_prediction(
			array_of_group_index,
			predicted_group_index,
			orthodox_prediction);

		show_orthodox_prediction(
			single_calculation_Fisher,
			array_of_group_index,
			predicted_group_index,
			orthodox_prediction);


		delete [] array_of_group_index  ;
		delete [] predicted_group_index ;

		for (int kk = 0; kk<number_of_record; kk++)
		{
			delete[] orthodox_prediction[kk];
		}
		delete[] orthodox_prediction;


}
void Da_solution::calc_orthodox_prediction(
	int		*array_of_group_index,
	int		*predicted_group_index,
	double	**orthodox_prediction)

{

//	Quality_plain = 0;

	double  *current_values = new double[number_of_variables_ + 1];
	int group_index;

	double *current_classifying_function = new double[number_of_groops_];
//	double *current_probability = new double[number_of_groops_];



	int number_of_records = da_da_->number_of_record();

	for (int ii = 0; ii<number_of_records; ii++)
	{
		da_da_->get_record(
			ii,
			current_values,
			&group_index);

		posterior_probability_to_be_in_each_group(
			current_values,
			current_classifying_function,
			orthodox_prediction[ii]);


	}



	delete[] current_values;
	delete[] current_classifying_function;
//	delete[] current_probability;




}

void Da_solution::
full_jack_nife ( double & best_Fisher)
{

	string protocol_file_name =  new_extension_file_name ( options_->option_meaning ("DATA_FILE_NAME"),"jack_nife_protocol") ;

	ofstream out ( protocol_file_name.c_str()  );
	if ( ! out )
	{

		log_stream << "can't create jack_nife.protocol" << endl;
		cout       << "can't create jack_nife.protocol" << endl;
		exit (1);
	}




	double fisher_min  =  atof ( options_->option_meaning ("FISHER_MIN").c_str()  );
	double fisher_max  =  atof ( options_->option_meaning ("FISHER_MAX").c_str()  );
	double fisher_step =  atof ( options_->option_meaning ("FISHER_STEP").c_str() );
	double tolerance   =  atof ( options_->option_meaning ("TOLERANCE").c_str()   );

	double r_Fisher_in = fisher_max;
	double r_Fisher_out;
//	double best_Fisher ;


	double Quality_jack_nife=0,	Quality_plain;

	double best_Quality_jack_nife =0;


	int number_of_record = da_da_->number_of_record();
	double **orthodox_prediction = new double* [number_of_record] ;
	for ( int kk=0;kk<number_of_record ;kk++)
	{
		orthodox_prediction [kk] = new double [number_of_groops_];
		memset (orthodox_prediction[kk] ,0,sizeof(double) *number_of_groops_);
	}

	int *array_of_group_index = new int [number_of_record];
	int *predicted_group_index = new int [number_of_record];


	PutVa( "Fisher ",			out, 12, 3, 'l');
	PutVa( "nu_included",		out, 12, 3, 'l');
	PutVa( "Quality" ,	out, 12, 3, 'l');
	PutVa( "Quality_jack_nife",	out, 17, 3, 'l');

	out << "|| ";

	out << "Indexes of included varibles" << endl;

	vector < int > included_index ;

	while ( r_Fisher_in >  fisher_min )
	{

		r_Fisher_out = r_Fisher_in ;

		cout << r_Fisher_out << endl;


		single_jack_nife (
			r_Fisher_in,
			r_Fisher_out,
			tolerance ,
			Quality_jack_nife,
			Quality_plain,
			included_index,
			orthodox_prediction,
			array_of_group_index,
			predicted_group_index);


		PutVaDouble ( r_Fisher_in,			out, 12, 3, 'l');
		PutVa		( number_of_included_,	out, 12, 3, 'l');
		PutVaDouble ( Quality_plain ,		out, 12, 8, 'l');
		PutVaDouble ( Quality_jack_nife,	out, 17, 8, 'l');

		out << " || ";

		for ( int kk=0; kk<number_of_included_; kk++ )
			PutVa		( included_index[kk],	out, 5, 2, 'l');

		out << endl;


		if ( Quality_jack_nife > best_Quality_jack_nife )
		{
			best_Quality_jack_nife = Quality_jack_nife ;
			best_Fisher = r_Fisher_in;
		}

		r_Fisher_in -= fisher_step;
	}


	single_jack_nife (
		best_Fisher,
		best_Fisher,
		tolerance,
		Quality_jack_nife,
		Quality_plain,
		included_index,
		orthodox_prediction,
		array_of_group_index,
		predicted_group_index);

	show_orthodox_prediction (
		best_Fisher,
		array_of_group_index,
		predicted_group_index,
		orthodox_prediction );


	refresh_fisher(
		best_Fisher,
		best_Fisher,
		tolerance );
	plain_solution();
	show_significant_variables () ;

	show_prediction_table(
		best_Fisher,
		array_of_group_index,
		predicted_group_index );



	for ( int kk=0;kk<number_of_record ;kk++)
		delete [] orthodox_prediction [kk] ;
	delete [] orthodox_prediction ;

	delete [] array_of_group_index;
	delete [] predicted_group_index;

}

void Da_solution::
show_prediction_table(
	double best_Fisher,
	const int *array_of_group_index,
	const int *predicted_group_index )
{

	string extension;
	string run_mode = options_->option_meaning ("RUN_MODE");

	if ( run_mode  == "JACK_NIFE")
		extension = "jack_nife_PREDICTION_TABLE";
	else if ( run_mode  == "SINGLE_CALCULATION" )
		extension = "single_calculation_PREDICTION_TABLE";

	string name =  new_extension_file_name ( options_->option_meaning ("DATA_FILE_NAME"),extension) ;

	ofstream out ( name.c_str()  );
	if ( ! out )
	{
		log_stream << "can't create " << name << endl;
		cout       << "can't create " << name << endl;
		exit (1);
	}


	out << "## " << run_mode << " run mode !" << endl;

	if ( run_mode  == "JACK_NIFE")
	{
		out << "## Best True prediction was achieved for Fisher value " << best_Fisher << endl ;
		out << "## Checked Fisher values: from " << options_->option_meaning ("FISHER_MAX") << " to " << options_->option_meaning ("FISHER_MIN") << "   with step " << options_->option_meaning ("FISHER_STEP") << endl << endl;
	}
	else if ( run_mode  == "SINGLE_CALCULATION" )
	{
		out << "## current Fisher value is " << best_Fisher << endl<< endl ;
	}




	int **prediction_table = new int* [number_of_groops_];
	for (int kk=0;kk<number_of_groops_;kk++)
	{
		prediction_table[kk] = new int [number_of_groops_];
		memset(prediction_table[kk],0, number_of_groops_*sizeof (int) );
	}


	int number_of_record = da_da_->number_of_record();
	for ( int kk=0;kk<number_of_record ;kk++)
		prediction_table[ array_of_group_index[kk] ][ predicted_group_index[kk] ] += 1;


	double Quality = 0;
	for (int kk=0;kk<number_of_groops_;kk++)
		Quality += prediction_table[kk][kk];

	Quality /= number_of_record;

	out << "Simple prediction table" << endl;
	for (int ii=0;ii<number_of_groops_;ii++)
	{
		PutVa(ii,out,3, 0,'l');			out << ":";
		for ( int jj=0;jj<number_of_groops_;jj++) 			{
			PutVa (prediction_table[ii][jj],out,12, 0,'l');			}
		out << endl ;
	}

	out << "Precentage prediction table" <<endl;
	for (int ii=0;ii<number_of_groops_;ii++)
	{
		PutVa(ii,out,3, 0,'l');			out << ":";
		for ( int jj=0;jj<number_of_groops_;jj++) 			{
			PutVaDouble (double (prediction_table[ii][jj]) * 100/case_group_index_[ii],out,12, 3,'l');
		}
		out << endl ;

	}

	out << endl << "True prediction " ;
	PutVaDouble(100*Quality,out,10,5,'l');
	out << endl;





	for (int kk=0;kk<number_of_groops_;kk++)
		delete [] prediction_table[kk];
	delete [] prediction_table;
}


void Da_solution::
show_orthodox_prediction (
	const double	Fisher,
	const int		*array_of_group_index,
	const int		*predicted_group_index,
	double	**orthodox_prediction )
{

	string extension;
	string run_mode = options_->option_meaning ("RUN_MODE");

	if ( run_mode  == "JACK_NIFE")
		extension = "jack_nife_orthodox";
	else if ( run_mode  == "SINGLE_CALCULATION" )
		extension = "single_calculation_orthodox";

	string orhodox_name =  new_extension_file_name ( options_->option_meaning ("DATA_FILE_NAME"),extension) ;

	ofstream out ( orhodox_name.c_str()  );
	if ( ! out )
	{
		log_stream << "can't create " << orhodox_name << endl;
		cout       << "can't create " << orhodox_name << endl;
		exit (1);
	}



	int number_of_records = da_da_->number_of_record();

	out << "#nu. of groops    nu. of records" << endl;
	out << number_of_groops_ << "  " << number_of_records << endl;

	PutVa ("#obs. ",out, 8,3,'l');
	PutVa ("pred. ",out, 8,3,'l');

	for (int kk=0;kk<number_of_groops_ ;kk++)
    {
        	out << "P(";
        	PutVa (kk,out,4,0,'l');
        	out << ")";

    }
    out << endl;

	for ( int ii=0; ii<number_of_records;ii++)
	{
		PutVa (array_of_group_index	[ii],out, 8,3,'l');
		PutVa (predicted_group_index[ii],out, 8,3,'l');
		for (int kk=0;kk<number_of_groops_ ;kk++)
			PutVaDouble (orthodox_prediction[ii][kk],out, 8,3,'l');

		out << endl;

	}
}



double Da_solution::calc_plain_quality ()
{
	double Quality_plain = 0;

	double  *current_values = new double [number_of_variables_ + 1] ;
	int group_index;

	double *current_classifying_function	= new double [number_of_groops_];
	double *current_probability				= new double [number_of_groops_];



	int number_of_records = da_da_->number_of_record();

	for ( int ii=0;ii<number_of_records; ii++ )
	{
		da_da_->get_record (
			ii,
			current_values,
			&group_index );

		posterior_probability_to_be_in_each_group (
			current_values,
			current_classifying_function,
			current_probability	);


		int index_of_max_probability = array_max_value_index ( current_probability, number_of_groops_);

		if ( group_index == index_of_max_probability )
			Quality_plain  += 1;

	}
	Quality_plain /= number_of_records;


	delete [] current_values	;
	delete [] current_classifying_function;
	delete [] current_probability		;

	return Quality_plain;
}


void Da_solution::calc_plain_prediction_table (
 	int		*array_of_group_index,
	int		*predicted_group_index,
	double   & Quality_plain )
{


	Quality_plain = 0;

	double  *current_values = new double [number_of_variables_ + 1] ;
	int group_index;

	double *current_classifying_function	= new double [number_of_groops_];
	double *current_probability				= new double [number_of_groops_];



	int number_of_records = da_da_->number_of_record();

	for ( int ii=0;ii<number_of_records; ii++ )
	{
		da_da_->get_record (
			ii,
			current_values,
			&group_index );

		posterior_probability_to_be_in_each_group (
			current_values,
			current_classifying_function,
			current_probability	);


		int index_of_max_probability = array_max_value_index ( current_probability, number_of_groops_);

//		int index_of_max_probability = array_max_value_index (orthodox_prediction[ii], number_of_groops_);

		predicted_group_index [ii] = index_of_max_probability;
		array_of_group_index  [ii] = group_index;


		if ( group_index == index_of_max_probability )
			Quality_plain  += 1;

	}
	Quality_plain /= number_of_records;

	log_stream << "Quality_plain: " << Quality_plain << endl;
	for (int kk=0; kk< 100; kk++)
	{
        log_stream << predicted_group_index [kk] << endl;
	}


	delete [] current_values	;
	delete [] current_classifying_function;
	delete [] current_probability		;

}


void Da_solution::
single_jack_nife (
    const double r_Fisher_in,
	const double r_Fisher_out,
	const double r_tolerance ,
	double & Quality_jack_nife,
	double & Quality_plain ,
	vector < int > & included_index,
	double **orthodox_prediction,
	int *array_of_group_index,
	int *predicted_group_index)
{


	included_index.resize(0);

	Quality_jack_nife	= 0;
//	double Quality = 0;

	refresh_fisher ( r_Fisher_in,r_Fisher_out,r_tolerance);
	plain_solution ();
	Quality_plain = calc_plain_quality ();
	pull_out_included_index ( included_index );


	double  *current_values = new double [number_of_variables_ + 1] ;
	int group_index;

	double *current_classifying_function	= new double [number_of_groops_];
	double *current_probability				= new double [number_of_groops_];

	int number_of_records = da_da_->number_of_record();
	for ( int ii=0;ii<number_of_records; ii++ )
	{
// refresh covariation matrix
		memcpy (case_group_index_,da_da_->case_group_index(),sizeof(int)*number_of_groops_ );
		for (int kk=0;kk<number_of_groops_;kk++)
			memcpy (group_average_value_[kk],da_da_->group_average_value(kk),sizeof(double)*number_of_variables_);
		memcpy(intra_group_cross_marix_, da_da_->intra_group_cross_marix(), sizeof(double)*upper_triange_matrix_size_);
// **************************

		da_da_->get_record (
			ii,
			current_values,
			&group_index );



		da_covar_subtraction(
			number_of_variables_, current_values, group_average_value_[group_index]  ,
	        case_group_index_[group_index], intra_group_cross_marix_);

		making_intra_group_covariation_matrix();
		push_in_mandatory_variables ( included_index );

		pull_out_discrimination_constants();

		posterior_probability_to_be_in_each_group (
			current_values,
			current_classifying_function,
			orthodox_prediction [ii] );

		int index_of_max_probability = array_max_value_index (orthodox_prediction[ii], number_of_groops_);

		predicted_group_index [ii] = index_of_max_probability;
		array_of_group_index  [ii] = group_index;
		if ( group_index == index_of_max_probability )
			Quality_jack_nife += 1;
	}

	Quality_jack_nife /= number_of_records;

	delete [] current_values	;
	delete [] current_classifying_function;
	delete [] current_probability		;


}

void Da_solution::
analyse_result ()
{

}

void Da_solution::
pull_out_included_index (vector < int > & included_index )
{
	included_index.resize(0); // �����

	double *T = cross_marix_;
	double *W = intra_group_cross_marix_;

	int N  = number_of_record_;
	int NP = number_of_included_;
	int NQ = number_of_groops_;

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	for (int ii=0;ii<number_of_variables_;ii++)
	{
		int index = one_dimensional_matrix_index(  ii,  ii, number_of_variables_) ;
		if ( W [index] < (-1)*VERY_SMALL_POSITIVE_VALUE   )
		{
			included_index.push_back (ii);

/*			double Fisher_exclusion = (( W [index] - T [index]) / T [index] ) * (N-NP-NQ)/((double)(NQ-1)) ;

			PutVaDouble (Fisher_exclusion,vs_out,8, 3,'r');
			PutVa( variable_names_ [ii],vs_out,10, 8,'r');
			vs_out << endl;
*/
		}
	}
}

void Da_solution::
read_Precursor_legacy ()
{
		string bin_file_name = new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "precursor_binary");

		ifstream precursor_binary_stream( bin_file_name .c_str() ,ios::binary);
		if ( ! precursor_binary_stream)
		{
			log_stream << " can't read precursor_binary_stream " << bin_file_name << endl;
			cout       << " can't read precursor_binary_stream " << bin_file_name << endl;
			exit (1);
		}

		precursor_binary_stream.read ( (char* ) & number_of_groops_,			sizeof (int)  );
		precursor_binary_stream.read ( (char* ) & number_of_variables_,			sizeof (int)  );
		precursor_binary_stream.read ( (char* ) & number_of_record_,				sizeof (int)  );


		allocate ();

		precursor_binary_stream.read ( (char* ) case_group_index_,		number_of_groops_*sizeof (int));

		for ( int ii=0; ii < number_of_groops_; ii++ )
			precursor_binary_stream.read ( (char* ) group_average_value_[ii],	number_of_variables_*sizeof (double));


		int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;
		precursor_binary_stream.read ( (char* ) intra_group_cross_marix_,	upper_triange_matrix_size*sizeof (double));




}

/***** format for result binary file:
number_of_groops_,		sizeof (int)  );
number_of_variables_,	sizeof (int)  );
number_of_record_:		sizeof (int)  );
case_group_index_:		number_of_groops_*sizeof (int));

group_average_value_ :		number_of_groops_ *number_of_variables_*sizeof (double));
intra_group_cross_marix_:	number_of_variables_*(number_of_variables_+1)/2 * sizeof (double)
***************/

void Da_solution::
allocate ()
{

		case_group_index_	= new int [number_of_groops_]; 	memset (case_group_index_,0,sizeof(int)*number_of_groops_);
		group_average_value_ = new double* [number_of_groops_] ;	memset (group_average_value_ ,0,sizeof(double*)	 *number_of_groops_);
		for (int ii=0;ii<number_of_groops_;ii++)
		{
			group_average_value_[ii] = new double [number_of_variables_];
			memset (group_average_value_[ii],0,sizeof(double)*number_of_variables_);
		}

		int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;
		intra_group_cross_marix_             = new double [upper_triange_matrix_size ];
		memset (intra_group_cross_marix_ ,0,sizeof(double)*upper_triange_matrix_size);

		cross_marix_                         = new double [ upper_triange_matrix_size ];
		memset (cross_marix_              ,0,sizeof(double)*upper_triange_matrix_size);

		average_value_                       = new double [number_of_variables_];
		memset (average_value_            ,0,sizeof(double)*number_of_variables_);

		intra_group_cross_marix_diagonal_	= new double [number_of_variables_] ;
		memset (intra_group_cross_marix_diagonal_,0,sizeof(double)*number_of_variables_);


		group_classifying_coefficient_	= new double* [number_of_variables_];
		for ( int ii=0;ii<number_of_variables_;ii++)
		{
			group_classifying_coefficient_[ii]= new double [number_of_groops_] ;
			memset (group_classifying_coefficient_[ii],0,sizeof (double) * number_of_groops_);
		}

		constant_of_classifying_function_	= new double [ number_of_groops_ ];
		memset (constant_of_classifying_function_,0,sizeof (double) * number_of_groops_ );

		apriori_class_content_tare_			= new double [number_of_groops_];
		memset (apriori_class_content_tare_,0,sizeof (double) * number_of_groops_ );
}


void Da_solution::
show_data_from_source()
{
	string result_file_name = new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "show_data_from_source");

	ofstream sr_stream ( result_file_name.c_str());
	if ( ! sr_stream )
	{
		log_stream << "fill_up_database(): ERROR -  can't create rejected_files.protocol" << endl;
		cout       << "fill_up_database(): ERROR -  can't create rejected_files.protocol" << endl;
		exit (1);
	}


	sr_stream << "NUMBER_OF_GROOPS   : "	<< number_of_groops_	<< endl	;
	sr_stream << "NUMBER_OF_VARIABLES: "	<< number_of_variables_	<< endl	;
	sr_stream << "NUMBER_OF_CASES   : "		<< number_of_record_		<< endl	;

	sr_stream << "GROUP_AVERAGE_VALUE : " << endl;
	for ( int ii=0; ii < number_of_groops_; ii++ )
	{
		for (int jj=0; jj < number_of_variables_; jj++ )
			PutVaDouble ( group_average_value_[ii][jj],sr_stream, 10, 5, 'l') ;
		sr_stream << endl;
	}


	sr_stream << "CASE_GROUP_INDEX : " << endl;
	for ( int ii=0; ii < number_of_groops_; ii++ )
		PutVa( case_group_index_[ii],sr_stream, 10, 5, 'l') ;
	sr_stream <<  endl;



	int upper_triange_matrix_size = number_of_variables_*(number_of_variables_+1)/2;

	sr_stream << "INTRA_GROUP_CROSS_MARIX: " << endl;
	for ( int ii =0 ; ii < upper_triange_matrix_size; ii++  )
		PutVaDouble ( intra_group_cross_marix_[ii],sr_stream, 10, 5, 'l') ;
	sr_stream << endl;

	sr_stream << "INTRA_GROUP_CROSS_MARIX_DIAGONAL_: " << endl;
	for ( int ii =0 ; ii < number_of_variables_; ii++  )
		PutVaDouble ( intra_group_cross_marix_diagonal_[ii],sr_stream, 10, 5, 'l') ;
	sr_stream << endl;

	sr_stream << "CROSS_MARIX_: " << endl;
	for ( int ii =0 ; ii < upper_triange_matrix_size; ii++  )
		PutVaDouble ( cross_marix_[ii],sr_stream, 10, 5, 'l') ;
	sr_stream << endl;


	sr_stream << "AVERAGE_VALUE_: " << endl;
	for ( int ii =0 ; ii < number_of_variables_; ii++  )
		PutVaDouble ( average_value_[ii],sr_stream, 10, 5, 'l') ;
	sr_stream << endl;

}


void Da_solution::making_intra_group_covariation_matrix ()
{

// ���� ��-�������� - ��� jack-nife ���� ��
// ������ ��� �������������	number_of_record_ ������ �� case_group_index_[ii]
// �� � apriori_class_content_tare_ ����
// **************************************************
	number_of_record_ = 0;
	for (int i=0; i<number_of_groops_;i++)
		number_of_record_ += case_group_index_[i];
// **************************************************

	memset (average_value_            ,0,sizeof(double)*number_of_variables_);


	for ( int kk =0; kk< number_of_variables_; kk++ )
	{
		for ( int ii =0; ii< number_of_groops_; ii++ )
		{
			average_value_ [kk] +=  case_group_index_[ii]*group_average_value_[ii][kk];
		}
		average_value_ [kk] /= number_of_record_;
	}

	for ( int    ii=0;ii<number_of_variables_;ii++ )
	{
		for (int jj=ii; jj<number_of_variables_;jj++)
		{
			int index = one_dimensional_matrix_index (ii,jj,number_of_variables_);
			cross_marix_[index]  =	intra_group_cross_marix_[ index ] ;

			for (int kk=0;kk<number_of_groops_;kk++)
			{

				cross_marix_[index]  +=
					case_group_index_[kk]*( group_average_value_[kk][ii] - average_value_[ii] ) * ( group_average_value_[kk][jj] - average_value_[jj] );
			}
		}
	}
	for ( int ii=0;ii<number_of_variables_;ii++ )
	{
		int index = one_dimensional_matrix_index (ii,ii,number_of_variables_);
		intra_group_cross_marix_diagonal_[ii] = intra_group_cross_marix_[ index ];
	}


	for (  int ii=0;ii< number_of_groops_; ii++ )
		apriori_class_content_tare_ [ii] = (double) case_group_index_[ii] / number_of_record_;


}

void Da_solution::refresh_fisher (
	const double r_Fisher_in,
	const double r_Fisher_out,
	const double r_tolerance)
{
	 Fisher_in_  =	 r_Fisher_in;
	 Fisher_out_ = 	 r_Fisher_out;
	 tolerance_	 =	 r_tolerance;
}

void Da_solution::prepare_particular_solution ()
{
//	vector <double> x; x.resize(number_of_variables_);
	double *x = new double [number_of_variables_];
	memset (x,0,number_of_variables_*sizeof (double) );


    int flag,kk,iter=0;

    number_of_included_ = 0;
   	while ( pedantic_selvar  (flag,kk) )
	{
		sweep_operator(number_of_variables_,kk,flag,intra_group_cross_marix_,x);
		sweep_operator(number_of_variables_,kk,flag,cross_marix_            ,x);

		number_of_included_ += -flag;
//		included_index_.push_back( kk );

		if(++iter > 2*number_of_variables_ )
			break;
    }

	delete [] x;
}

void Da_solution::
push_in_mandatory_variables ( vector < int > & mandatory_index )
{
	double *x = new double [number_of_variables_];
	memset (x,0,number_of_variables_*sizeof (double) );

	int flag = -1;

	int size = mandatory_index.size();

	int current_counter_of_included = 0;

	for (int kk=0; kk< size;kk++)
	{
		sweep_operator(number_of_variables_,mandatory_index[kk],flag,intra_group_cross_marix_,x);
		sweep_operator(number_of_variables_,mandatory_index[kk],flag,cross_marix_            ,x);

		current_counter_of_included += -flag;
	}

	delete [] x;
}



bool Da_solution::pedantic_selvar (int & FLAG,int & K)
{
/*
	vector <double> T = cross_marix_;
	vector <double> W = intra_group_cross_marix_;
	vector <double> D = intra_group_cross_marix_diagonal_;
*/
	double *T = cross_marix_;
	double *W = intra_group_cross_marix_;
	double *D = intra_group_cross_marix_diagonal_;


	int M  = number_of_variables_;
	int N  = number_of_record_;
	int NP = number_of_included_;
	int NQ = number_of_groops_;
	double TOL  = tolerance_;
	double FIN  = Fisher_in_;
	double FOUT = Fisher_out_;


	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	double VI = NQ*FOUT + 1;
	double VO = 1.0;

	double V;
	int KO,KI;

	for (int I=0;I<M;I++)
	{
		int index = one_dimensional_matrix_index(  I,  I, number_of_variables_) ;
		if ( fabs ( T [ index ] )  < VERY_SMALL_POSITIVE_VALUE  )
			continue;

		V= W[index]/T[index];

		if ( V >= VI )
			continue;

		if ( W[index] < 0 ) // fix < VERY_SMALL_POSITIVE_VALUE
			goto label2;

		if ( W[index]/D[I] < TOL )
			continue;

		if ( V >= VO )
			continue;

		VO = V;
		KO = I;
		continue;
label2:
		VI = V;
		KI = I;
	}
	FLAG = 0;

	if ( ((1-VO)/VO) * (N-NP-NQ)/(NQ-1) >= FIN  )
		FLAG = -1;
	if ( (VI-1)*(N-NP-NQ+1)/(NQ-1) < FOUT)
		FLAG = 1;

	K = KO;

	if (FLAG == 1)
		K = KI;

	if (FLAG)		return true;
	else            return false;
}

void Da_solution::assign_Fisher_paramemters (
		const double Fisher_in ,
		const double Fisher_out,
		const double tolerance )
{

		Fisher_in_   =  Fisher_in ;
		Fisher_out_  =	Fisher_out;
		tolerance_   =	tolerance ;
}

void     Da_solution::pull_out_discrimination_constants()
{

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();
/*
	group_classifying_coefficient_.resize(number_of_variables_);
	for (int ii=0;ii<number_of_variables_;ii++)
		group_classifying_coefficient_[ii].resize(number_of_groops_) ;


	memset (group_classifying_coefficient_,0,sizeof(double)*number_of_groops_);
*/

	for ( int  ii=0;ii<number_of_variables_;ii++)
		memset (group_classifying_coefficient_[ii],0,sizeof (double) * number_of_groops_);

	memset (constant_of_classifying_function_,0,sizeof (double) * number_of_groops_ );

	for ( int ii=0;ii<number_of_variables_;ii++)
	{
		int index = one_dimensional_matrix_index(  ii,  ii, number_of_variables_) ;
		if ( intra_group_cross_marix_ [index]  >  -VERY_SMALL_POSITIVE_VALUE )
			continue;

		for ( int gg=0;gg<number_of_groops_;gg++)
		{
			for ( int jj=0;jj<number_of_variables_;jj++)
			{
//									double  test = group_classifying_coefficient_[ii][gg];

				int index = one_dimensional_matrix_index(  jj,  jj, number_of_variables_) ;
				if ( intra_group_cross_marix_ [index]  >  -VERY_SMALL_POSITIVE_VALUE )
					continue;

				index = one_dimensional_matrix_index(  ii,  jj, number_of_variables_) ;
				group_classifying_coefficient_[ii][gg] +=  intra_group_cross_marix_ [index] * group_average_value_ [gg][jj];
			}
		}
	}

	double Const = number_of_groops_ - number_of_record_ ;
	for ( int ii=0;ii<number_of_variables_;ii++)
	{

		for ( int gg=0;gg<number_of_groops_;gg++)
			group_classifying_coefficient_[ii][gg] *= Const;
	}


	//fix- move it to constructor
//	constant_of_classifying_function_.resize(number_of_groops_);

	for ( int gg=0;gg<number_of_groops_;gg++)
	{
		for ( int jj=0;jj<number_of_variables_;jj++)
		{
			int index = one_dimensional_matrix_index(  jj,  jj, number_of_variables_) ;
			if ( intra_group_cross_marix_ [index]  >  -VERY_SMALL_POSITIVE_VALUE )
				continue;
			constant_of_classifying_function_[gg] -= group_average_value_ [gg][jj]*group_classifying_coefficient_[jj][gg]/2;
		}
	}
}

/*
group_classifying_coefficient_
*/

void 	Da_solution::
well_bred_prediction ()
{
	string result_file_name	= new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "well_bred_prediction");
	ofstream  out ( result_file_name.c_str() );
	if ( ! out)	{	cout << "can't create file " << result_file_name << endl;
		assert (  out );		exit (1);	}


	double *current_values					= new double [number_of_variables_+1];
	double *current_classifying_function	= new double [number_of_groops_];
	double *current_probability				= new double [number_of_groops_];

	int current_group_number;


	out << number_of_groops_ << "  " << number_of_record_ << endl;

	for ( int record_index = 0; record_index < number_of_record_ ; record_index++)
	{
		da_da_->get_record (
			record_index,
			current_values,
			&current_group_number );

		posterior_probability_to_be_in_each_group (
			current_values,
			current_classifying_function,
			current_probability	);


		PutVa 	(current_group_number ,out,5, 3,'l');
		for ( int gg=0;gg<number_of_groops_;gg++)
			PutVaDouble (current_probability[gg],out,9, 5,'r'); out << " ";
		out << endl;

	}


	delete [] current_values	;
	delete [] current_classifying_function;
	delete [] current_probability		;
}


void 	Da_solution::
print_orthodox_result ()
{
	string result_file_name					= new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "orthodox_result");
	string significant_variables_file_name	= new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "var_significant");

	ofstream  out ( result_file_name.c_str() );
	if ( ! out)	{	cout << "can't create file " << result_file_name << endl;
		assert (  out );		exit (1);	}


//	string significant_variables_file_name = new_extension_file_name (data_file_name_,"var_significant");
	ofstream  vs_out ( significant_variables_file_name .c_str() );
	if ( ! vs_out )	{	cout << "can't create file " << significant_variables_file_name << endl;
		assert (  vs_out );		exit (1);	}


	double *T = cross_marix_;
	double *W = intra_group_cross_marix_;



	int N  = number_of_record_;
	int NP = number_of_included_;
	int NQ = number_of_groops_;

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	for (int ii=0;ii<number_of_variables_;ii++)
	{
		int index = one_dimensional_matrix_index(  ii,  ii, number_of_variables_) ;
		if ( W [index] < (-1)*VERY_SMALL_POSITIVE_VALUE   )
		{
			double Fisher_exclusion = (( W [index] - T [index]) / T [index] ) * (N-NP-NQ)/((double)(NQ-1)) ;

			PutVaDouble (Fisher_exclusion,vs_out,8, 3,'r');
			PutVa( variable_names_ [ii],vs_out,10, 8,'r');
			vs_out << endl;

		}
	}


	out << number_of_groops_ << "  " << number_of_record_ << endl;


// FIX: I should make for binary input file too

	string data_file_name = options_->option_meaning ("DATA_FILE_NAME");

	ifstream  data_stream ( data_file_name.c_str() );
	if ( ! data_stream )	{	cout << "can't find file " << data_file_name << endl;
		assert (  data_stream  );		exit (1);	}
	string current_line;
	getline( data_stream , current_line, '\n' );


	double *current_values					= new double [number_of_variables_+1];
	double *current_classifying_function	= new double [number_of_groops_];
	double *current_probability				= new double [number_of_groops_];


	int count =0;
	while( getline( data_stream , current_line, '\n' ) )
	{

		double current_group_number;
		istringstream ist (current_line);
		ist >> current_group_number;

		double value ;
//		vector < double > current_values;

		int check_index = 0;
		while ( ist >> value )
		{
			current_values [check_index ] = value ;
//			current_values.push_back( value );
			check_index ++;
		}

		if ( (count % 1000  ) == 0 )
			cout << count <<  "++ " << value <<  endl;

		assert ( check_index ==  number_of_variables_  );
//		current_values.push_back (current_group_number);

		current_values [check_index] = current_group_number;

			//cout << count << " " ;

	//	vector < double > probabilities = posterior_probability_to_be_in_each_group ( current_values );

		posterior_probability_to_be_in_each_group (
			current_values,
			current_classifying_function,
			current_probability	);

		int group_index = current_values[number_of_variables_];

		PutVa 	(group_index ,out,5, 3,'l');

		for ( int gg=0;gg<number_of_groops_;gg++)
		{
			PutVaDouble (current_probability[gg],out,9, 5,'r'); out << " ";
		}

		out << endl;

		count ++;
	}

	delete [] current_values	;
	delete [] current_classifying_function;
	delete [] current_probability		;

}

void Da_solution::
posterior_probability_to_be_in_each_group (
	const double *current_case,
	double *current_classifying_function,
	double *current_probability	)
{

/*
	vector < double > current_classifying_function;
	current_classifying_function.resize(number_of_groops_);

	vector < double > current_probability;
	current_probability.resize(number_of_groops_);
*/

	memset (current_classifying_function,0,  number_of_groops_*sizeof (double) );


	for ( int hh=0; hh< number_of_groops_;hh++)
	{
		current_classifying_function [hh]  = constant_of_classifying_function_[hh];
		for (int ii=0; ii < number_of_variables_;ii++)
		{
			current_classifying_function [hh] += current_case [ii] * group_classifying_coefficient_[ii][hh];
		}
	}


	for ( int hh=0; hh< number_of_groops_;hh++)
	{
		double subsidiary_sum =0.0;
		for ( int kk=0; kk< number_of_groops_;kk++)
		{
			/*general mode */
			//subsidiary_sum += exp (current_classifying_function [kk] - current_classifying_function [hh]);

		// taking into consideration class content
			double power_value =  apriori_class_content_tare_[kk] + current_classifying_function [kk]
			                    - apriori_class_content_tare_[hh] - current_classifying_function [hh] ;

			subsidiary_sum += exp ( power_value );
		}


			current_probability[hh] = 1/subsidiary_sum ;

	}


//	return current_probability;

}
void	 Da_solution::assign_names                          ()
{

	string names_file_name = new_extension_file_name (options_->option_meaning ("DATA_FILE_NAME"), "names" );
	ifstream  names_stream ( names_file_name.c_str() );




	if ( ! names_stream )
	{
		cout << "REMEMBER! can't find file " << names_file_name << endl;
		variable_names_.resize (number_of_variables_);

		for (int ii=0;ii<number_of_variables_;ii++)
		{
			{
				ostringstream ost ;
				ost << "predictor_" << ii;

				variable_names_[ii] = ost.str();
			}
		}
	}

	else
	{
		int ii=0;
		string current_line;
		while( getline( names_stream , current_line, '\n' ) )
		{
			if ( current_line [0] == '/' ||  current_line [0] == '#' || current_line [0] == ' '  )
				continue;

			variable_names_.push_back ( current_line ) ;

		}
		int variable_names_size  = variable_names_.size() ;

		if ( variable_names_.size() != number_of_variables_ )
		{
			cout << "Check number of variables in file " << names_file_name << endl;
			cout << "variable_names_size = " <<  variable_names_size  << endl;
			cout << "number_of_variables = " <<  number_of_variables_ << endl;
			assert (ii == number_of_variables_ );
			exit (1);
		}
	}
}

void 	Da_solution::
print_prediction_parameters ()
{

	string result_file_name = new_extension_file_name (options_->option_meaning ("DATA_FILE_NAME"),"prediction_template");

	ofstream  out ( result_file_name.c_str() );
	if ( ! out)	{	cout << "can't create file " << result_file_name << endl;
		assert (  out );		exit (1);	}

//	out << "NUMBER OF GROUPS" << endl;
	PutVa 	(number_of_groops_,out,10, 0,'l');			out << endl ;
//	out << endl << "NUMBER OF VARIABLES" << endl;
	PutVa 	(number_of_variables_,out,10, 0,'l');		out << endl ;
//	out << endl ;

//	out << "CONTENT for classes" << endl;
	for ( int hh=0; hh< number_of_groops_;hh++)
		PutVaDouble  	(apriori_class_content_tare_[hh],out,25, 10,'l');
	out << endl ;


//	out << "CONSTANTS OF CLASSIFYING FUNCTIONS" << endl;
	for ( int hh=0; hh< number_of_groops_;hh++)
		PutVaDouble  	(constant_of_classifying_function_[hh],out,25, 10,'l');
	out << endl ;

//	out << "GROUP CLASSIFYING COEFFICIENTS" << endl;

	for ( int hh=0; hh< number_of_groops_;hh++)
	{
		for (int ii=0; ii < number_of_variables_;ii++)
			PutVaDouble 	(group_classifying_coefficient_[ii][hh],out,25, 10,'l');

		out << endl ;
	}
}




void 	Da_solution::
print_prediction_parameters (ofstream &out )
{

	PutVa 	(number_of_groops_,out,10, 0,'l');			out << endl ;
	PutVa 	(number_of_variables_,out,10, 0,'l');		out << endl ;

	for ( int hh=0; hh< number_of_groops_;hh++)
		PutVaDouble  	(apriori_class_content_tare_[hh],out,25, 10,'l');
	out << endl ;

	for ( int hh=0; hh< number_of_groops_;hh++)
		PutVaDouble  	(constant_of_classifying_function_[hh],out,25, 10,'l');
	out << endl ;


	for ( int hh=0; hh< number_of_groops_;hh++)
	{
		for (int ii=0; ii < number_of_variables_;ii++)
			PutVaDouble 	(group_classifying_coefficient_[ii][hh],out,25, 10,'l');

		out << endl ;
	}
}

void 	Da_solution::
show_significant_variables ()
{

	string extension;
	string run_mode = options_->option_meaning ("RUN_MODE");

	if ( run_mode  == "JACK_NIFE")
		extension = "jack_nife_var_significant";
	else if ( run_mode  == "SINGLE_CALCULATION" )
		extension = "single_calculation_var_significant";

	string significant_variables_file_name = new_extension_file_name (options_->option_meaning ("DATA_FILE_NAME"),extension );

	ofstream  vs_out ( significant_variables_file_name .c_str() );
	if ( ! vs_out )	{	cout << "can't create file " << significant_variables_file_name << endl;
		assert (  vs_out );		exit (1);	}

	vs_out << "## Results were obtained for run mode " << run_mode << endl << endl;

	double *T = cross_marix_;
	double *W = intra_group_cross_marix_;

	int N  = number_of_record_;
	int NP = number_of_included_;
	int NQ = number_of_groops_;

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

	vs_out << "## Fisher_in_  " << Fisher_in_  << endl;
	vs_out << "## Fisher_out_ " << Fisher_out_ << endl;


	vs_out << endl << endl;
	vs_out << "F-value      | Name of included variables " << endl;
	vs_out << "_____________|___________________________ " << endl;


	for (int ii=0;ii<number_of_variables_;ii++)
	{
		int index = one_dimensional_matrix_index(  ii,  ii, number_of_variables_) ;
		if ( W [index] < (-1)*VERY_SMALL_POSITIVE_VALUE   )
		{
			double Fisher_exclusion = (( W [index] - T [index]) / T [index] ) * (N-NP-NQ)/((double)(NQ-1)) ;

			PutVaDouble (Fisher_exclusion,vs_out,12, 3,'r');
			vs_out << "   ";
			PutVa( variable_names_ [ii],vs_out,10, 8,'r');
			vs_out << endl;

		}
	}


}
