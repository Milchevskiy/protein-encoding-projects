#include "Da_data.h"


#include "Sheduler.h"
#include "CommonFunc.h"

#include "da_covar_handle.h"

#include <string>
#include <fstream>
#include <iostream>
#include <cassert>
#include <sstream>
#include <vector>

using namespace std;

extern ofstream log_stream;

Da_data::
~Da_data()
{
	if ( group_average_value_ )
	{
		 for (int ii =0 ; ii< number_of_groops_; ii++ )
			 delete [] group_average_value_ [ii];
	}
	delete [] group_average_value_ ;

	if ( case_group_index_ )				delete [] case_group_index_;
	if ( intra_group_cross_marix_ ) 		delete [] intra_group_cross_marix_;
}

Da_data::
Da_data(  Sheduler	*options ) :
  options_					(options),
  number_of_groops_			(0),
  number_of_variables_		(0),
  number_of_record_         (0),
  case_group_index_			(0),
  intra_group_cross_marix_	(0),
  group_average_value_		(0)
{

	const string data_file_name		= options_->option_meaning ("DATA_FILE_NAME");

	string extension = get_extension_file_name (data_file_name);
	string input_file_format =  options_->option_meaning ("INPUT_FILE_FORMAT");;

/*	if ( extension == "BIN" || extension == "bin")
		input_file_format = "BIN";
	else
		input_file_format = "TXT";
*/



//	string input_file_format	= options_->option_meaning ("INPUT_FILE_FORMAT");

	if ( input_file_format == "TXT" || input_file_format == "txt" )
		convert_txt_to_binary (data_file_name);

// open files for reading records from binary files
	string binary_file_name_ = new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "binary_source");
	binary_source_stream_.open ( binary_file_name_.c_str(),ios::binary );
	if ( !binary_source_stream_ )
	{
		cout		<< " Da_data ERROR: " << binary_file_name_ << "problem" << endl;
		log_stream	<< " Da_data ERROR: " << binary_file_name_ << "problem" << endl;
		exit (-1);
	}

    initial_address_shift_ = sizeof (int) * 3;

	string crossum_status	= options_->option_meaning ("IS_CROSSUM_YET");
	if ( crossum_status =="NO" || crossum_status =="NO" )
		prepare_cross_sum_data ();
	else
		suck_up_cross_sum_data ();
}

void Da_data::

prepare_cross_sum_data ()
{

	double  *current_values = new double [number_of_variables_ + 1] ;
	int group_index;

	for ( int record_index = 0; record_index < number_of_record_ ; record_index++)
	{
		get_record (
			record_index,
			current_values,
			&group_index );

		da_covar_addition (
			number_of_variables_, current_values, group_average_value_[group_index]  ,
	        case_group_index_[group_index], intra_group_cross_marix_);

	        if (record_index%1000 == 0)
                cout << record_index << " crs" << endl;
	}


	string cross_sum_name = new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "cross_sum");

	ofstream out_stream ( cross_sum_name.c_str(),ios::binary );
	if ( !out_stream)
	{
		cout		<< " Da_data ERROR: " << cross_sum_name<< "problem" << endl;
		log_stream	<< " Da_data ERROR: " << cross_sum_name<< "problem" << endl;
		exit (-1);
	}


	out_stream.write( (char* ) &number_of_groops_,		sizeof (int)  );
	out_stream.write ( (char* ) &number_of_variables_,	sizeof (int)  );
	out_stream.write ( (char* ) &number_of_record_,	sizeof (int)  );

	out_stream.write ( (char* ) case_group_index_,		sizeof(int)*number_of_groops_ );

	for (int ii=0;ii<number_of_groops_;ii++)
		out_stream.write ( (char* ) group_average_value_[ii],sizeof(double)*number_of_variables_ );

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;
	out_stream.write ( (char* ) intra_group_cross_marix_, sizeof(double)*upper_triange_matrix_size_);

	delete [] current_values;
}

void Da_data::
suck_up_cross_sum_data ()
{

//allocate_arrays ();


	string cross_sum_name = new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "cross_sum");

	ifstream in_stream ( cross_sum_name.c_str(),ios::binary );
	if ( !in_stream)
	{
		cout		<< " Da_data ERROR: " << cross_sum_name<< " can't found" << endl;
		log_stream	<< " Da_data ERROR: " << cross_sum_name<< " can't found" << endl;
		exit (-1);
	}


	in_stream.read ( (char* ) &number_of_groops_,		sizeof (int)  );
	in_stream.read ( (char* ) &number_of_variables_,	sizeof (int)  );
	in_stream.read ( (char* ) &number_of_record_,	sizeof (int)  );



    allocate_arrays ();  /// НАДО БЫ ВЫДЕЛИТЬ ПАМЯТЬ

    in_stream.read ( (char* ) case_group_index_,		sizeof(int)*number_of_groops_ );
	for (int ii=0;ii<number_of_groops_;ii++)
		in_stream.read ( (char* ) group_average_value_[ii],sizeof(double)*number_of_variables_ );

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;
	in_stream.read ( (char* ) intra_group_cross_marix_, sizeof(double)*upper_triange_matrix_size_);


}

void Da_data::
convert_txt_to_binary ( const string & data_file_name)
{

	ifstream  data_stream ( data_file_name.c_str() );
	if ( ! data_stream )
	{
		log_stream	<< "Can't find " << data_file_name << endl;
		cout		<< "Can't find " << data_file_name << endl;
		exit (1);
	}

	string bin_file_name = new_extension_file_name	( options_->option_meaning ("DATA_FILE_NAME"), "binary_source");
	ofstream bin_stream( bin_file_name.c_str(),ios::binary );
	if ( ! bin_stream )
	{
		log_stream << "ERROR -  can't create binary  file" << bin_file_name << endl;
		cout       << "ERROR -  can't create binary  file" << bin_file_name << endl;
		exit (1);
	}



	string current_line;
	getline( data_stream , current_line, '\n' );

	{
		istringstream ist (current_line);
		ist >> number_of_groops_ >> number_of_record_ >> number_of_variables_;
	}
	bin_stream.write ( (char* ) &number_of_groops_,		sizeof (int)  );
	bin_stream.write ( (char* ) &number_of_variables_,	sizeof (int)  );
	bin_stream.write ( (char* ) &number_of_record_,		sizeof (int)  );

	initial_address_shift_ = sizeof (int) * 3;

	allocate_arrays ();

	double *current_values = new double [number_of_variables_ + 1] ;


	int counter =0 ;
	while( getline( data_stream , current_line, '\n' ) )
	{
		int current_group_number;
		istringstream ist (current_line);
		ist >> current_group_number;

		int check_index = 0;
		while ( ist >> current_values [check_index] )
			check_index ++;

			//**** check variables number
        if ( check_index !=  number_of_variables_ )
        {
            cout		<< "wrong number of words in text datafile." <<  check_index << " String number  " << counter << endl;
            log_stream	<< "wrong number of words in text datafile." <<  check_index << " String number  " << counter << endl;
            exit (1);
        }

		current_values [ number_of_variables_  ]  = (double) current_group_number;

		bin_stream.write ( (char* ) current_values,	(number_of_variables_+1)*sizeof (double));

		counter++ ;
		if ( counter %1000 == 0)
            cout << counter << " cnv" << endl;

	}

	assert( number_of_record_ == counter );

	delete [] current_values ;
}

void Da_data::
allocate_arrays ()
{

		case_group_index_	= new int [number_of_groops_];
		memset (case_group_index_,0,sizeof(int)*number_of_groops_);

		group_average_value_ = new double* [number_of_groops_] ;
		memset (group_average_value_ ,0,sizeof(double*)	 *number_of_groops_);
		for (int ii=0;ii<number_of_groops_;ii++)
		{
			group_average_value_[ii] = new double [number_of_variables_];
			memset (group_average_value_[ii],0,sizeof(double)*number_of_variables_);
		}

		upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;
		intra_group_cross_marix_             = new double [upper_triange_matrix_size_ ];
		memset (intra_group_cross_marix_ ,0,sizeof(double)*upper_triange_matrix_size_);
}


bool Da_data::
get_record (
	const int record_index,
	double *current_values,
	int *current_group_number )
{

	if ( record_index >= number_of_record_ ||  record_index  < 0 )
		return false;
	else
	{
		long shift = initial_address_shift_ + record_index*( number_of_variables_+1 )*sizeof(double) ;
		binary_source_stream_.seekg(shift,ios::beg);

		binary_source_stream_.read ( (char* ) current_values,	(number_of_variables_+1)*sizeof (double));
		*current_group_number = ( int ) current_values [number_of_variables_] ;

		return true;
	}
}



void Da_data::prepare_squeeze_record (
	const int record_index,
	const vector < int > &squeeze_index,
	double *current_values,
	double *squeeze_values,
	int &group_index )
{
		get_record (
			record_index,
			current_values,
			&group_index );

		for ( int ii=0; ii< squeeze_index.size(); ii++ )
			squeeze_values [ii] =  current_values [ squeeze_index [ii] ] ;

}

void Da_data::make_squeeze_database ()
{

//	string prev_protocol_file_name = options->option_meaning( string("INDEX_FILE_NAME") );
	vector < int > squeeze_index = get_squeeze_index ();

	int squeeze_size = squeeze_index.size();

	double  *current_values = new double [number_of_variables_ + 1] ;
	double  *squeeze_values = new double [squeeze_size + 1] ;

	int group_index;
	for ( int record_index = 0; record_index < number_of_record_ ; record_index++)
	{
		get_record (
			record_index,
			current_values,
			&group_index );

		int counter = 0;
		for ( int ii=0; ii< squeeze_size; ii++ )
			squeeze_values [ii] =  current_values [ squeeze_index [ii] ] ;

	}

	delete [] current_values;
	delete [] squeeze_values;
}

vector < int > Da_data::
get_squeeze_index ()
{

	string prev_protocol_file_name = options_->option_meaning( string("INDEX_FILE_NAME") );
	double Fisher_choosen = atof(options_->option_meaning( string("FISHER_CHOOSEN") ).c_str() ) ;

	ifstream in ( prev_protocol_file_name.c_str() ) ;
	if ( ! in )	{	cout << "can't find file " << prev_protocol_file_name<< endl;
		assert (  in );		exit (1);	}


	vector < int >  squeeze_index;

	string current_line;
	while( getline( in , current_line, '\n' ) )
	{
		if (   current_line[0] == '/'  ||
			   current_line[0] == '#'  ||
			   current_line[0] == ' '  ||
			   current_line[0] == '\n' ||
			   current_line[0] == '\0')
			continue;
//4.000       4           0.62845010  0.62420382        || 10   27   30   43
// 123456789 123456789 123456789 123456789 123456789 123456789



		double current_Fisher;
		{
			string dummy;
			istringstream ist (current_line);
			ist >> current_Fisher;
			ist >> dummy;
			ist >> dummy;
			ist >> dummy;
			ist >> dummy;

			if (current_Fisher == Fisher_choosen )
			{
				int i_value;
				while ( ist >> i_value )
					squeeze_index.push_back ( i_value );

				break;
			}
		}

	}

	return squeeze_index;

}




void Da_data::
show_data_as_txt_file ( const string & show_text_file)
{
	ofstream  out ( show_text_file.c_str() );
	if ( ! out )
	{
		log_stream	<< "Can't find " << show_text_file << endl;
		cout		<< "Can't find " << show_text_file << endl;
		exit (1);
	}

	out << number_of_groops_ << "  " << number_of_record_ << "  " << number_of_variables_ << endl ;

	double  *current_values = new double [number_of_variables_ + 1] ;
	int		current_group_number;

	for ( int record_index = 0; record_index < number_of_record_ ; record_index++)
	{
		get_record (
			record_index,
			current_values,
			&current_group_number );


		PutVa( current_group_number ,out, 5, 0, 'l') ;
		for (int ii=0; ii<number_of_variables_; ii++)
			PutVaDouble ( current_values[ii],out, 10, 5, 'l') ;
		out << endl;
	}

	delete [] current_values;

}
