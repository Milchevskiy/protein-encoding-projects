#ifndef DA_COVAR_ADDITION_H
#define DA_COVAR_ADDITION_H


void da_covar_addition
(	const int wcount,
	double *current_values,
	double *group_average_value,
	int  & case_group_index,
	double	*marix_w);



void da_covar_subtraction
(	const int wcount,
	double *current_values,
	double *group_average_value,
	int  & case_group_index,
	double	*marix_w );


#endif