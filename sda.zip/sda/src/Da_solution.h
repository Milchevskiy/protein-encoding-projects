

#ifndef DA_SOLUTION_H
#define DA_SOLUTION_H

#include <string>
#include <vector>
#include <map>
#include <fstream>

class Sheduler;

class Da_data;

using namespace std;


class Da_solution
{
public:
	Da_solution(  Sheduler	*options );
   ~Da_solution() ;


   void plain_solution ();

   	void show_data_from_source ();
	void read_Precursor_legacy ();
	void prepare_particular_solution ();
	void push_in_mandatory_variables ();
	void push_in_mandatory_variables ( vector < int > & mandatory_index );

	void assign_Fisher_paramemters (
		const double Fisher_in_ ,
		const double Fisher_out_,
		const double tolerance_ );

	void making_intra_group_covariation_matrix ();
	void pull_out_discrimination_constants();
	void print_orthodox_result ();
	void assign_names          ();

	void posterior_probability_to_be_in_each_group (
		const double *current_case,
		double *current_classifying_function,
		double *current_probability	);

	void print_prediction_parameters ( );
	void print_prediction_parameters (ofstream & out );

	void refresh_fisher (
		const double r_Fisher_in,
		const double r_Fisher_out,
		const double r_tolerance);

	void single_jack_nife (
		const double r_Fisher_in,
		const double r_Fisher_out,
		const double r_tolerance ,
		double & Quality_jack_nife,
		double & Quality_plain ,
		vector < int > & included_index,
		double **orthodox_prediction,
		int *array_of_group_index,
		int *predicted_group_index);

	void full_jack_nife ( double & best_Fisher);


	void calc_orthodox_prediction(
		int		*array_of_group_index,
		int		*predicted_group_index,
		double	**orthodox_prediction);


	void single_calculation ();

	void pull_out_included_index (vector < int > & included_index );

	void analyse_result ();

	void well_bred_prediction ();

	double calc_plain_quality ();


	void show_significant_variables ();

	Da_data     *get_da_da () const { return da_da_; }

	int		number_of_groops	() const { return number_of_groops_		; }
	int		number_of_variables () const { return number_of_variables_	; }
	int		number_of_record    () const { return number_of_record_		; }
	double  Fisher_in			() const { return Fisher_in_			; }
	double  Fisher_out			() const { return Fisher_out_			; }
	double  tolerance			() const { return tolerance_			; }

private:

	void show_orthodox_prediction (
		const double	Fisher,
		const int		*array_of_group_index,
		const int		*predicted_group_index,
		 double	**orthodox_prediction );

	void show_prediction_table(
		double best_Fisher,
		const int *array_of_group_index,
		const int *predicted_group_index );

	void calc_plain_prediction_table (
 		int		*array_of_group_index,
		int		*predicted_group_index,
		double   & Quality_plain );


	void allocate ();
//	void making_intra_group_covariation_matrix ();
	bool pedantic_selvar (int & FLAG,int & K);


	Da_data     *da_da_;

	Sheduler	*options_;

	int		number_of_groops_;
	int		number_of_variables_;
	int		number_of_record_    ;

	int		upper_triange_matrix_size_;

	vector < string >			    variable_names_;


	int				number_of_included_;
	vector  < int > included_index_;

	double							**group_average_value_;
	int								*case_group_index_;
	double 							*intra_group_cross_marix_;
	double 							*intra_group_cross_marix_diagonal_;
	double							*cross_marix_;
	double							*average_value_ ;

	double							**group_classifying_coefficient_;
	double							*constant_of_classifying_function_;

	double Fisher_in_  ;
	double Fisher_out_ ;
    double tolerance_  ;

//	std::vector < std::vector < double> >   group_classifying_coefficient_  ;
//	std::vector  < double >                 constant_of_classifying_function_  ;

//	std::vector  < double >					apriori_class_content_tare_;
//	int										*apriori_class_content_tare_; // ����� ������ int


	double	*apriori_class_content_tare_;



};

#endif
