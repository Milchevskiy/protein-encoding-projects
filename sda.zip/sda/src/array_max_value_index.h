#ifndef ARRAY_MAX_VALUE_INDEX_H
#define ARRAY_MAX_VALUE_INDEX_H


int array_max_value_index ( 
	const double *current_probability, 
	const int number_of_groops );


#endif
